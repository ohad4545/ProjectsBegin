package deliveriesCompany_208113332;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


public class MenuFile extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	public JMenuBar mb;
	public JMenu managerMenu;
	public JMenuItem addManager;
	
	public JMenu memberMenu;
	public JMenuItem addMember;
	public JMenuItem removeMember;
	
	public JMenu DeliveriesMenu;
	public JMenuItem addDelivery;
	public JMenuItem watchLastDeliveries;
	
	public JMenu shortDeliveryMenu;
	public JMenuItem removeShortDelivery;
	
	public JMenu logOut;
	public JMenuItem logOutOption;
	
	public JMenu more;
	public JMenuItem wholeShortDeliveries;
	public JMenuItem wholeShortDeliveriesMembers;
	public JMenuItem lastThirtyDays;
	
	public JLabel massage1;
	public JLabel massage2;
	public LogInFile logIn;
	
	public JLabel backgroundMenuFile;
	
	private String currentUserName;
	
	
	public MenuFile(String title,LogInFile logIn,String currentUserName){
		super(title);
		this.logIn = logIn;
		this.currentUserName = currentUserName;
	
		this.addWindowListener(new WindowListener() //only for windowClosing function
		{
			
			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowClosing(WindowEvent e) {
				DataBase.writeToWholeFiles();
				System.exit(0);
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		setLayout(null);
		mb = new JMenuBar();
		
		managerMenu = new JMenu("Manager");
		addManager = new JMenuItem("Add manager");
		addManager.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
		addManager.addActionListener(this);
		managerMenu.add(addManager);
		
		memberMenu = new JMenu("Member");
		addMember = new JMenuItem("Add member");
		addMember.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
		addMember.addActionListener(this);
		removeMember = new JMenuItem("Remove member");
		removeMember.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/remove.png")));
		removeMember.addActionListener(this);
		memberMenu.add(addMember); memberMenu.add(removeMember);
		
		DeliveriesMenu = new JMenu("Deliveries");
		addDelivery = new JMenuItem("Add delivery");
		addDelivery.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
		addDelivery.addActionListener(this);
		watchLastDeliveries = new JMenuItem("Watch last deliveries");
		watchLastDeliveries.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/eye.png")));
		watchLastDeliveries.addActionListener(this);
		DeliveriesMenu.add(addDelivery);
		DeliveriesMenu.add(watchLastDeliveries);
		
		shortDeliveryMenu = new JMenu("Short deliveries");

		removeShortDelivery = new JMenuItem("Remove short delivery");
		removeShortDelivery.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/remove.png")));
		removeShortDelivery.addActionListener(this);
		shortDeliveryMenu.add(removeShortDelivery);
		
		more = new JMenu("More");
		wholeShortDeliveries = new JMenuItem("Whole short deliveries");
		wholeShortDeliveries.addActionListener(this);
		wholeShortDeliveriesMembers = new JMenuItem("Whole short deliveries members");
		wholeShortDeliveriesMembers.addActionListener(this);
		lastThirtyDays = new JMenuItem("Last thirty days");
		lastThirtyDays.addActionListener(this);
		more.add(wholeShortDeliveries);more.add(wholeShortDeliveriesMembers);more.add(lastThirtyDays);
		shortDeliveryMenu.add(more);
		
		logOut = new JMenu("Logout");
		logOutOption = new JMenuItem("Logout");
		logOutOption.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/exit.png")));
		logOut.add(logOutOption);
		logOutOption.addActionListener(this);
		
		mb.add(managerMenu); mb.add(memberMenu); mb.add(DeliveriesMenu); mb.add(shortDeliveryMenu);
		mb.add(logOut);
		setJMenuBar(mb);
		
		
		massage1 = new JLabel("Hello " + DataBase.ManagerByUserName(this.currentUserName).getFirstName() + " " + DataBase.ManagerByUserName(this.currentUserName).getLastName());
		massage1.setBounds(180,50,200,50);
		massage1.setForeground(Color.darkGray);
		massage1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		
		massage2 = new JLabel("Please choose an option from the menu above");
		massage2.setBounds(100,80,400,50);
		massage2.setForeground(Color.darkGray);
		massage2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(massage1);
		this.add(massage2);
		this.setSize(500,600);
		this.getContentPane().setBackground(Color.WHITE);
	
		backgroundMenuFile = new JLabel("");
		backgroundMenuFile.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/business-man-say-hi-260nw-277503758.jpg")));
		backgroundMenuFile.setBounds(74, 129, 249, 254);
		this.add(backgroundMenuFile);
	
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		/*My idea was to do 2 frames, one for main manager and one for deputy manager*/
		/*And in each of the frames, when you choose an option at the menu, it sets the JPanel according to the user choice(except for log out option,which brings you to the LogInFile JFrame)*/
		
		if(e.getSource() == addManager)
		{
			this.setSize(500,650);
			this.setContentPane(new AddManagerFile(this.currentUserName));
		}
		
		if(e.getSource() == addMember)
		{
			this.setContentPane(new AddMemberFile(this.currentUserName));
		}
		
		if(e.getSource() == watchLastDeliveries)
		{
			this.setContentPane(new LastDeliveriesFile());
		}
			
		if(e.getSource() == removeMember)
		{
			this.setContentPane(new RemoveCustomerFile(this.currentUserName));
		}
		if(e.getSource() == removeShortDelivery)
		{
			this.setContentPane(new RemoveShortDeliveryFile(this.currentUserName));
		}
		if(e.getSource() == logOutOption)
		{
			this.setVisible(false);
			new LogInFile(this,null);
		}
		if(e.getSource() == addDelivery)
		{
			this.setContentPane(new AddDeliveryFile(this.currentUserName));
		}
		if(e.getSource() == wholeShortDeliveries)
		{
			this.setBounds(100, 100, 1250, 600);
			this.setContentPane(new WholeShortDeliveriesJTbaleFile());
		}
		if(e.getSource() == wholeShortDeliveriesMembers)
		{
			this.setContentPane(new wholeShortDeliveriesMembersFile());
		}
		if(e.getSource() == lastThirtyDays)
		{
			this.setContentPane(new LastThirtyDaysFile());
		}
		if(e.getSource() != wholeShortDeliveries && e.getSource() != addManager)
		{
			this.setSize(500,600);
		}	
		this.getContentPane().revalidate();//this order meant for refresh the page(JPanel)
	}	
	
}
