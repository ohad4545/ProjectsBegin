package deliveriesCompany_208113332;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;

public class RemoveShortDeliveryFile extends JPanel implements ActionListener{

	public JLabel title;
	public JLabel massage;
	public JComboBox<String> comboBoxShortDeliveries;
	public JButton removeButton;
	public JButton removeWholeShortDeliveriesButton;
	
	private String currentUserName;
	private Manager tmpManager;
	public JLabel backgroundRemoveShortDeliveryFile;
	
	public RemoveShortDeliveryFile(String currentUserName) {
		
		this.currentUserName = currentUserName;
		this.tmpManager = DataBase.ManagerByUserName(this.currentUserName);
		
		setLayout(null);
		this.setBounds(0,10,400,500);
		
		title = new JLabel("Remove short delivery file");
		title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
		title.setBounds(112, 21, 254, 22);
		add(title);
		
		massage = new JLabel("Please choose the short delivery you woud like to remove:");
		massage.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		massage.setBounds(10, 68, 356, 14);
		add(massage);
		
		comboBoxShortDeliveries = new JComboBox<String>();
		comboBoxShortDeliveries.setBounds(354, 64, 115, 22);
		
		comboBoxShortDeliveries.addItem("");
		
		/*I assumed that if the user is a deputy manager, it can remove only its short deliveries*/
		/*And if the user is a main manager, it can remove from short deliveries from the whole customers*/
		if(this.tmpManager instanceof DeputyManager)
		{
			for(ShortDelivery s:((DeputyManager)this.tmpManager).getShortDeliveriesList())
			{
				comboBoxShortDeliveries.addItem(s.getDeliveryCode() + " " + s.getMember().getMemberId());
			}
		}
		
		else if(this.tmpManager instanceof Manager)
		{
			for(ShortDelivery s:DataBase.wholeShortDeliveries)
			{
				comboBoxShortDeliveries.addItem(s.getDeliveryCode() + " " + s.getMember().getMemberId());
			}
		}
		
		add(comboBoxShortDeliveries);
		
		removeButton = new JButton("Remove short delivery");
		removeButton.setIcon(new ImageIcon(RemoveShortDeliveryFile.class.getResource("/ImagesPackage/remove.png")));
		removeButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		removeButton.setBounds(127, 103, 206, 23);
		removeButton.addActionListener(this);
		add(removeButton);
		
		removeWholeShortDeliveriesButton = new JButton("Remove whole member short deliveries");
		removeWholeShortDeliveriesButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		removeWholeShortDeliveriesButton.setIcon(new ImageIcon(RemoveShortDeliveryFile.class.getResource("/ImagesPackage/delete.png")));
		removeWholeShortDeliveriesButton.setBounds(79, 137, 325, 33);
		removeWholeShortDeliveriesButton.addActionListener(this);
		add(removeWholeShortDeliveriesButton);
		if(this.tmpManager instanceof DeputyManager)
		{
			removeWholeShortDeliveriesButton.setVisible(false);
		}
		
		this.setSize(500,500);
		
		backgroundRemoveShortDeliveryFile = new JLabel("");
		backgroundRemoveShortDeliveryFile.setIcon(new ImageIcon(RemoveShortDeliveryFile.class.getResource("/ImagesPackage/parcel-delivery-services-500x500.jpg")));
		backgroundRemoveShortDeliveryFile.setBounds(0, 0, 500, 526);
		add(backgroundRemoveShortDeliveryFile);
		
		
		this.setVisible(true);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == removeButton)
		{
			try
			{
				if(comboBoxShortDeliveries.getSelectedIndex() == 0)//delivery was not chosen
				{
					throw new NullPointerException();
				}
				
				ShortDelivery tmpShortDelivery = null;
				
				/*Removing and updating the fit data structures*/
				
				if(this.tmpManager instanceof DeputyManager)
				{
					tmpShortDelivery = ((DeputyManager) this.tmpManager).getShortDeliveriesList().get(comboBoxShortDeliveries.getSelectedIndex() - 1);
					((DeputyManager) this.tmpManager).getShortDeliveriesList().remove(tmpShortDelivery);
				}
				
				else if(this.tmpManager instanceof Manager)
				{
					tmpShortDelivery = DataBase.wholeShortDeliveries.get(comboBoxShortDeliveries.getSelectedIndex() - 1);
					for(DeputyManager m:DataBase.deputyManagers)
					{
						if(m.getShortDeliveriesList().indexOf(tmpShortDelivery) != -1)
						{
							m.getShortDeliveriesList().remove(tmpShortDelivery);
						}
					}
				}
				
				Members tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpShortDelivery.getMember()));
				tmpMember.getDeliveries().remove(tmpShortDelivery);
					
				DataBase.wholeShortDeliveries.remove(tmpShortDelivery);
				DataBase.shortDeliveriesByMemberId.get(tmpMember.getMemberId()).remove(tmpShortDelivery);
				
				/*The member has more deliveries*/
				if(tmpMember.getDeliveries().size() > 0)
				{
					DataBase.ourLastDeliveries.put(tmpMember,tmpMember.getDeliveries().get(tmpMember.getDeliveries().size() - 1));
				}
				
				/*The member does not have more deliveries*/
				else if(tmpMember.getDeliveries().size() == 0)
				{
					DataBase.ourLastDeliveries.remove(tmpMember);
				}
				
				Manager tmpManager2 = tmpMember.whichManagerStrExists(tmpMember.getMemberId());
				tmpManager2.getManagerMembers().get(tmpMember.getMemberId()).getDeliveries().remove(tmpShortDelivery);
				
				JOptionPane.showMessageDialog(null, "The short delivery was removed successfully");
				int index = comboBoxShortDeliveries.getSelectedIndex();
				comboBoxShortDeliveries.removeItemAt(index);
				comboBoxShortDeliveries.setSelectedIndex(0);
			}
				
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "Please choose a delivery");
			}
			
		}
		
		if(e.getSource() == removeWholeShortDeliveriesButton)
		{
			try
			{
				/*Removing and updating the fit data structures*/
				
				String tmpMemberId = JOptionPane.showInputDialog(null, "Please type the member ID you would like to remove his short deliveries:");
				if(DataBase.shortDeliveriesByMemberId.get(tmpMemberId) == null || DataBase.shortDeliveriesByMemberId.get(tmpMemberId).size() == 0)
				{
					throw new UnauthorizedException();
				}
				else if(DataBase.shortDeliveriesByMemberId.get(tmpMemberId)!= null)
				{
					Members tmpMember = new Members(tmpMemberId);
					ArrayList<ShortDelivery> al = DataBase.shortDeliveriesByMemberId.get(tmpMemberId);
					DataBase.shortDeliveriesByMemberId.remove(tmpMemberId);
					DataBase.wholeShortDeliveries.removeAll(al);
					DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember)).getDeliveries().removeAll(al);
					
					tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember));
					if(tmpMember.getDeliveries().size() == 0)
					{
						if(DataBase.ourLastDeliveries.containsKey(tmpMember))
						{
							DataBase.ourLastDeliveries.remove(tmpMember);
						}
					}
					else if(tmpMember.getDeliveries().size() > 0)
					{
						DataBase.ourLastDeliveries.put(tmpMember,tmpMember.getDeliveries().get(tmpMember.getDeliveries().size() - 1));
					}

					/*This loop meant for getting the whole deputy Managers and NOT for removing the member itself*/
					for(DeputyManager m:DataBase.deputyManagers)
					{
						m.removeShortDeliveries(tmpMember);
					}
					
					JOptionPane.showMessageDialog(null, "The whole member's short deliveries were removed successfully");
					
				}
			}
			catch(UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "Member does not exist or does not have short deliveries, please type ID again");
			}
		
		}
		
	}
}
