package deliveriesCompany_208113332;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import java.awt.Font;

public class AddShortDeliveryFile extends JPanel implements ActionListener{
	public JTextField originCity_tf;
	public JTextField destinationCity_tf;
	public JTextField distance_tf;
	public JTextField pricePerKm_tf;
	public JButton clearButton;
	public JButton addDeliveryButton;
	public JLabel pricePerKm;
	public JLabel distanceLabel;
	public JLabel destinationCityLabel;
	public JLabel originCityLabel;
	public JComboBox<String> comboBoxCustomers;
	public JLabel massage;
	public JLabel title;
	public JDateChooser dateToArriveCalander;
	public JLabel dateLabel;
	public JTextFieldDateEditor editor1;
	public JLabel deliveryCodeL;
	public JLabel sLabel;
	public JTextField restOfCode_tf;
	public JTextField price_tf1;
	public JLabel priceLabel;
	public JButton calcButton;
	public JLabel backgroundLastDeliveriesFile;

	private String currentUserName;
	
	/**
	 * Create the panel.
	 */
	public AddShortDeliveryFile(String currentUserName) {
		setBackground(UIManager.getColor("Button.background"));
		
		this.currentUserName = currentUserName;
		setLayout(null);
		
		title = new JLabel("Add short delivery file");
		title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
		title.setBounds(127, 37, 218, 22);
		add(title);
		
		massage = new JLabel("Choose customer:");
		massage.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		massage.setBounds(39, 95, 121, 14);
		add(massage);
		
		comboBoxCustomers = new JComboBox<String>();
		comboBoxCustomers.setBounds(172, 91, 188, 22);
		comboBoxCustomers.addItem("");
		Iterator<Members> itr = DataBase.wholeManagersMembersList.iterator();
		Members tmpMember;
		while(itr.hasNext())
		{
			tmpMember = itr.next();
			comboBoxCustomers.addItem(tmpMember.getMemberId() + " " + tmpMember.getFirstName() + " " + tmpMember.getLastName());
		}
		add(comboBoxCustomers);
		
		originCityLabel = new JLabel("Origin city:");
		originCityLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		originCityLabel.setBounds(39, 187, 91, 14);
		add(originCityLabel);
		
		originCity_tf = new JTextField();
		originCity_tf.setBounds(172, 184, 132, 20);
		add(originCity_tf);
		originCity_tf.setColumns(10);
		
		destinationCityLabel = new JLabel("Destination city:");
		destinationCityLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		destinationCityLabel.setBounds(39, 218, 121, 14);
		add(destinationCityLabel);
		
		destinationCity_tf = new JTextField();
		destinationCity_tf.setBounds(172, 215, 132, 20);
		add(destinationCity_tf);
		destinationCity_tf.setColumns(10);
		
		distanceLabel = new JLabel("Distance:");
		distanceLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		distanceLabel.setBounds(39, 249, 78, 14);
		add(distanceLabel);
		
		distance_tf = new JTextField();
		distance_tf.setBounds(172, 246, 40, 20);
		add(distance_tf);
		distance_tf.setColumns(10);
		
		pricePerKm = new JLabel("Price per Km:");
		pricePerKm.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		pricePerKm.setBounds(39, 274, 91, 14);
		add(pricePerKm);
		
		pricePerKm_tf = new JTextField();
		pricePerKm_tf.setBounds(172, 271, 52, 20);
		add(pricePerKm_tf);
		pricePerKm_tf.setColumns(10);
		pricePerKm_tf.setEditable(false);
		
		addDeliveryButton = new JButton("Add delivery");
		addDeliveryButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		addDeliveryButton.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/add.png")));
		addDeliveryButton .setBounds(84, 336, 140, 33);
		addDeliveryButton.addActionListener(this);
		add(addDeliveryButton);
		
		clearButton = new JButton("Clear");
		clearButton.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/edit_clear.png")));
		clearButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		clearButton.setBounds(250, 332, 110, 41);
		clearButton.addActionListener(this);
		add(clearButton);

		this.setSize(500,400);
		
		dateToArriveCalander = new JDateChooser();
		dateToArriveCalander.setDateFormatString("dd/MM/yyyy");
		dateToArriveCalander.setBounds(172, 299, 115, 19);
		add(dateToArriveCalander);
		editor1 = (JTextFieldDateEditor) dateToArriveCalander.getDateEditor();
		editor1.setEditable(false);
		
		dateLabel = new JLabel("Date to arrive:");
		dateLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		dateLabel.setBounds(39, 299, 93, 14);
		add(dateLabel);
		
		deliveryCodeL = new JLabel("Delivery code:");
		deliveryCodeL.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		deliveryCodeL.setBounds(39, 129, 91, 14);
		add(deliveryCodeL);
		
		sLabel = new JLabel("S");
		sLabel.setBounds(172, 129, 46, 14);
		add(sLabel);
		
		restOfCode_tf = new JTextField();
		restOfCode_tf.setBounds(201, 126, 52, 20);
		add(restOfCode_tf);
		restOfCode_tf.setColumns(10);
		
		price_tf1 = new JTextField();
		price_tf1.setBounds(172, 153, 86, 20);
		add(price_tf1);
		price_tf1.setColumns(10);
		
		priceLabel = new JLabel("Price:");
		priceLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		priceLabel.setBounds(39, 154, 46, 14);
		add(priceLabel);
		
		calcButton = new JButton("calculate");
		calcButton.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/calculator.png")));
		calcButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		calcButton.setBounds(235, 260, 125, 33);
		calcButton.addActionListener(this);
		add(calcButton);
	
		backgroundLastDeliveriesFile = new JLabel("");
		backgroundLastDeliveriesFile.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/delivery-man-handing-box-client_23-2148669584.jpg")));
		backgroundLastDeliveriesFile.setBounds(0, -77, 500, 570);
		add(backgroundLastDeliveriesFile);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == addDeliveryButton)
		{
			Delivery tmpDelivery;
			double price,tmpPricePerKm;
			int tmpDistance;
			Date tmpDate;
			Members tmpMember,tmpMember2;
			ShortDelivery tmpShortDelivery;
			DeputyManager tmpDeputyManager = (DeputyManager)(DataBase.ManagerByUserName(this.currentUserName));
			try
			{
				/*if the deputy manager reached his take care limit if short deliveries*/
				if(tmpDeputyManager.getAmountDeliveriesTakeCare() <= tmpDeputyManager.getShortDeliveriesList().size())
				{
					throw new UnauthorizedException();
				}
				
				/*empty field*/
				if(restOfCode_tf.getText().equals("") || price_tf1.getText().equals("") || 
					originCity_tf.getText().equals("") || destinationCity_tf.getText().equals("") ||
				   distance_tf.getText().equals("") || pricePerKm.getText().equals("") ||
				   comboBoxCustomers.getSelectedIndex() == 0 || editor1.getText().equals(""))
				{
					throw new NullPointerException();
				}
				
				tmpDelivery = new Delivery("S" + restOfCode_tf.getText());
				
				/*delivery code already exists*/
				if(tmpDelivery.whichManagerStrExists(tmpDelivery.getDeliveryCode()) != null)
//				if(DataBase.wholeDeliveriesByDeliveryCode.get("S" + restOfCode_tf.getText()) != null)
				{
					throw new UserAlreadyExistsException();
				}
				
				price = Double.parseDouble(price_tf1.getText());
				tmpDistance = Integer.parseInt(distance_tf.getText());
				
				/*Distance is above 30*/
				if(tmpDistance > 30)
				{
					throw new DistanceAboveThertyException();
				}
				tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(editor1.getText());
				tmpPricePerKm = Double.parseDouble(pricePerKm_tf.getText());
				tmpMember = DataBase.wholeManagersMembersList.get(comboBoxCustomers.getSelectedIndex() - 1);
				tmpMember2 = new Members(tmpMember.getMemberId());
				tmpShortDelivery = new ShortDelivery("S" + restOfCode_tf.getText(),price,tmpDate,
						originCity_tf.getText(),destinationCity_tf.getText(),tmpDistance,tmpPricePerKm,
						tmpMember2);
				
				/*Adding to the fit DataBases*/
//				DeputyManager tmpDeputyManager = (DeputyManager)(DataBase.wholeManagersByUserName.get(this.currentUserName));
				tmpDeputyManager.getShortDeliveriesList().add(tmpShortDelivery);
				
				tmpMember.getDeliveries().add(tmpShortDelivery);				
				
//				Manager tmpManager = DataBase.wholeManagersMembersMap.get(tmpMember.getMemberId());
//				tmpManager.getManagerMembers().get(tmpMember.getMemberId()).addDelivery(tmpShortDelivery);
				
//				ArrayList<Object> tmpAl = new ArrayList<Object>();
//				tmpAl.add(tmpMember);tmpAl.add(tmpManager);
//				DataBase.wholeDeliveriesByDeliveryCode.put(tmpShortDelivery.getDeliveryCode(),tmpAl);
				
//				DataBase.wholeShortDeliveriesByDeliveryCode.put(tmpShortDelivery.getDeliveryCode(), tmpDeputyManager);
//				DataBase.managers.get(DataBase.managers.indexOf(tmpManager)).getManagerMembers().get(tmpMember.getMemberId()).addDelivery(tmpShortDelivery);
				
//				DataBase.deputyManagers.get(DataBase.deputyManagers.indexOf(tmpDeputyManager)).getShortDeliveriesList().add(tmpShortDelivery);
				DataBase.ourLastDeliveries.put(tmpMember, tmpShortDelivery);
				
				DataBase.wholeShortDeliveries.add(tmpShortDelivery);
				if(DataBase.shortDeliveriesByMemberId.containsKey(tmpMember.getMemberId()))
				{
					DataBase.shortDeliveriesByMemberId.get(tmpMember.getMemberId()).add(tmpShortDelivery);
				}
				else
				{
					ArrayList<ShortDelivery> al = new ArrayList<ShortDelivery>();
					al.add(tmpShortDelivery);
					DataBase.shortDeliveriesByMemberId.put(tmpMember.getMemberId(),al);
				}
				
				JOptionPane.showMessageDialog(null, "The short delivery code will be S" + restOfCode_tf.getText());
				JOptionPane.showMessageDialog(null, "Short delivery was added successfully");
			}
			
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields is empty,please fill the whole fields");
			}
			catch(NumberFormatException ex)
			{
				JOptionPane.showMessageDialog(null, "please pay attention that the price must be a number and the distance must be an integer number");
			}
			catch(ParseException ex)
			{
				JOptionPane.showMessageDialog(null, "Can not convert Date");
			}
			catch (UserAlreadyExistsException ex) 
			{
				JOptionPane.showMessageDialog(null, "This short delivery already exists.please type another delivery code");
			}
			catch (DistanceAboveThertyException ex)
			{
				JOptionPane.showMessageDialog(null, "Distance can not be above 30 km");
			} 
			catch (UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "Sorry, You reached the max amount of short deliveries you can take care and therefore you can not add more deliveries(unless you remove one)");
			}
		
		}
		if(e.getSource() == calcButton)
		{
			try
			{
				double price = Double.parseDouble(price_tf1.getText());
				int tmpDistance = Integer.parseInt(distance_tf.getText());
				if(price < 0 || tmpDistance < 0)
				{
					throw new NumberSmallerThenZeroException();
				}
				if(tmpDistance == 0)
				{
					throw new ArithmeticException();
				}
				pricePerKm_tf.setText(String.valueOf(price/tmpDistance));
			}
			catch(NumberFormatException ex)
			{
				JOptionPane.showMessageDialog(null, "please pay attention that the price must be a number and the distance must be an integer number, these fields also can not be empty");
			}	
			catch(ArithmeticException ex)
			{
				JOptionPane.showMessageDialog(null, "Please pay attention that the distance must be an Integer and can not be 0");
			}
			catch(NumberSmallerThenZeroException ex)
			{
				JOptionPane.showMessageDialog(null, "Please pay attention that the price and the distance can not be a negative number");
			}
		}
		if(e.getSource() == clearButton)
		{
			restOfCode_tf.setText("");
			price_tf1.setText("");
			originCity_tf.setText("");
			destinationCity_tf.setText("");
			distance_tf.setText("");
			pricePerKm_tf.setText("");
			comboBoxCustomers.setSelectedIndex(0);
			editor1.setText("");
		}
		
	}
}
