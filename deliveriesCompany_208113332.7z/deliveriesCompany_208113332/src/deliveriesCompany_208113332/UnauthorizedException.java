package deliveriesCompany_208113332;

/*This exception is thrown when an a user tries to do something in the program that it is not authorized to do*/
public class UnauthorizedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UnauthorizedException()
	{
		super();
	}
	public UnauthorizedException(String massage)
	{
		super(massage);
	}
}
