package deliveriesCompany_208113332;

/*This exception is thrown when a main manager tries to add a member from a different area*/
public class InvalidLivingAreaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/*constructors*/
	public InvalidLivingAreaException() {
		super();
	}
	public InvalidLivingAreaException(String massage) {
		super(massage);
	}
}
