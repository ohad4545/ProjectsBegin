package deliveriesCompany_208113332;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class LastDeliveriesFile extends JPanel implements ItemListener{

	public JPanel p2;
	public JPanel p3;
	public 	JLabel title;
	public JLabel massage; //choose a delivery(comboBox of delivery code)
	public JComboBox<String> deliveryCodeComboBox;
	public JTextArea textAreaDetails;
	public JScrollPane jsp;
	public JLabel backgroundLastDeliveriesFile;
	
	private ArrayList<Members> lastDeliveriesMembers;
	
	public LastDeliveriesFile() {
		
		this.lastDeliveriesMembers = new ArrayList<Members>();
		this.setBackground(Color.WHITE);
		this.setBounds(0,30,400,500);
		p2 = new JPanel(new FlowLayout());
		p2.setBounds(30,200,400,50);
		p2.setBackground(Color.WHITE);
		massage = new JLabel("Please choose the deivery:");
		massage.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		massage.setBounds(30,50,200,20);
		p2.add(massage);
		
		deliveryCodeComboBox = new JComboBox<String>();
		deliveryCodeComboBox.setSize(1000,500);
		deliveryCodeComboBox.addItem("");
		for(Entry<Members, Delivery> en: DataBase.ourLastDeliveries.entrySet())
		{
			deliveryCodeComboBox.addItem(en.getValue().getDeliveryCode());
			this.lastDeliveriesMembers.add(en.getKey());
		}
		deliveryCodeComboBox.addItemListener(this);
		p2.add(deliveryCodeComboBox);
		this.add(p2);		

		p3 = new JPanel(new FlowLayout());
		p3.setBounds(50,70,400,50);
		textAreaDetails = new JTextArea(8,40);
		textAreaDetails.setEditable(false);
		jsp = new JScrollPane(textAreaDetails);
		jsp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		p3.setBackground(Color.WHITE);
		p3.add(jsp);
		this.add(p3);
		
		backgroundLastDeliveriesFile = new JLabel("");
		backgroundLastDeliveriesFile.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/delimage.jpg")));
		backgroundLastDeliveriesFile.setBounds(127, 173, 500, 197);
		add(backgroundLastDeliveriesFile);
		this.setSize(500,500);
		this.setVisible(true);
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(deliveryCodeComboBox.getSelectedIndex() == 0)//no delivery is chosen
		{
			textAreaDetails.setText("");
		}
		else
		{
			String tmpDeliveryCode = String.valueOf(deliveryCodeComboBox.getSelectedItem());
//			Members tmpMember = (Members) DataBase.wholeDeliveriesByDeliveryCode.get(tmpDeliveryCode).get(0);
			Members tmpMember = this.lastDeliveriesMembers.get(deliveryCodeComboBox.getSelectedIndex() - 1);
			Delivery tmpLastDelivery = tmpMember.getDeliveries().get(tmpMember.getDeliveries().size() - 1);
			Manager tmpManager = tmpMember.whichManagerStrExists(tmpMember.getMemberId());
			
			/*When the last delivery is a short delivery, in the text area also written the name of the deputy manager that responsible for this short delivery*/
			if(tmpLastDelivery.getDeliveryCode().startsWith("S"))//short delivery
			{
				tmpLastDelivery = (ShortDelivery)tmpLastDelivery;
				textAreaDetails.setText(tmpManager.toString() +"\n" + tmpMember.toString() + "\n" +
						tmpLastDelivery.toString() +"\n" + "Deputy manager:\n" + tmpLastDelivery.whichManagerStrExists(tmpDeliveryCode).toString());
			}
			else if(!tmpLastDelivery.getDeliveryCode().startsWith("S"))
			{
				textAreaDetails.setText(tmpManager.toString() +"\n" + tmpMember.toString() + "\n" +
						tmpLastDelivery.toString());
			}
		}
		
	}
}
