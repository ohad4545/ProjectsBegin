package deliveriesCompany_208113332;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class LastThirtyDaysFile extends JPanel {
	
	public JPanel panel11;
	public JPanel panel22;
	public JLabel massage; //These are the whole cities that a short delivery was sent to them in the last 30 days
	public JTextArea textAreaShortDeliveriesDetails;
	public JScrollPane jsp2;
	public JLabel backgroundLastThirtyDaysFile;
	
	private String textOfTheTextArea;
	private Date tmpShortDeliveryArrivedDate;
	private Date todayDate;
	private long result;
	private int daysDifference1;
	private long daysDifference2;
	
	public LastThirtyDaysFile()
	{
		this.setBackground(Color.WHITE);
		
		this.textOfTheTextArea = "";
		this.todayDate = new Date();
		
		/*Adding the whole short deliveries that arrived to their customers at the last 30 days*/
		for(ShortDelivery s:DataBase.wholeShortDeliveries)
		{
			this.tmpShortDeliveryArrivedDate = s.getDateArrived();
			this.result = this.todayDate.getTime() - this.tmpShortDeliveryArrivedDate.getTime();
			this.daysDifference2 = this.result / (24 * 60 * 60 * 1000);
			this.daysDifference1 = (int) this.daysDifference2;
			if(this.daysDifference1 <= 30)
			{
				this.textOfTheTextArea += s.getDestinationCity() + "\n";
			}
		}
		
		this.setBounds(0,30,400,500);
		panel11 = new JPanel(new FlowLayout());
		panel11.setBounds(30,200,400,50);
		panel11.setBackground(Color.WHITE);
		massage = new JLabel("Destination cities that short deliveries were sent to them at the last 30 days:");
		massage.setBounds(30,50,200,20);
		massage.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		panel11.add(massage);

		this.add(panel11);		

		panel22 = new JPanel(new FlowLayout());
		panel22.setBounds(50,70,400,50);
		panel22.setBackground(Color.WHITE);
		textAreaShortDeliveriesDetails = new JTextArea(8,40);
		textAreaShortDeliveriesDetails.setEditable(false);
		textAreaShortDeliveriesDetails.setText(this.textOfTheTextArea);
		jsp2 = new JScrollPane(textAreaShortDeliveriesDetails);
		jsp2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		panel22.add(jsp2);
		this.add(panel22);
		
		backgroundLastThirtyDaysFile = new JLabel("");
		backgroundLastThirtyDaysFile.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/Delivery-truck-service-icon-Graphics-4544895-1-1-580x386.jpg")));
		backgroundLastThirtyDaysFile.setBounds(0, 154, 500, 235);
		add(backgroundLastThirtyDaysFile);
		
		this.setSize(500,500);
		this.setVisible(true);
	}

}
