package deliveriesCompany_208113332;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class MenuFileDeputyManager extends JFrame implements ActionListener {

	public JMenu shortDeliveryMenu;
	public JMenuItem addShortDelivery;
	public JMenuItem removeShortDelivery;
	
	public JMenuBar mb;
	public JMenu logOut;
	public JMenuItem logOutOption;
	
	public JLabel massage1;
	public JLabel massage2;
	public LogInFile logIn;
	public JLabel backgroundMenuFile;
	
	private String currentUserName;
	
	public MenuFileDeputyManager(String title,LogInFile logIn,String currentUserName)
	{
		super(title);
		this.logIn = logIn;
		this.currentUserName = currentUserName;
		
		this.addWindowListener(new WindowListener()//only for windowClosing function
		{
			
			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowClosing(WindowEvent e) {
				DataBase.writeToWholeFiles();
				System.exit(0);
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		setLayout(null);
		mb = new JMenuBar();
		
		shortDeliveryMenu = new JMenu("Short deliveries");
		addShortDelivery = new JMenuItem("Add short delivery");
		addShortDelivery.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
		addShortDelivery.addActionListener(this);
		removeShortDelivery = new JMenuItem("Remove short delivery");
		removeShortDelivery.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/remove.png")));
		removeShortDelivery.addActionListener(this);
		shortDeliveryMenu.add(addShortDelivery);
		shortDeliveryMenu.add(removeShortDelivery);
		
		logOut = new JMenu("Logout");
		logOutOption = new JMenuItem("Logout");
		logOutOption.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/exit.png")));
		logOut.add(logOutOption);
		logOutOption.addActionListener(this);
		
		mb.add(shortDeliveryMenu);mb.add(logOut);
		setJMenuBar(mb);
		
		massage1 = new JLabel("Hello " + DataBase.ManagerByUserName(this.currentUserName).getFirstName() + " " + DataBase.ManagerByUserName(this.currentUserName).getLastName());
		massage1.setBounds(180,50,200,50);
		
		
		massage2 = new JLabel("Please choose an option from the menu above");
		massage2.setBounds(100,80,400,50);
		this.add(massage1);
		this.add(massage2);
		this.setSize(500,600);
		
		this.getContentPane().setBackground(Color.WHITE);
		
		backgroundMenuFile = new JLabel("");
		backgroundMenuFile.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/business-man-say-hi-260nw-277503758.jpg")));
		backgroundMenuFile.setBounds(74, 129, 249, 254);
		this.add(backgroundMenuFile);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == addShortDelivery)
		{
			try
			{
				DeputyManager tmpDeputyManager = (DeputyManager)(DataBase.ManagerByUserName(this.currentUserName));
				
				/*If the deputy manager arrived his limit in take care for short deliveries property*/
				if(tmpDeputyManager.getAmountDeliveriesTakeCare() <= tmpDeputyManager.getShortDeliveriesList().size())
				{
					throw new UnauthorizedException();
				}
				this.setContentPane(new AddShortDeliveryFile(this.currentUserName));
				this.getContentPane().revalidate();
			}
			
			catch(UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "Sorry, you can not add more deliveries because the amount of deliveries you take care equals to the short deliveries you are responsible right now");
			}	
		}
		if(e.getSource() == removeShortDelivery)
		{
			this.setContentPane(new RemoveShortDeliveryFile(this.currentUserName));
		}
		if(e.getSource() == logOutOption)
		{
			this.setVisible(false);
			new LogInFile(null,this);
		}
		this.getContentPane().revalidate();
	}
}
