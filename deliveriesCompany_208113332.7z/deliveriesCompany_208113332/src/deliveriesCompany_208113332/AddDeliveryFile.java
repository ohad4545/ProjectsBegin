package deliveriesCompany_208113332;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


import javax.swing.JComboBox;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;

import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;

public class AddDeliveryFile extends JPanel implements ItemListener,ActionListener{
	public JLabel deliveryCodeLabel;
	public JTextField deliveryCode_tf;
	public JTextField price_tf;
	public JLabel title;
	public JComboBox<String> kindOfDeliveryComboBox;
	public JLabel priceLabel;
	public JButton addDeliveryButton;
	public JButton clearButton;
	public JLabel memberLabel;
	public JComboBox<String> membersComboBox;
	public JLabel deadLineLabel;
	public JTextField expressAddition_tf;
	public JTextField companyName_tf;
	public JTextField afterDiscountPrice_tf;
	public JLabel afterDiscountPriceLabel;
	public JDateChooser deadLineCalander;
	public JLabel expressAdditionPrice;
	public JLabel companyNameLabel;
	public JTextFieldDateEditor editor;
	
	private Manager tmpManager;
	private String currentUserName;
	/**
	 * Create the panel.
	 */
	public AddDeliveryFile(String currentUserName) {
		
		this.currentUserName = currentUserName;
		this.tmpManager = DataBase.ManagerByUserName(this.currentUserName);
		
		setLayout(null);
		
		title = new JLabel("Add delivery file");
		title.setForeground(Color.BLACK);
		title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
		title.setBounds(130, 0, 200, 37);
		add(title);
		
		deliveryCodeLabel = new JLabel("delivery code:");
		deliveryCodeLabel.setForeground(Color.BLACK);
		deliveryCodeLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		deliveryCodeLabel.setBounds(32, 124, 107, 14);
		add(deliveryCodeLabel);
		
		kindOfDeliveryComboBox = new JComboBox<String>();
		kindOfDeliveryComboBox.setBounds(149, 120, 99, 22);
		kindOfDeliveryComboBox.addItem("");
		kindOfDeliveryComboBox.addItem("G - general");
		kindOfDeliveryComboBox.addItem("E - express");
		kindOfDeliveryComboBox.addItem("B - business");
		kindOfDeliveryComboBox.addItemListener(this);
		add(kindOfDeliveryComboBox);
		
		deliveryCode_tf = new JTextField();
		deliveryCode_tf.setBounds(258, 121, 65, 20);
		add(deliveryCode_tf);
		deliveryCode_tf.setColumns(10);
		
		priceLabel = new JLabel("Price:");
		priceLabel.setForeground(Color.BLACK);
		priceLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		priceLabel.setBounds(32, 149, 46, 14);
		add(priceLabel);
		
		price_tf = new JTextField();
		price_tf.setBounds(106, 149, 52, 20);
		add(price_tf);
		price_tf.setColumns(10);
		
		addDeliveryButton = new JButton("Add delivery");
		addDeliveryButton.setForeground(Color.BLACK);
		addDeliveryButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		addDeliveryButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
		addDeliveryButton.setBounds(106, 374, 133, 37);
		addDeliveryButton.addActionListener(this);
		add(addDeliveryButton);
		
		clearButton = new JButton("Clear");
		clearButton.setForeground(Color.BLACK);
		clearButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		clearButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/edit_clear.png")));
		clearButton.setBounds(249, 374, 126, 37);
		clearButton.addActionListener(this);
		add(clearButton);
		
		memberLabel = new JLabel("Please choose the member you would like to add the delivery:");
		memberLabel.setForeground(Color.BLACK);
		memberLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		memberLabel.setBounds(32, 37, 382, 14);
		add(memberLabel);
		
		membersComboBox = new JComboBox<String>();
		membersComboBox.setBounds(32, 62, 274, 22);
		membersComboBox.addItem("");
		for(Members m:this.tmpManager.getManagerMembers().values())
		{
			membersComboBox.addItem(m.getMemberId() + " " + m.getFirstName() + " " + m.getLastName());
		}
		add(membersComboBox);
		
		deadLineLabel = new JLabel("Deadline arrive Date:");
		deadLineLabel.setForeground(Color.BLACK);
		deadLineLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		deadLineLabel.setBounds(32, 221, 126, 14);
		add(deadLineLabel);
		deadLineLabel.setVisible(false);
		
		deadLineCalander = new JDateChooser();
		deadLineCalander.setDateFormatString("dd/MM/yyyy");
		editor = (JTextFieldDateEditor) deadLineCalander.getDateEditor();
		editor.setEditable(false);
		
		deadLineCalander.setBounds(168, 221, 155, 19);
		add(deadLineCalander);
		deadLineCalander.setVisible(false);
		
		expressAdditionPrice = new JLabel("After express addition price:");
		expressAdditionPrice.setForeground(Color.BLACK);
		expressAdditionPrice.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		expressAdditionPrice.setBounds(32, 256, 174, 14);
		add(expressAdditionPrice);
		expressAdditionPrice.setVisible(false);
		
		expressAddition_tf = new JTextField();
		expressAddition_tf.setBounds(216, 253, 52, 20);
		add(expressAddition_tf);
		expressAddition_tf.setColumns(10);
		expressAddition_tf.setVisible(false);
		
		companyNameLabel = new JLabel("Company name:");
		companyNameLabel.setForeground(Color.BLACK);
		companyNameLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		companyNameLabel.setBounds(32, 292, 107, 14);
		add(companyNameLabel);
		companyNameLabel.setVisible(false);
		
		companyName_tf = new JTextField();
		companyName_tf.setBounds(149, 289, 121, 20);
		add(companyName_tf);
		companyName_tf.setColumns(10);
		companyName_tf.setVisible(false);
		
		afterDiscountPriceLabel = new JLabel("After discount price:");
		afterDiscountPriceLabel.setForeground(Color.BLACK);
		afterDiscountPriceLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		afterDiscountPriceLabel.setBounds(32, 317, 126, 14);
		add(afterDiscountPriceLabel);
		afterDiscountPriceLabel.setVisible(false);
		
		afterDiscountPrice_tf = new JTextField();
		afterDiscountPrice_tf.setBounds(174, 314, 65, 20);
		add(afterDiscountPrice_tf);
		afterDiscountPrice_tf.setColumns(10);
		
		JLabel backgroundAddDeliveryFile = new JLabel("");
		backgroundAddDeliveryFile.setIcon(new ImageIcon(AddDeliveryFile.class.getResource("/ImagesPackage/Parcels-delivery--tojpeg_1452007184390_x2.jpg")));
		backgroundAddDeliveryFile.setBounds(0, -43, 558, 627);
		add(backgroundAddDeliveryFile);
		afterDiscountPrice_tf.setVisible(false);
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource() == addDeliveryButton)
		{
			Members tmpMember;
			Delivery tmpDelivery = null;
			double tmpPrice=0;
			double tmpAfterExpressPrice=0,tmpAfterDiscountPrice=0;
			Date tmpDate;
			String tmpMemberId,deliveryType,restOfCode,tmpCompanyName;
			try
			{
				/*empty field*/
				if(membersComboBox.getSelectedIndex() == 0 || kindOfDeliveryComboBox.getSelectedIndex() == 0
						|| deliveryCode_tf.getText().equals("") || price_tf.getText().equals(""))
					{
						throw new NullPointerException();
					}
				deliveryType = (String.valueOf(kindOfDeliveryComboBox.getSelectedItem())).substring(0, 1);
				restOfCode = deliveryCode_tf.getText();
				tmpDelivery = new Delivery(deliveryType + restOfCode);
				
				/*checking if the deliveryCode already exists*/
				if(tmpDelivery.whichManagerStrExists(tmpDelivery.getDeliveryCode()) != null)
				{
					throw new UserAlreadyExistsException();
				}
				
				tmpPrice = Double.parseDouble(price_tf.getText());
				if(tmpPrice < 0)
				{
					throw new NumberSmallerThenZeroException();
				}
				
				if(kindOfDeliveryComboBox.getSelectedIndex() == 2)//express
				{
					if(editor.getText().equals("") || expressAddition_tf.getText().equals(""))
					{
						throw new NullPointerException();
					}
					tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(editor.getText());
					tmpAfterExpressPrice = Double.parseDouble(expressAddition_tf.getText());
					if(tmpAfterExpressPrice < tmpPrice)
					{
						throw new SmallerThanPriceException();
					}
					tmpDelivery = new Express(deliveryType + restOfCode,tmpPrice,tmpDate,tmpAfterExpressPrice);
				}
				
				else if(kindOfDeliveryComboBox.getSelectedIndex() == 3)//Business
				{
					if(companyName_tf.getText().equals("") || afterDiscountPrice_tf.getText().equals(""))
					{
						throw new NullPointerException();
					}
					tmpCompanyName = companyName_tf.getText();
					tmpAfterDiscountPrice = Double.parseDouble(afterDiscountPrice_tf.getText());
					if(tmpAfterDiscountPrice > tmpPrice)
					{
						throw new BiggerThanPriceException();
					}
					
					tmpDelivery = new Business(deliveryType + restOfCode,tmpPrice,tmpCompanyName,tmpAfterDiscountPrice);
				}
				
				else//general
				{
					tmpDelivery = new Delivery(deliveryType + restOfCode,tmpPrice);
				}
				
				tmpMemberId = (String.valueOf(membersComboBox.getSelectedItem())).substring(0, 9);
				
				/*Adding the delivery to the whole fit DataBase structures*/
				
				tmpMember = new Members(tmpMemberId);
				
				DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember)).addDelivery(tmpDelivery);
				tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember));
				DataBase.ourLastDeliveries.put(tmpMember, tmpDelivery);
				DataBase.ourMembersAndDeliveries1.put(DataBase.countTree, tmpMember);
				DataBase.ourMembersAndDeliveries2.put(DataBase.countTree, tmpDelivery);
				DataBase.countTree += 5;
				
													/*same as the managing area of the current manager*/
				if(DataBase.RegularDeliveriesByAreasMap.containsKey(tmpMember.getLivingArea()))
				{
					DataBase.RegularDeliveriesByAreasMap.get(tmpMember.getLivingArea()).add(tmpDelivery);
				}
				else
				{
					ArrayList<Delivery>al = new ArrayList<Delivery>();
					al.add(tmpDelivery);
					DataBase.RegularDeliveriesByAreasMap.put(tmpMember.getLivingArea(), al);
				}
				JOptionPane.showMessageDialog(null, "The delivery code will be " + deliveryType + restOfCode);
				JOptionPane.showMessageDialog(null, "The delivery was added successfully");		
			}
			
			catch(UserAlreadyExistsException ex)
			{
				JOptionPane.showMessageDialog(null, "This delivery code already exists,please type another code");
			}
			catch(NumberFormatException ex)
			{
				JOptionPane.showMessageDialog(null, "Price must include only Double or Integer numbers");
			}
			catch(ParseException ex)
			{
				JOptionPane.showMessageDialog(null, "Can not convert date");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields is empty, please fill the whole fields");
			} 
			catch (NumberSmallerThenZeroException ex) 
			{
				JOptionPane.showMessageDialog(null, "Price can not be a negative number");
			} 
			catch (SmallerThanPriceException ex)
			{
				JOptionPane.showMessageDialog(null, "After express addition price can not be smaller than the initial price");
			}
			catch (BiggerThanPriceException ex)
			{
				JOptionPane.showMessageDialog(null, "Afte discount price can not be bigger than the initial price");
			}
			
		}
		
		if(e.getSource() == clearButton)
		{
			membersComboBox.setSelectedIndex(0);
			kindOfDeliveryComboBox.setSelectedIndex(0);
			deliveryCode_tf.setText("");
			price_tf.setText("");
			editor.setText("");
			expressAddition_tf.setText("");
			companyName_tf.setText("");
			afterDiscountPrice_tf.setText("");
		}	
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(kindOfDeliveryComboBox.getSelectedIndex() == 2)//Express
		{
			/*Business fields*/
			companyNameLabel.setVisible(false);
			companyName_tf.setVisible(false);
			afterDiscountPriceLabel.setVisible(false);
			afterDiscountPrice_tf.setVisible(false);
			
			/*Express fields*/
			deadLineLabel.setVisible(true);
			deadLineCalander.setVisible(true);
			expressAdditionPrice.setVisible(true);
			expressAddition_tf.setVisible(true);
		}
		else if(kindOfDeliveryComboBox.getSelectedIndex() == 3)//Business
		{
			/*Express Fields*/
			deadLineLabel.setVisible(false);
			deadLineCalander.setVisible(false);
			expressAdditionPrice.setVisible(false);
			expressAddition_tf.setVisible(false);
			
			/*Business Fields*/
			companyNameLabel.setVisible(true);
			companyName_tf.setVisible(true);
			afterDiscountPriceLabel.setVisible(true);
			afterDiscountPrice_tf.setVisible(true);
		}
		
		else
		{
			/*Express Fields*/
			deadLineLabel.setVisible(false);
			deadLineCalander.setVisible(false);
			expressAdditionPrice.setVisible(false);
			expressAddition_tf.setVisible(false);
			
			/*Business fields*/
			companyNameLabel.setVisible(false);
			companyName_tf.setVisible(false);
			afterDiscountPriceLabel.setVisible(false);
			afterDiscountPrice_tf.setVisible(false);
		}	
	}
}
