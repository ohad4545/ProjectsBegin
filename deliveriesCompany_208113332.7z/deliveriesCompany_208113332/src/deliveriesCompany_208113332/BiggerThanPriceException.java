package deliveriesCompany_208113332;

/*This exception is thrown when the after discount price is bigger than the initial price*/
public class BiggerThanPriceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*constructors*/
	public BiggerThanPriceException()
	{
		super();
	}
	
	public BiggerThanPriceException(String massage)
	{
		super(massage);
	}
	

}
