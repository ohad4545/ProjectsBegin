package deliveriesCompany_208113332;

public interface DeliveryMemberMethods {
	Manager  whichManagerStrExists(String str);
}
