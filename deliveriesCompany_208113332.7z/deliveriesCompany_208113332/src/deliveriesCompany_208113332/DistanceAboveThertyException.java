package deliveriesCompany_208113332;

/*This exception is thrown when the distance(when adding short delivery) is above 30 km*/
public class DistanceAboveThertyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*constructors*/
	public DistanceAboveThertyException() {
		super();
	}
	public DistanceAboveThertyException(String massage) {
		super(massage);
	}
}
