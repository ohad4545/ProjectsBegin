package deliveriesCompany_208113332;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class WholeShortDeliveriesByDateClass extends JFrame {

	public JTable table;
	public JScrollPane scroll;
	
	private BufferedReader reader;
	private StringReader linesReader;
	private String line;
	private Date tmpDate;
	private Date currentDeliveryDate;
	
	public WholeShortDeliveriesByDateClass(Date tmpDate) {

		try
		{
			this.tmpDate = tmpDate;
			this.setBackground(Color.WHITE);
			DataBase.writeToShortDeliveriesFile(); //for updating also the current running changes of this file
			String[] cols= {"Deliery code","price","Date arrived","Origin city","Destination city",
					"Distance","Price per km","member"};
			Object[][] data = new Object[DataBase.wholeShortDeliveries.size()][8];
			reader = new BufferedReader(new FileReader("src/ShortDeliveries.txt"));
			int ch = 0,row = 0;
			if(reader != null)
			{
				line = reader.readLine();
				linesReader = new StringReader(line);
				while(line != null && linesReader != null)
				{
					DataBase.readString(linesReader, ch);//code
					DataBase.readString(linesReader, ch);//price
					this.currentDeliveryDate = new SimpleDateFormat("dd/MM/yyyy").parse(DataBase.readString(linesReader, ch));
					linesReader.close();
					linesReader = new StringReader(line);
					if(this.tmpDate.getTime() - this.currentDeliveryDate.getTime() == 0)//same day
					{
						for(int col = 0;col < 8;col++)
						{
							data[row][col] = DataBase.readString(linesReader, ch);
						}
						row++;
					}
					linesReader.close();
					line = reader.readLine();
					if(line != null)
						linesReader = new StringReader(line);
				}
			}
			
			this.setBounds(0,10,800,500);
			setLayout(new BorderLayout());
					
			table = new JTable(data,cols);
			table.setBounds(10, 254, 414, -198);

			scroll = new JScrollPane(table);
			add(scroll,BorderLayout.CENTER);
			
			this.setBackground(Color.WHITE);
			this.setVisible(true);
			
			
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the reading of ShortDeliveries.txt file");
		}
		catch(ParseException ex)
		{
			System.out.println("Something went wrong with the date formating in reading of ShortDeliveries.txt file");
		}
		
		finally
		{
			try
			{
				if(reader != null) 
				{
					reader.close();
				}
				if(linesReader != null)
				{
					linesReader.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing one of the streams in ShortDeliveries.txt file");
			}
		}	
	}
}