package deliveriesCompany_208113332;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class WholeShortDeliveriesByDateClass extends JFrame {

	public JTable table;
	public JScrollPane scroll;
	
	private Date tmpDate;
	private Date currentDeliveryDate;
	
	public WholeShortDeliveriesByDateClass(Date tmpDate) {

		try
		{
			int row = 0;
			this.tmpDate = tmpDate;
			this.setBackground(Color.WHITE);
			DataBase.writeToShortDeliveriesFile(); //for updating also the current running changes of this file
			String[] cols= {"Deliery code","price","Date arrived","Origin city","Destination city",
					"Distance","Price per km","member"};
			Object[][] data = new Object[DataBase.wholeShortDeliveries.size()][8];
	
			File file = new File("src/ShortDeliveries.txt");
			Scanner scn = new Scanner(file);
			String line;
			String[] deliveryDetails;
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				deliveryDetails = line.split(" ");
				deliveryDetails[0] = deliveryDetails[0].substring(5);
				System.out.println();
				this.currentDeliveryDate = new SimpleDateFormat("dd/MM/yyyy").parse(deliveryDetails[2]);
				if(this.tmpDate.getTime() - this.currentDeliveryDate.getTime() == 0)//same day
				{
					for(int col = 0;col < 8;col++)
					{
						data[row][col] = deliveryDetails[col];
					}
					row++;
				}
			}
			scn.close();
			this.setBounds(0,10,800,500);
			setLayout(new BorderLayout());
					
			table = new JTable(data,cols);
			table.setBounds(10, 254, 414, -198);

			scroll = new JScrollPane(table);
			add(scroll,BorderLayout.CENTER);
			
			this.setBackground(Color.WHITE);
			this.setVisible(true);
				
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the reading of ShortDeliveries.txt file");
		}
		catch(ParseException ex)
		{
			System.out.println("Something went wrong with the date formating in reading of ShortDeliveries.txt file");
		}	
	}
}