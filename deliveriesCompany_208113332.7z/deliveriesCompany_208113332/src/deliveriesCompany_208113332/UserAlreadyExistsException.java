package deliveriesCompany_208113332;

/*This exception is thrown when an object from the class I try to create is already exists(has the same Unique property)(for example: two members with the same ID)*/
public class UserAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*constructors*/
	public UserAlreadyExistsException()
	{
		super();
	}
	public UserAlreadyExistsException(String massage)
	{
		super(massage);
	}
}
