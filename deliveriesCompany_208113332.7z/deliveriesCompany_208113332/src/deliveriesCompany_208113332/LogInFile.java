package deliveriesCompany_208113332;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LogInFile extends JFrame implements ActionListener{
	public JLabel title;
	public JLabel userNameLabel;
	public JTextField userName_tf;
	public JLabel passwordLabel;
	public JPasswordField password_tf;
	public JButton enterButton;
	
	public MenuFile menu;
	public MenuFileDeputyManager menuDeputyManager;
	public JLabel backgroundImage1;
	
	
	/*constructor*/
	public LogInFile(MenuFile menu,MenuFileDeputyManager menuDeputyManager) {
		
		this.menu = menu;
		this.menuDeputyManager = menuDeputyManager;
		
		final char apostrophes = '"';
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		title = new JLabel("Welcome to "+ apostrophes + "Deliveries For You" + apostrophes);
		title.setForeground(Color.darkGray);
		title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		title.setBounds(82, 11, 1000, 20);
		this.setLayout(null);
		this.add(title);
		
		userNameLabel = new JLabel("Username:");
		userNameLabel.setBounds(125,95,150,20);
		userNameLabel.setForeground(Color.darkGray);
		userNameLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
		this.add(userNameLabel);
		
		userName_tf = new JTextField();
		userName_tf.setBounds(250,90,130,30);
		this.add(userName_tf);
		
		passwordLabel = new JLabel("Password:");
		passwordLabel.setBounds(125,135,150,20);
		passwordLabel.setForeground(Color.darkGray);
		passwordLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
		this.add(passwordLabel);
		
		password_tf = new JPasswordField();
		password_tf.setBounds(250,130,130,30);
		this.add(password_tf);
		
		enterButton = new JButton("LogIn");
		enterButton.setBounds(195,190,105,30);
		enterButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/68839537.jpg")));
		enterButton.addActionListener(this);
		this.add(enterButton);
		
		this.setSize(570,340);
		this.backgroundImage1 = new JLabel("");
		this.backgroundImage1.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/CAMLOGIS-Deliveries-2.png")));
		this.backgroundImage1.setBounds(0,-350, 1200, 1000);
		this.add(backgroundImage1);
		this.setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == enterButton)
		{
			try
			{
				if(userName_tf != null && password_tf != null)
				{
					/*The user does not exist in the system*/
					if(DataBase.ManagerByUserName(userName_tf.getText()) == null ||
						!DataBase.ManagerByUserName(userName_tf.getText()).getPassword().equals(String.valueOf(password_tf.getPassword())))
					{
						throw new UnauthorizedException();
					}
				}
					this.setVisible(false);
					if(!(DataBase.ManagerByUserName(userName_tf.getText()) instanceof DeputyManager))
					{
						new MenuFile("Current user : " + 
						DataBase.ManagerByUserName(userName_tf.getText()).getFirstName() + " " +
						DataBase.ManagerByUserName(userName_tf.getText()).getLastName(),
						this,userName_tf.getText());
					}
					else
					{
						new MenuFileDeputyManager("Current user : " + 
								DataBase.ManagerByUserName(userName_tf.getText()).getFirstName() + " " +
								DataBase.ManagerByUserName(userName_tf.getText()).getLastName(),
								this,userName_tf.getText());
					}
				}
			
			catch(UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "Invalid userName or password, please type your details again");
			}
		}
}
}


