package deliveriesCompany_208113332;

/*This exception is thrown when the (add delivery) the express addition price is smaller than the initial price*/
public class SmallerThanPriceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*constructors*/
	public SmallerThanPriceException()
	{
		super();
	}
	public SmallerThanPriceException(String massage)
	{
		super(massage);
	}

}
