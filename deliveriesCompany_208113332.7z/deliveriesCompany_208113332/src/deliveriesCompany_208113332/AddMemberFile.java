package deliveriesCompany_208113332;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddMemberFile extends JPanel implements ActionListener{

	public JLabel title;
	public JButton addButton;
	public JButton clearButton;
	public JLabel idLabel;
	public JTextField id_tf;
	public JLabel firstNameLabel;
	public JTextField firstName_tf;
	public JLabel lastNameLabel;
	public JTextField lastName_tf;
	public JLabel livingAreaLabel;
	public JComboBox<String> livingAreaComboBox;
	public JLabel backgroundAddMember;
	
	
	private String currentUserName;
	
	public AddMemberFile(String currentUserName){
	this.currentUserName = currentUserName;
	this.setLayout(null);
	this.setBounds(0,10,400,500);
	
	title = new JLabel("Adding member file");
	title.setBounds(120,10,200,30);
	title.setForeground(Color.darkGray);
	title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
	this.add(title);
	
	idLabel = new JLabel("ID number:");
	idLabel.setBounds(50,50,100,20);
	idLabel.setForeground(Color.darkGray);
	idLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
	this.add(idLabel);
	
	id_tf = new JTextField();
	id_tf.setBounds(130,50,150,20);
	this.add(id_tf);
	
	firstNameLabel = new JLabel("First name:");
	firstNameLabel.setBounds(50,80,100,20);
	firstNameLabel.setForeground(Color.darkGray);
	firstNameLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
	this.add(firstNameLabel);
	
	firstName_tf = new JTextField();
	firstName_tf.setBounds(130,80,150,20);
	this.add(firstName_tf);
	
	lastNameLabel = new JLabel("Last name");
	lastNameLabel.setBounds(50,110,100,20);
	lastNameLabel.setForeground(Color.darkGray);
	lastNameLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
	this.add(lastNameLabel);
	
	lastName_tf = new JTextField();
	lastName_tf.setBounds(130,110,150,20);
	this.add(lastName_tf);
	
	livingAreaLabel = new JLabel("Living area");
	livingAreaLabel.setBounds(50,140,100,20);
	livingAreaLabel.setForeground(Color.darkGray);
	livingAreaLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
	this.add(livingAreaLabel);
	
	livingAreaComboBox = new JComboBox<String>();
	livingAreaComboBox.addItem("");
	livingAreaComboBox.addItem("north");
	livingAreaComboBox.addItem("center");
	livingAreaComboBox.addItem("south");
	livingAreaComboBox.setBounds(130,140,100,20);
	this.add(livingAreaComboBox);
	
	addButton = new JButton("Add member");
	addButton.setBounds(150,190,150,30);
	addButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
	addButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
	addButton.addActionListener(this);
	this.add(addButton);
	
	clearButton = new JButton("Clear");
	clearButton.setBounds(170,230,100,35);
	clearButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/edit_clear.png")));
	clearButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
	clearButton.addActionListener(this);
	this.add(clearButton);
	
	this.setSize(500,350);
	
	backgroundAddMember = new JLabel("");
	backgroundAddMember.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/Viessmann-Direct-Deliveries-dept_300x210.jpg")));
	backgroundAddMember.setBounds(73, 151, 522, 435);
	this.add(backgroundAddMember);
	
	this.setBackground(Color.WHITE);
	this.setVisible(true);
	
}

	@Override
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == addButton)
		{
			Members tmpMember = new Members(id_tf.getText());
			
			Manager tmpManager = DataBase.ManagerByUserName(this.currentUserName);
			try
			{
				/*empty field*/
				if(id_tf.getText().equals("") || firstName_tf.getText().equals("")
				   || lastName_tf.getText().equals("") || livingAreaComboBox.getSelectedIndex() == 0)
							{
								throw new NullPointerException();
							}
				
				/*invalid ID*/
				if(!tmpMember.isValidMemberId(tmpMember.getMemberId(), null))
				{
					throw new InvalidInputException();
				}
				
//				if(!DataBase.wholeManagersByUserName.get(this.currentUserName).getManagerArea().equals(String.valueOf(livingAreaComboBox.getSelectedItem())))
				/*Different member and manager area*/
				if(!tmpManager.getManagerArea().equals(String.valueOf(livingAreaComboBox.getSelectedItem())))
				{
					throw new InvalidLivingAreaException();
				}
				
				/*Member already exists*/
				if(DataBase.wholeManagersMembersList.contains(tmpMember))
				{
					throw new UserAlreadyExistsException();
				}

				
				tmpMember = new Members(id_tf.getText(),firstName_tf.getText(),lastName_tf.getText(),String.valueOf(livingAreaComboBox.getSelectedItem()));
				
				/*Adding the member to the fit DataBases*/
//				DataBase.managers.get(DataBase.managers.indexOf(DataBase.wholeManagersByUserName.get(this.currentUserName))).addMember(tmpMember);
//				DataBase.wholeManagersByUserName.get(this.currentUserName).addMember(tmpMember);
				DataBase.ManagerByUserName(this.currentUserName).addMember(tmpMember);
				DataBase.wholeManagersMembersList.add(tmpMember);
//				DataBase.wholeManagersMembersMap.put(tmpMember.getMemberId(),DataBase.wholeManagersByUserName.get(this.currentUserName));
				
				JOptionPane.showMessageDialog(null, "The member was added successfully");

			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields are empty, please fill the whole fields");
			} 
			catch (UserAlreadyExistsException ex)
			{
				/*the founded member is in another manager's list*/
				if(!tmpMember.whichManagerStrExists(tmpMember.getMemberId()).equals(DataBase.ManagerByUserName(this.currentUserName)))
				{
					JOptionPane.showMessageDialog(null, "This member already exists at the system");

				}
				else
				{
					int answer = JOptionPane.showConfirmDialog(null, "This member already in your members list, if you add another one with the same id, you will delete the previous member data, would you like to do that?","", JOptionPane.YES_NO_OPTION);
					if(answer == 0)//yes
					{
						tmpMember = new Members(id_tf.getText(),firstName_tf.getText(),lastName_tf.getText(),String.valueOf(livingAreaComboBox.getSelectedItem()));
						DataBase.ManagerByUserName(this.currentUserName).addMember(tmpMember);
						JOptionPane.showMessageDialog(null, "The member was added successfully");
					}
				}	
			}
			catch(InvalidInputException ex)
			{
				JOptionPane.showMessageDialog(null, "Invalid member Id, Id must include only and exactly 9 digits");
			} 
			catch (InvalidLivingAreaException ex)
			{
				JOptionPane.showMessageDialog(null, "Sorry, you can add members only from your managing area");
			}
		}
		
		if(e.getSource() == clearButton)
		{
			id_tf.setText("");
			firstName_tf.setText("");
			lastName_tf.setText("");
			livingAreaComboBox.setSelectedIndex(0);
		}
		
	}
}
