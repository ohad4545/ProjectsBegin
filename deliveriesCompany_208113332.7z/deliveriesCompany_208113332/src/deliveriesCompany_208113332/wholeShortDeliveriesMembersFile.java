package deliveriesCompany_208113332;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class wholeShortDeliveriesMembersFile extends JPanel{

	public JPanel panel1;
	public JPanel panel2;
	public JLabel massage; //These are the whole members details that have short deliveries
	public JTextArea textAreaMembersDetails;
	public JScrollPane jsp1;
	public JLabel background;
	
	private String textOfTheTextArea;
	private Members tmpMember;
	private int index;
	
	public wholeShortDeliveriesMembersFile(){
		
		this.textOfTheTextArea = "";
		
		/*Adding the whole members that have short deliveries*/
		for(String memberId:DataBase.shortDeliveriesByMemberId.keySet())
		{
			if(DataBase.shortDeliveriesByMemberId.get(memberId).size() > 0)
			{
				this.tmpMember = new Members(memberId);
				this.index = DataBase.wholeManagersMembersList.indexOf(this.tmpMember);
				this.textOfTheTextArea += DataBase.wholeManagersMembersList.get(this.index).toString() + "\n";
			}
		}
		
		this.setBounds(0,30,400,500);
		this.setBackground(Color.WHITE);
		panel1 = new JPanel(new FlowLayout());
		panel1.setBounds(30,200,400,50);
		panel1.setBackground(Color.WHITE);
		massage = new JLabel("These are the whole members details that have short deliveries:");
		massage.setBounds(30,50,200,20);
		massage.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		panel1.add(massage);
	
		this.add(panel1);		

		panel2 = new JPanel(new FlowLayout());
		panel2.setBounds(50,70,400,50);
		panel2.setBackground(Color.WHITE);
		textAreaMembersDetails = new JTextArea(8,40);
		textAreaMembersDetails.setEditable(false);
		textAreaMembersDetails.setText(this.textOfTheTextArea);
		jsp1 = new JScrollPane(textAreaMembersDetails);
		jsp1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		panel2.add(jsp1);
		this.add(panel2);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(AddShortDeliveryFile.class.getResource("/ImagesPackage/Firedog-Packages1.jpg")));
		background.setBounds(10, 120, 544, 291);
		add(background);
		
		this.setSize(500,500);
		this.setVisible(true);
	}
}
