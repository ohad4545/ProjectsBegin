package deliveriesCompany_208113332;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;



public class AddManagerFile extends JPanel implements ActionListener,ItemListener{

	public JLabel title;
	public JLabel message;
	public JLabel firstName;
	public JTextField firstName_tf;
	public JLabel lastName;
	public JTextField lastName_tf;
	public JLabel userName;
	public JTextField userName_tf;
	public JLabel password;
	public JPasswordField password_tf;
	public JLabel managingArea;
	public JComboBox<String> managingAreaComboBox;
	public JLabel kindOfManager;
	public JComboBox<String> kindOfManagerComboBox;
	public JButton addButton;
	public JButton clearButton;
	
	public JLabel amountDeputyManagerLabel;
	public JTextField amountDeputyManager_tf;
	public JLabel backgroundAddManagerFile;
	
	
	public AddManagerFile() {
		
		this.setLayout(null);
		this.setBounds(0,10,400,500);
		title = new JLabel("Adding manager file");
		title.setBounds(120,5,200,30);
		title.setForeground(Color.darkGray);
		title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
		this.add(title);
		
		firstName = new JLabel("First name:");
		firstName.setBounds(50,50,100,20);
		firstName.setForeground(Color.darkGray);
		firstName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(firstName);
		
		firstName_tf = new JTextField();
		firstName_tf.setBounds(130,50,150,20);
		this.add(firstName_tf);
		
		lastName = new JLabel("Last name:");
		lastName.setBounds(50,80,100,20);
		lastName.setForeground(Color.darkGray);
		lastName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(lastName);
		
		lastName_tf = new JTextField();
		lastName_tf.setBounds(130,80,150,20);
		this.add(lastName_tf);
		
		userName = new JLabel("User name:");
		userName.setBounds(50,110,100,20);
		userName.setForeground(Color.darkGray);
		userName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(userName);
		
		userName_tf = new JTextField();
		userName_tf.setBounds(130,110,150,20);
		this.add(userName_tf);
		
		password = new JLabel("Password:");
		password.setBounds(50,140,100,20);
		password.setForeground(Color.darkGray);
		password.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(password);
		
		password_tf = new JPasswordField();
		password_tf.setBounds(130,140,150,20);
		this.add(password_tf);
		
		managingArea = new JLabel("Managing area:");
		managingArea.setBounds(50,170,100,20);
		managingArea.setForeground(Color.darkGray);
		managingArea.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(managingArea);
		
		managingAreaComboBox = new JComboBox<String>();
		managingAreaComboBox.setBounds(150,170,100,20);
		managingAreaComboBox.addItem("");
		managingAreaComboBox.addItem("north");
		managingAreaComboBox.addItem("center");
		managingAreaComboBox.addItem("south");
		this.add(managingAreaComboBox);
		
		kindOfManager = new JLabel("What kind of manager will be added:");
		kindOfManager.setBounds(50,200,250,20);
		kindOfManager.setForeground(Color.darkGray);
		kindOfManager.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(kindOfManager);
		
		kindOfManagerComboBox = new JComboBox<String>();
		kindOfManagerComboBox.setBounds(270,200,120,20);
		kindOfManagerComboBox.addItem("");
		kindOfManagerComboBox.addItem("Main manager");
		kindOfManagerComboBox.addItem("Deputy manager");
		kindOfManagerComboBox.addItemListener(this);
		this.add(kindOfManagerComboBox);
		
		
		amountDeputyManagerLabel = new JLabel("Amount of deliveries can take care: ");
		amountDeputyManagerLabel.setBounds(50,230,250,20);
		amountDeputyManagerLabel.setForeground(Color.darkGray);
		amountDeputyManagerLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		this.add(amountDeputyManagerLabel);
		
		amountDeputyManager_tf = new JTextField();
		amountDeputyManager_tf.setBounds(270,230,50,20);
		this.add(amountDeputyManager_tf);
		amountDeputyManagerLabel.setVisible(false);
		amountDeputyManager_tf.setVisible(false);
		
		
		addButton = new JButton("Add manager");
		addButton.setBounds(150,280,150,30);
		addButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/add.png")));
		addButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		addButton.addActionListener(this);
		this.add(addButton);
		
		clearButton = new JButton("Clear");
		clearButton.setBounds(150,320,150,35);
		clearButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/edit_clear.png")));
		clearButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		clearButton.addActionListener(this);
		this.add(clearButton);
		
		this.setSize(500,400);
		
		backgroundAddManagerFile = new JLabel("");
		backgroundAddManagerFile.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/616-6169200_supervised-distribution-team-project-manager-icon-hd-png.png")));
		backgroundAddManagerFile.setBounds(-172, -35, 672, 724);
		add(backgroundAddManagerFile);
		
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == addButton)
		{
			try
			{
				int tmpAmountDeputyManager=0;
				String tmpUserName = userName_tf.getText();
				String tmpPassword = String.copyValueOf(password_tf.getPassword());
				Manager tmpManager = new Manager(tmpUserName);
				DeputyManager tmpDeputyManager;
				
				/*empty field*/
				if(firstName_tf.getText().equals("") || lastName_tf.getText().equals("") ||
				   userName_tf.getText().equals("") ||(String.valueOf(password_tf.getPassword())).equals("")
				  || managingAreaComboBox.getSelectedIndex() == 0 ||
				   kindOfManagerComboBox.getSelectedIndex() == 0)
				{
					throw new NullPointerException();
				}
				
				if(kindOfManagerComboBox.getSelectedIndex() == 2)//Deputy manager
				{
					if(amountDeputyManager_tf.getText().equals(""))
						throw new NullPointerException();
					
					tmpAmountDeputyManager = Integer.parseInt(amountDeputyManager_tf.getText());
					
				}
				
				/*There is a manager by the same userName(Assume in Manager Class)*/
//				if(DataBase.wholeManagersByUserName.containsKey(tmpManager.getUserName())) 
				if(DataBase.ManagerByUserName(tmpUserName) != null)
				{
					throw new UserAlreadyExistsException();
				}
				
				/*Adding to the fit array list*/
				if(kindOfManagerComboBox.getSelectedIndex() == 1) /*main manager*/
				{
					tmpManager = new Manager(tmpUserName, tmpPassword,
							String.valueOf(managingAreaComboBox.getSelectedItem()),
							firstName_tf.getText(),lastName_tf.getText());
					
					DataBase.managers.add(tmpManager);
//					DataBase.wholeManagersByUserName.put(tmpManager.getUserName(),tmpManager);
				}
				if(kindOfManagerComboBox.getSelectedIndex() == 2)/*deputy manager*/
				{
					tmpDeputyManager = new DeputyManager(tmpUserName, tmpPassword,
							String.valueOf(managingAreaComboBox.getSelectedItem()),
							firstName_tf.getText(),lastName_tf.getText(),tmpAmountDeputyManager);
					DataBase.deputyManagers.add(tmpDeputyManager);
//					DataBase.wholeManagersByUserName.put(tmpDeputyManager.getUserName(),tmpDeputyManager);
				}
				JOptionPane.showMessageDialog(null, "The Manager was added successfully");
			}
			
			catch(UserAlreadyExistsException ex)
			{
				JOptionPane.showMessageDialog(null, "The Manager already exists at the system, please choose another userName");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields are empty, please fill the whole fields");
			}
			catch(NumberFormatException ex)
			{
				JOptionPane.showMessageDialog(null, "Amount of deputy manager must be an integer number");
			}
		
		}
		
		if(e.getSource() == clearButton)
		{
			firstName_tf.setText("");
			lastName_tf.setText("");
			userName_tf.setText("");
			password_tf.setText("");
			managingAreaComboBox.setSelectedIndex(0);;
			kindOfManagerComboBox.setSelectedIndex(0);
			amountDeputyManager_tf.setText("");
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		
		if(kindOfManagerComboBox.getSelectedIndex() == 2)//Deputy manager
		{
			amountDeputyManagerLabel.setVisible(true);
			amountDeputyManager_tf.setVisible(true);
		}
		else
		{
			amountDeputyManagerLabel.setVisible(false);
			amountDeputyManager_tf.setVisible(false);
		}
		
	}
}
