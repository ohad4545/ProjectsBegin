package deliveriesCompany_208113332;

/*This exception is thrown when a number that the user typed can not be negative(for example:price,distance)*/
public class NumberSmallerThenZeroException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*constructors*/
	public NumberSmallerThenZeroException() {
		super();
	}
	public NumberSmallerThenZeroException(String massage) {
		super(massage);
	}
}
