package deliveriesCompany_208113332;

import java.util.Date;
import java.util.Iterator;

public class ShortDelivery extends Delivery{

	private Date dateArrived;
	private String originCity;
	private String destinationCity;
	private int distance;
	private double pricePerKm;//I assumed that when a deputy manager adds a short delivery, the pricePerKm will be calculated automatically by price(father property) and distance
	private Members member;
	
	/*constructor*/
	public ShortDelivery(String deliveryCode,double price,Date dateArrived, String originCity,
						 String destinationCity, int distance,double pricePerKm, Members member) {
		super(deliveryCode,price);
		this.dateArrived = dateArrived;
		this.originCity = originCity;
		this.destinationCity = destinationCity;
		this.distance = distance;
		this.pricePerKm = pricePerKm;
		this.member = member;
	}
	
	/*This function returns the deputyManager that has a delivery that equals to the deliveryCode the function gets*/
	/*if the deliveryCode is not found ,the function returns null*/
	@Override
	public Manager whichManagerStrExists(String deliveryCode) {
		if(deliveryCode == null)
		{
			return null;
		}	
		DeputyManager tmpDeputyManager;
		ShortDelivery tmpShortDelivery;
		Iterator<DeputyManager> itr1= DataBase.deputyManagers.iterator();
		while(itr1.hasNext())
		{
			 tmpDeputyManager = itr1.next();
			 Iterator<ShortDelivery> itr2 = tmpDeputyManager.getShortDeliveriesList().iterator();
			 while(itr2.hasNext())
			 {
				 tmpShortDelivery = itr2.next();
				 if(tmpShortDelivery.getDeliveryCode().equals(deliveryCode))
				 {
					 return tmpDeputyManager;
				 }
			 }
		}
		return null;	
	}

	/*Getters and Setters*/
	public String getOriginCity() {
		return originCity;
	}

	public void setOriginCity(String originCity) {
		if(originCity != null)
			this.originCity = originCity;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		if(destinationCity != null)
			this.destinationCity = destinationCity;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public double getPricePerKm() {
		return pricePerKm;
	}

	public void setPricePerKm(double pricePerKm) {
		this.pricePerKm = pricePerKm;
	}

	public Members getMember() {
		return member;
	}

	public void setMember(Members member) {
		if(member != null)
			this.member = member;
	}

	public Date getDateArrived() {
		return dateArrived;
	}

	public void setDateArrived(Date dateArrived) {
		this.dateArrived = dateArrived;
	}

	/*toString function*/
	@Override
	public String toString() {
		return super.toString() + "ShortDelivery [dateArrived=" + dateArrived + ", originCity=" + originCity + ", destinationCity="
				+ destinationCity + ", distance=" + distance + ", pricePerKm=" + pricePerKm + ", member=" + member.getMemberId()
				+ "]";
	}
}
