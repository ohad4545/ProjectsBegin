package deliveriesCompany_208113332;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class WholeShortDeliveriesJTbaleFile extends JPanel {

	public JTable table;
	public JScrollPane scroll;
	
	public WholeShortDeliveriesJTbaleFile() {
		this.setBackground(Color.WHITE);
		
		String[] cols= {"Deliery code","price","Date arrived","Origin city","Destination city",
				"Distance","Price per km","member"};
		Object[] shortDeliveriessArray = DataBase.wholeShortDeliveries.toArray();
		Object[][] data = new Object[shortDeliveriessArray.length][8];
		int index;
		
		/*inserting the data in the data 2D array*/
		for(index = 0;index < shortDeliveriessArray.length;index++)
		{
			data[index][0] = ((ShortDelivery)shortDeliveriessArray[index]).getDeliveryCode();
			data[index][1] = ((ShortDelivery)shortDeliveriessArray[index]).getPrice();
			data[index][2] = ((ShortDelivery)shortDeliveriessArray[index]).getDateArrived();
			data[index][3] = ((ShortDelivery)shortDeliveriessArray[index]).getOriginCity();
			data[index][4] = ((ShortDelivery)shortDeliveriessArray[index]).getDestinationCity();
			data[index][5] = ((ShortDelivery)shortDeliveriessArray[index]).getDistance();
			data[index][6] = ((ShortDelivery)shortDeliveriessArray[index]).getPricePerKm();
			data[index][7] = ((ShortDelivery)shortDeliveriessArray[index]).getMember().getMemberId();
		}
		this.setBounds(0,10,400,500);
		setLayout(new BorderLayout());
				
		table = new JTable(data,cols);
		table.setBounds(10, 254, 414, -198);

		scroll = new JScrollPane(table);
		add(scroll,BorderLayout.CENTER);
		
		this.setBackground(Color.WHITE);
		this.setVisible(true);
	}

}

