package deliveriesCompany_208113332;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class WholeDeliveriesByIdClass extends JFrame {

	public JTable table;
	public JScrollPane scroll;
	
	private BufferedReader reader;
	private StringReader linesReader;
	private String line;
	private Members tmpMember;
	
	public WholeDeliveriesByIdClass(Members tmpMember) {

		try
		{
			this.tmpMember = tmpMember;
			this.setBackground(Color.WHITE);
			DataBase.writeToWholeMembersFile(); //for updating also the current running changes of this file
			String[] cols= {"Deliery code","price","DeadLine date","After express price","Company name","After discount price","Date arrived","Origin city","Destination city",
					"Distance","Price per km","member"};
			Object[][] data = new Object[this.tmpMember.getDeliveries().size()][12];
			reader = new BufferedReader(new FileReader("src/WholeMembers.txt"));
			int ch = 0,row = 0;
			if(reader != null)
			{
				line = reader.readLine();
				linesReader = new StringReader(line);
				while(line != null && linesReader != null)
				{
					if(DataBase.readString(linesReader, ch).equals(this.tmpMember.getMemberId()))//the current line describes the member the user inserted its Id
					{
						for(int detailsNum = 1;detailsNum <=3;detailsNum++)
						{
							DataBase.readString(linesReader, ch);//member details besides of Id and deliveries
						}
						
						while(linesReader.read() != -1)
						{
							data[row][0] = DataBase.readString(linesReader, ch).substring(4);//code
							data[row][1] = DataBase.readString(linesReader, ch);//price
							
							/*To initialize the rest of the details which are not common to whole types of deliveries*/
							for(int col=2;col<12;col++)
							{
								data[row][col] = "";
							}
							
							if(String.valueOf(data[row][0]).startsWith("E"))//Express
							{
								/*Express properties columns*/
								data[row][2] = DataBase.readString(linesReader, ch);//DeadLine date
								data[row][3] = DataBase.readString(linesReader, ch);//After express addition price
							}
							
							else if(String.valueOf(data[row][0]).startsWith("B"))//Business
							{
								/*Business properties columns*/
								data[row][4] = DataBase.readString(linesReader, ch);//company name
								data[row][5] = DataBase.readString(linesReader, ch);//After discount price
							}
							
							else if(String.valueOf(data[row][0]).startsWith("S"))//Short
							{
								/*Short delivery properties columns*/
								data[row][6] = DataBase.readString(linesReader, ch);//Date arrived
								data[row][7] = DataBase.readString(linesReader, ch);//origin city
								data[row][8] = DataBase.readString(linesReader, ch);//destination city
								data[row][9] = DataBase.readString(linesReader, ch);//distance
								data[row][10] = DataBase.readString(linesReader, ch);//price per km
								data[row][11] = DataBase.readString(linesReader, ch);//member
							}
							row++;
						}	
					}
					
					linesReader.close();
					line = reader.readLine();
					if(line != null)
						linesReader = new StringReader(line);
				}
			}
			
			this.setBounds(0,10,1300,500);
			setLayout(new BorderLayout());
					
			table = new JTable(data,cols);
			table.setBounds(10, 254, 414, -198);

			scroll = new JScrollPane(table);
			add(scroll,BorderLayout.CENTER);
			
			this.setBackground(Color.WHITE);
			this.setVisible(true);		
		}
		
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the reading of WholeMembers.txt file");
		}
		
		finally
		{
			try
			{
				if(reader != null) 
				{
					reader.close();
				}
				if(linesReader != null)
				{
					linesReader.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing one of the streams in WholeMembers.txt file");
			}
		}	
	}
}