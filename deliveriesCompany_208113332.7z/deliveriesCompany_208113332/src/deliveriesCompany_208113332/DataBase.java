/*This is a class with static values and functions that meant for keeping the whole database of the deliveries company*/
package deliveriesCompany_208113332;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
//import java.util.Map.Entry;
import java.util.TreeMap;



public class DataBase {
	public static Integer countTree = 100;
	

	public static ArrayList<Members> wholeManagersMembersList = new ArrayList<Members>();
	
						 /*Area*/
	public static HashMap<String,ArrayList<Delivery>> RegularDeliveriesByAreasMap = new HashMap<String,ArrayList<Delivery>>();
	
	public static ArrayList<ShortDelivery> wholeShortDeliveries = new ArrayList<ShortDelivery>();
	public static HashMap<String,ArrayList<ShortDelivery>> shortDeliveriesByMemberId = new HashMap<String,ArrayList<ShortDelivery>>();
					    //memberId
							
	public static ArrayList<Manager> managers = new ArrayList<Manager>(); 
	public static ArrayList<DeputyManager> deputyManagers = new ArrayList<DeputyManager>();
	
	public static Map<Members,Delivery> ourLastDeliveries = new TreeMap<Members,Delivery>();
	public static Map<Integer,Members> ourMembersAndDeliveries1 = new TreeMap<Integer,Members>();
	public static Map<Integer,Delivery> ourMembersAndDeliveries2 = new TreeMap<Integer,Delivery>();
	
	
	/*Functions*/
	
	/*This function builds the ArrayList of the managers*/
	public static void createManagersList()
	{
										 /*userNames*//*Passwords*/
		DataBase.managers.add(new Manager("adminNorth","adminNorth","north","Avi","Cohen"));
		DataBase.managers.add(new Manager("adminCenter","adminCenter","center","Moshe","Levi"));
		DataBase.managers.add(new Manager("adminSouth","adminSouth","south","George","Jackson"));
	}
	
	/*This function restores the whole information that was added, deleted or changed since the last running of the program*/
	/*Beside of outLastMembersAndDeliveries1,2*/
	public static void restoreInfo()
	{
		BufferedReader mainManagersFileReader = null;
		StringReader linesReader = null;
		String line,tmpUserName,tmpPassword,tmpManagingArea,tmpFirstName,tmpLastName;
		Manager tmpManager;
		Members tmpMember;
		String tmpMemberId,tmpLivingArea;
		String tmpDeliveryCode;
		int ch = 0,tmpDistance;
		double tmpPrice,tmpAfterExpressPrice,tmpAfterDiscountPrice,tmpPricePerKm;
		Delivery tmpDelivery = null;
		Date tmpDate;
		String tmpCompanyName;
		String tmpOriginCity,tmpDestinationCity;
		Members tmpMember2;
		try
		{
			mainManagersFileReader = new BufferedReader(new FileReader("src/MainManagers.txt"));
			if(mainManagersFileReader != null)
			{
				line = mainManagersFileReader.readLine();
				if(line == null)
				{
					return;
				}
				
				/*starting the adding from the second line*/
				while((line = mainManagersFileReader.readLine()) != null)
				{
					linesReader = new StringReader(line);
					
					/*Details of the managers except for members*/
					tmpUserName = readString(linesReader,ch);
					tmpPassword = readString(linesReader,ch);
					tmpManagingArea = readString(linesReader,ch);
					tmpFirstName = readString(linesReader,ch);
					tmpLastName = readString(linesReader,ch);
					tmpManager = new Manager(tmpUserName, tmpPassword, tmpManagingArea,tmpFirstName,tmpLastName);
					
					ch = linesReader.read(); // reads space or -1
					
//					if(ch == -1)//if the manager has no members
//					{
//						DataBase.managers.add(tmpManager);
//					}
					
					/*If the manager has members, it now reads the 'I' character of ID String that is written in the file*/
					while(ch == 'I') 
					{
						/*manager's members*/
						for(int numberOfNotesToRead = 1;numberOfNotesToRead <= 2;numberOfNotesToRead++)
						{
							ch = linesReader.read();//Now it reads "D:" (if I contact the whole 2 iterations)
						}
						tmpMemberId = readString(linesReader,ch);
						tmpFirstName = readString(linesReader,ch);
						tmpLastName = readString(linesReader,ch);
						tmpLivingArea = readString(linesReader,ch);
						tmpMember = new Members(tmpMemberId, tmpFirstName, tmpLastName, tmpLivingArea);
						
						ch = linesReader.read();
//						if(ch == -1)//the member has no deliveries
//						{
//							tmpManager.getManagerMembers().put(tmpMemberId, tmpMember);
//							DataBase.managers.add(tmpManager);
//						}
						while(ch == 'C')//the member has deliveries,read the 'C' character of the word "Code:"
						{
							for(int numberOfNotesToRead = 1;numberOfNotesToRead <= 4;numberOfNotesToRead++)
							{
								ch = linesReader.read();//Now it reads "ode:" (if I contact the whole 4 iterations)
							}
							tmpDeliveryCode = readString(linesReader,ch);
							tmpPrice = Double.parseDouble(readString(linesReader,ch));
							if(tmpDeliveryCode.startsWith("G"))//General delivery
							{
								tmpDelivery = new Delivery(tmpDeliveryCode,tmpPrice);
							}
							else if(tmpDeliveryCode.startsWith("E"))//Express Delivery
							{
								tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(readString(linesReader,ch));
								tmpAfterExpressPrice = Double.parseDouble(readString(linesReader,ch));
								tmpDelivery = new Express(tmpDeliveryCode,tmpPrice,tmpDate,tmpAfterExpressPrice);
							}
							else if(tmpDeliveryCode.startsWith("B"))//Business Delivery
							{
								tmpCompanyName = readString(linesReader,ch);
								tmpAfterDiscountPrice = Double.parseDouble(readString(linesReader,ch));
								tmpDelivery = new Business(tmpDeliveryCode,tmpPrice,tmpCompanyName,tmpAfterDiscountPrice);
							}
							else if(tmpDeliveryCode.startsWith("S"))//Short Delivery
							{
								tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(readString(linesReader,ch));
								tmpOriginCity = readString(linesReader,ch);
								tmpDestinationCity = readString(linesReader,ch);
								tmpDistance = Integer.parseInt(readString(linesReader,ch));
								tmpPricePerKm = Double.parseDouble(readString(linesReader,ch));
								tmpMember2 = new Members(readString(linesReader,ch));
								tmpDelivery = new ShortDelivery(tmpDeliveryCode,tmpPrice,tmpDate,tmpOriginCity,
						        tmpDestinationCity, tmpDistance,tmpPricePerKm,tmpMember2);
								
								DataBase.wholeShortDeliveries.add((ShortDelivery)tmpDelivery);
								
								if(DataBase.shortDeliveriesByMemberId.containsKey(tmpMemberId))
								{
									DataBase.shortDeliveriesByMemberId.get(tmpMemberId).add((ShortDelivery)tmpDelivery);
								}
								else
								{
									ArrayList<ShortDelivery> al = new ArrayList<ShortDelivery>();
									al.add((ShortDelivery)tmpDelivery);
									DataBase.shortDeliveriesByMemberId.put(tmpMemberId, al);
								}
							}
							
							/*I assumed that a regular delivery is any delivery which is not a short delivery*/
							if(!tmpDeliveryCode.startsWith("S"))//Regular delivery
							{
								if(DataBase.RegularDeliveriesByAreasMap.containsKey(tmpManager.getManagerArea()))
								{
									DataBase.RegularDeliveriesByAreasMap.get(tmpManager.getManagerArea()).add(tmpDelivery);
								}
								else
								{
									ArrayList<Delivery> al = new ArrayList<Delivery>();
									al.add(tmpDelivery);
									DataBase.RegularDeliveriesByAreasMap.put(tmpManager.getManagerArea(), al);
								}
							}
							tmpMember.addDelivery(tmpDelivery);	
							DataBase.ourLastDeliveries.put(tmpMember, tmpDelivery);
//							DataBase.ourMembersAndDeliveries1.put(DataBase.countTree, tmpMember);
//							DataBase.ourMembersAndDeliveries2.put(DataBase.countTree, tmpDelivery);
//							DataBase.countTree += 5;
							ch = linesReader.read();
						}
						tmpManager.addMember(tmpMember);
						DataBase.wholeManagersMembersList.add(tmpMember);
					}
					DataBase.managers.add(tmpManager);
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the opening of MainManagers.txt file");
		}
		catch(NumberFormatException ex)
		{
			System.out.println("Somthing went wrong with the formating of the one of the numbers types(one of the prices or distance) in MainMangers.txt file");
		}
		catch (ParseException ex)
		{
			System.out.println("Somthing went wrong with the fromating of date in MainManagers.txt file");
		}
		finally
		{
			if(linesReader != null)
			{
				linesReader.close();
			}
			if(mainManagersFileReader != null)
			{
				try
				{
					mainManagersFileReader.close();
				}
				catch (IOException ex)
				{
					System.out.println("somthing went wrong with the closing of the bufferedReader of MainMangers.txt file");
				}
			}
		}
	}
	
	/*This function restores the whole most updated information about the ourMembersAndDeliveries1,2 TreeMaps*/
	public static void restoreDeliveriesOneAndTwo()
	{
		BufferedReader reader = null;
		String line;
		StringReader linesReader = null;
		int ch = 0,tmpDistance;
		String tmpMemberId,tmpDeliveryCode,tmpCompanyName,tmpOriginCity,tmpDestinationCity;
		Members tmpMember,tmpMember2;
		double tmpPrice,tmpAfterExpressPrice,tmpAfterDiscountPrice,tmpPricePerKm;
		Date tmpDate;
		Delivery tmpDelivery = null;
		
		try
		{
			reader = new BufferedReader(new FileReader("src/ourMembersAndDeliveries1And2.txt"));
			if(reader != null)
			{
				line = reader.readLine();
				linesReader = new StringReader(line);
				while(line != null && linesReader != null)
				{
					linesReader.close();
					linesReader = new StringReader(line);
					DataBase.countTree = Integer.parseInt(readString(linesReader,ch));
					tmpMemberId = readString(linesReader,ch);
					tmpMember = new Members(tmpMemberId);
					tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember));
					
					/*Next line (The number of lines must be even)*/
					line = reader.readLine();
					linesReader.close();
					linesReader = new StringReader(line);
					if(line == null)
					{
						return;
					}
					else if(line != null)
					{
						readString(linesReader,ch);
						tmpDeliveryCode = readString(linesReader,ch);
						tmpPrice = Double.parseDouble(readString(linesReader,ch));
						
						if(tmpDeliveryCode.startsWith("G"))//General delivery
						{
							tmpDelivery = new Delivery(tmpDeliveryCode,tmpPrice);
						}
						else if(tmpDeliveryCode.startsWith("E"))//Express Delivery
						{
							tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(readString(linesReader,ch));
							tmpAfterExpressPrice = Double.parseDouble(readString(linesReader,ch));
							tmpDelivery = new Express(tmpDeliveryCode,tmpPrice,tmpDate,tmpAfterExpressPrice);
						}
						else if(tmpDeliveryCode.startsWith("B"))//Business Delivery
						{
							tmpCompanyName = readString(linesReader,ch);
							tmpAfterDiscountPrice = Double.parseDouble(readString(linesReader,ch));
							tmpDelivery = new Business(tmpDeliveryCode,tmpPrice,tmpCompanyName,tmpAfterDiscountPrice);
						}
						else if(tmpDeliveryCode.startsWith("S"))//Short Delivery
						{
							tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(readString(linesReader,ch));
							tmpOriginCity = readString(linesReader,ch);
							tmpDestinationCity = readString(linesReader,ch);
							tmpDistance = Integer.parseInt(readString(linesReader,ch));
							tmpPricePerKm = Double.parseDouble(readString(linesReader,ch));
							tmpMember2 = new Members(readString(linesReader,ch));
							tmpDelivery = new ShortDelivery(tmpDeliveryCode,tmpPrice,tmpDate,tmpOriginCity,
					        tmpDestinationCity, tmpDistance,tmpPricePerKm,tmpMember2);
						}
						
						/*Adding to ourMembersAndDeliveries1,2 TreeMaps*/
						DataBase.ourMembersAndDeliveries1.put(DataBase.countTree, tmpMember);
						DataBase.ourMembersAndDeliveries2.put(DataBase.countTree, tmpDelivery);
						line = reader.readLine();
					}
				}
				DataBase.countTree += 5;
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with openning the ourMembersAndDeliveries1,2 file");
		}
		catch(NumberFormatException ex)
		{
			System.out.println("Somthing went wrong with the Number format in ourMembersAndDeliveries1,2 file");
		} 
		catch (ParseException ex) 
		{
			System.out.println("Somthing went wrong with the formating of the date in ourMembersAndDeliveries1,2 file");
		}
		finally
		{
			if(linesReader != null)
			{
				linesReader.close();
			}
			if(reader != null)
			{
				try
				{
					reader.close();
				}
				catch (IOException ex)
				{
					System.out.println("somthing went wrong with the closing of the bufferedReader in ourMembersAndDeliveries1,2 file");
				}
			}
		}
	}
	
	/*This function restores the whole most updated information about the DeputyManagers*/
	public static void restoreDeputyManagers()
	{
		BufferedReader reader = null;
		StringReader linesReader = null;
		String line;
		String tmpUserName,tmpPassword,tmpManagingArea,tmpFirstName,tmpLastName,tmpOriginCity,tmpDestinationCity;
		String tmpDeliveryCode;
		DeputyManager tmpDeputyManager;
		int ch = 0,tmpAmountDeliveriesCanTakeCare,tmpDistance;
		double tmpPrice,tmpPricePerKm;
		Date tmpDate;
		Members tmpMember;
		ShortDelivery tmpShortDelivery;
		
		try
		{
			reader = new BufferedReader(new FileReader("src/DeputyManagers.txt"));
			if(reader != null)
			{
				while((line = reader.readLine()) != null)
				{
					linesReader = new StringReader(line);
						
					/*Details of the deputy manager*/
					tmpUserName = readString(linesReader,ch);
					tmpPassword = readString(linesReader,ch);
					tmpManagingArea = readString(linesReader,ch);
					tmpFirstName = readString(linesReader,ch);
					tmpLastName = readString(linesReader,ch);
					tmpAmountDeliveriesCanTakeCare = Integer.parseInt(readString(linesReader,ch));
					tmpDeputyManager = new DeputyManager(tmpUserName, tmpPassword, tmpManagingArea,tmpFirstName,tmpLastName,tmpAmountDeliveriesCanTakeCare);
					
					ch = linesReader.read();
					/*adding Short deliveries*/
					
					while(ch == 'C')//reads the 'C' character of the word "Code:"
					{
						for(int numberOfNotesToRead = 1;numberOfNotesToRead <= 4;numberOfNotesToRead++)
						{
							ch = linesReader.read();//Now it reads "ode:" (if I contact the whole 4 iterations)
						}
						tmpDeliveryCode = readString(linesReader,ch);
						tmpPrice = Double.parseDouble(readString(linesReader,ch));
						tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(readString(linesReader,ch));
						tmpOriginCity = readString(linesReader,ch);
						tmpDestinationCity = readString(linesReader,ch);
						tmpDistance = Integer.parseInt(readString(linesReader,ch));
						tmpPricePerKm = Double.parseDouble(readString(linesReader,ch));
						tmpMember = new Members(readString(linesReader,ch));
						tmpShortDelivery = new ShortDelivery(tmpDeliveryCode,tmpPrice,tmpDate,tmpOriginCity,
						tmpDestinationCity, tmpDistance,tmpPricePerKm,tmpMember);
						
						tmpDeputyManager.getShortDeliveriesList().add(tmpShortDelivery);
						ch = linesReader.read();
					}
					
					DataBase.deputyManagers.add(tmpDeputyManager);
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of DeputyManagers.txt file");
		} 
		catch (ParseException ex) 
		{
			System.out.println("Somthing went wrong with the date formating in DeputyManagers.txt file");
		}
		catch(NumberFormatException ex)
		{
			System.out.println("Somthing went wrong with the Number Format in deputy managers file for reading");
		}
		finally
		{
			if(linesReader != null)
			{
				linesReader.close();
			}
			if(reader != null)
			{
				try
				{
					reader.close();
				}
				catch (IOException ex)
				{
					System.out.println("somthing went wrong with the closing of the bufferedReader in DeputyManagers.txt file");
				}
			}
		}
	}
	
	/*This function writes The whole members details to WholeMembers.txt file*/
	public static void writeToWholeMembersFile()
	{
		BufferedWriter writer = null;
		String tmpMemberDetails="",tmpMemberDeliveriesDetails="",tmpStringDate;
		Members tmpMember;
		Delivery tmpDelivery;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/WholeMembers.txt"));
			Iterator<Members> itr = DataBase.wholeManagersMembersList.iterator();
			while(itr.hasNext())
			{
				tmpMember = itr.next();
				tmpMemberDetails = tmpMember.getMemberId() + " " + tmpMember.getFirstName().replace(' ', '-') + " "
						 + tmpMember.getLastName().replace(' ', '-') + " " + tmpMember.getLivingArea() + " ";
				
				Iterator<Delivery> itr2 = tmpMember.getDeliveries().iterator();
				while(itr2.hasNext())
				{
					tmpDelivery = itr2.next();
					tmpMemberDeliveriesDetails += "Code:";//Code: is written and then the code of the tmpDelivery with no space(comment for me)
					tmpMemberDeliveriesDetails += tmpDelivery.getDeliveryCode() + " " + tmpDelivery.getPrice() + " ";
					
					if(tmpDelivery.getDeliveryCode().startsWith("E"))//Express
					{
						tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((Express)tmpDelivery).getDeadlineArriveDate());
						tmpMemberDeliveriesDetails += tmpStringDate + " " + String.valueOf(((Express)tmpDelivery).getAfterExpressAdditionPrice()) + " ";		
					}
					
					else if(tmpDelivery.getDeliveryCode().startsWith("B"))//Business
					{
						tmpMemberDeliveriesDetails += ((Business)tmpDelivery).getCompanyName() + " " 
						+ String.valueOf(((Business)tmpDelivery).getAfterDiscountPrice()) + " ";
					}
					
					else if(tmpDelivery.getDeliveryCode().startsWith("S"))//Short
					{
						tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((ShortDelivery)tmpDelivery).getDateArrived());
						tmpMemberDeliveriesDetails += tmpStringDate + " " + ((ShortDelivery)tmpDelivery).getOriginCity()
						+ " " + ((ShortDelivery)tmpDelivery).getDestinationCity() + " " +
						String.valueOf(((ShortDelivery)tmpDelivery).getDistance()) + " " + 
						String.valueOf(((ShortDelivery)tmpDelivery).getPricePerKm()) + " " + tmpMember.getMemberId() + " ";
					}
				}
				
				writer.write(tmpMemberDetails + tmpMemberDeliveriesDetails);
				writer.newLine();
				tmpMemberDeliveriesDetails = "";
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of WholeMembers.txt file");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing bufferedWriter of WholeMembers.txt file");
			}
		}
	}
	
	/*This function writes the whole details of main managers file*/
	public static void writeToMainManagersFile()
	{
		BufferedWriter writer = null;
		String tmpManagerDetails = "",tmpMemberDetails = "",tmpMemberDeliveriesDetails = "",tmpStringDate;
		Delivery tmpDelivery;
		Manager tmpManager;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/MainManagers.txt"));
			writer.write("UserName   Password   Area  FName LName Members (and each member deliveries)");
			writer.newLine();
			Iterator<Manager> itrManagers = DataBase.managers.iterator();
			while(itrManagers.hasNext())
			{
				tmpManager = itrManagers.next();
				tmpManagerDetails += tmpManager.getUserName() + " " + tmpManager.getPassword() + " " +
				tmpManager.getManagerArea() + " " + tmpManager.getFirstName() + " " + tmpManager.getLastName() + " ";
				
				for(Members tmpMember:tmpManager.getManagerMembers().values())
				{
					tmpMemberDetails = "ID:" +  tmpMember.getMemberId() + " " + tmpMember.getFirstName().replace(' ', '-') + " "
							 + tmpMember.getLastName().replace(' ', '-') + " " + tmpMember.getLivingArea() + " ";
					
					Iterator<Delivery> itrTmpMemberDeliveries = tmpMember.getDeliveries().iterator();
					while(itrTmpMemberDeliveries.hasNext())
					{
						tmpDelivery = itrTmpMemberDeliveries.next();
						tmpMemberDeliveriesDetails += "Code:";//Code: is written and then the code of the tmpDelivery with no space(comment for me)
						tmpMemberDeliveriesDetails += tmpDelivery.getDeliveryCode() + " " + tmpDelivery.getPrice() + " ";
						
						if(tmpDelivery.getDeliveryCode().startsWith("E"))//Express
						{
							tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((Express)tmpDelivery).getDeadlineArriveDate());
							tmpMemberDeliveriesDetails += tmpStringDate + " " + String.valueOf(((Express)tmpDelivery).getAfterExpressAdditionPrice()) + " ";		
						}
						
						else if(tmpDelivery.getDeliveryCode().startsWith("B"))//Business
						{
							tmpMemberDeliveriesDetails += ((Business)tmpDelivery).getCompanyName() + " " 
							+ String.valueOf(((Business)tmpDelivery).getAfterDiscountPrice()) + " ";
						}
						
						else if(tmpDelivery.getDeliveryCode().startsWith("S"))//Short
						{
							tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((ShortDelivery)tmpDelivery).getDateArrived());
							tmpMemberDeliveriesDetails += tmpStringDate + " " + ((ShortDelivery)tmpDelivery).getOriginCity()
							+ " " + ((ShortDelivery)tmpDelivery).getDestinationCity() + " " +
							String.valueOf(((ShortDelivery)tmpDelivery).getDistance()) + " " + 
							String.valueOf(((ShortDelivery)tmpDelivery).getPricePerKm()) + " " + tmpMember.getMemberId() + " ";
						}
					}
					tmpMemberDetails += tmpMemberDeliveriesDetails;
					tmpManagerDetails += tmpMemberDetails;
					tmpMemberDeliveriesDetails = "";
					tmpMemberDetails = "";
				}
				
				writer.write(tmpManagerDetails);
				writer.newLine();
				tmpManagerDetails = "";
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of main managers file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing the bufferedWriter of main managers file");
			}
		}
	}
	
	/*This function writes the whole details about ourMembersAndDeliveries1,2 TreeMapp in ourMembersAndDeliveries1And2.txt file*/
	public static void writeToDeliveries1AND2File()
	{
		BufferedWriter writer = null;
		Delivery tmpDelivery;
		String tmpStringDate;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/ourMembersAndDeliveries1And2.txt"));
			if(writer != null)
			{
				for(Entry<Integer, Members> en:DataBase.ourMembersAndDeliveries1.entrySet())
				{
					writer.write(en.getKey() + " " + en.getValue().getMemberId());
					writer.newLine();
					tmpDelivery = DataBase.ourMembersAndDeliveries2.get(en.getKey());
					if(tmpDelivery.getDeliveryCode().startsWith("G"))
					{
						writer.write(en.getKey() + " " + tmpDelivery.getDeliveryCode() + " " + tmpDelivery.getPrice());
					}
					else if(tmpDelivery.getDeliveryCode().startsWith("E"))
					{
						tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((Express)tmpDelivery).getDeadlineArriveDate());
						writer.write(en.getKey() + " " + tmpDelivery.getDeliveryCode() + " " +
						tmpDelivery.getPrice() + " " + tmpStringDate + " " + ((Express)tmpDelivery).getAfterExpressAdditionPrice());
					}
					else if(tmpDelivery.getDeliveryCode().startsWith("B"))
					{
						writer.write(en.getKey() + " " + tmpDelivery.getDeliveryCode() + " " +
						tmpDelivery.getPrice() + " " + ((Business)tmpDelivery).getCompanyName() + " "
						 + String.valueOf(((Business)tmpDelivery).getAfterDiscountPrice()));
					}
					
					else if(tmpDelivery.getDeliveryCode().startsWith("S"))//Short
					{
						tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((ShortDelivery)tmpDelivery).getDateArrived());
						writer.write(en.getKey() + " " + tmpDelivery.getDeliveryCode() + " " +
								tmpDelivery.getPrice() + " " + tmpStringDate + " " + ((ShortDelivery)tmpDelivery).getOriginCity()
								+ " " + ((ShortDelivery)tmpDelivery).getDestinationCity() + " " +
								String.valueOf(((ShortDelivery)tmpDelivery).getDistance()) + " " + 
								String.valueOf(((ShortDelivery)tmpDelivery).getPricePerKm()) + " " + en.getValue().getMemberId());
					}
					writer.newLine();
				}
			}
		}
		
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the opening of the file ourMembersAndDeliveries1And2.txt for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing the ourMembersAndDeliveries1And2.txt file");
			}
		}
	}
	
	/*This function writes the whole updated information to MembersShortDeliveries.txt file*/
	public static void writeToMembersShortDeliveries()
	{
		BufferedWriter writer = null;
		Members tmpMember;
		String line,tmpStringDate;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/MembersShortDeliveries.txt"));
			if(writer != null)
			{
				for(Entry<String,ArrayList<ShortDelivery>> en: DataBase.shortDeliveriesByMemberId.entrySet())
				{
					tmpMember = new Members(en.getKey());
					tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember));
					line = tmpMember.getMemberId() + " " + tmpMember.getFirstName() + " " + tmpMember.getLastName()
					+ " " + tmpMember.getLivingArea() + " ";
					for(ShortDelivery tmpShortDelivery: en.getValue())
					{
						tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((ShortDelivery)tmpShortDelivery).getDateArrived());
						line += "Code:" + tmpShortDelivery.getDeliveryCode() + " " + 
						String.valueOf(tmpShortDelivery.getPrice()) + " " + tmpStringDate + " " + 
						tmpShortDelivery.getOriginCity() + " " + tmpShortDelivery.getDestinationCity() + 
						" " + String.valueOf(tmpShortDelivery.getDistance()) + " " + 
						String.valueOf(tmpShortDelivery.getPricePerKm()) + " " + tmpShortDelivery.getMember().getMemberId() + " ";
					}
					writer.write(line);
					writer.newLine();
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong on opening MembersShortDeliveries.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing the MembersShortDeliveries.txt file");
			}
		}
	}
	
	/*This function writes the information about the whole short deliveries to ShortDeliveries.txt file*/
	public static void writeToShortDeliveriesFile()
	{
		BufferedWriter writer = null;
		String line,tmpStringDate;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/ShortDeliveries.txt"));
			if(writer != null)
			{
				for(ShortDelivery tmpShortDelivery:DataBase.wholeShortDeliveries)
				{
					tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(tmpShortDelivery.getDateArrived());
					line = tmpShortDelivery.getDeliveryCode() + " " + String.valueOf(tmpShortDelivery.getPrice())
					+ " " + tmpStringDate + " " + tmpShortDelivery.getOriginCity() + " " + 
					tmpShortDelivery.getDestinationCity() + " " + String.valueOf(tmpShortDelivery.getDistance())
					 + " " + String.valueOf(tmpShortDelivery.getPricePerKm()) + " " + tmpShortDelivery.getMember().getMemberId();
					writer.write(line);
					writer.newLine();
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of ShortDeliveries.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing ShortDeliveries.txt file");
			}
		}	
	}
	
	/*This function write the information from the arrayList of the deputy managers to DeputyManagers.txt file*/
	public static void writeToDeputyManagers()
	{
		BufferedWriter writer = null;
		String line,tmpStringDate;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/DeputyManagers.txt"));
			for(DeputyManager tmpDeputyManager:DataBase.deputyManagers)
			{
				line = tmpDeputyManager.getUserName() + " " + tmpDeputyManager.getPassword() + " " + 
						tmpDeputyManager.getManagerArea() + " " + tmpDeputyManager.getFirstName() + " "
						+ tmpDeputyManager.getLastName() + " " + tmpDeputyManager.getAmountDeliveriesTakeCare() + " ";
				for(ShortDelivery tmpShortDelivery: tmpDeputyManager.getShortDeliveriesList())
				{
					line += "Code:";
					tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(tmpShortDelivery.getDateArrived());
					line += tmpShortDelivery.getDeliveryCode() + " " + String.valueOf(tmpShortDelivery.getPrice())
					+ " " + tmpStringDate + " " + tmpShortDelivery.getOriginCity() + " " + 
					tmpShortDelivery.getDestinationCity() + " " + String.valueOf(tmpShortDelivery.getDistance())
					 + " " + String.valueOf(tmpShortDelivery.getPricePerKm()) + " " + tmpShortDelivery.getMember().getMemberId() + " ";
				}
				writer.write(line);
				writer.newLine();
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of DeputyManagers.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing DeputyManagers.txt file");
			}
		}	
	}
	
	/**/
	public static void writeToRegularDeliveriesByArea()
	{
		BufferedWriter writer = null;
		String tmpArea = null;
		String line = "",tmpStringDate;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/RegularDeliveriesByArea.txt"));
			if(writer != null)
			{
				for(int areaNumber = 1;areaNumber <= 3;areaNumber++)
				{
					switch(areaNumber)
					{
						case 1: tmpArea = "north";break;
						case 2: tmpArea = "center";break;
						case 3: tmpArea = "south";break;
						default:System.out.println("Something went wrong with the areas loop in writeToRegularDeliveriesByArea function");;
					}
					
					writer.write(tmpArea);
					writer.newLine();
					if(DataBase.RegularDeliveriesByAreasMap.get(tmpArea) != null)
					{
						for(Delivery tmpDelivery: DataBase.RegularDeliveriesByAreasMap.get(tmpArea))
						{
							if(tmpDelivery instanceof Express)
							{
								tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((Express)tmpDelivery).getDeadlineArriveDate());
								line += "Code:" + tmpDelivery.getDeliveryCode() + " " +
								String.valueOf(tmpDelivery.getPrice()) + " " + tmpStringDate + " " + 
								String.valueOf(((Express)tmpDelivery).getAfterExpressAdditionPrice()) + " ";
							}
							
							else if(tmpDelivery instanceof Business)
							{
								line += "Code:" + tmpDelivery.getDeliveryCode() + " " +
										String.valueOf(tmpDelivery.getPrice()) + " " +
										((Business)tmpDelivery).getCompanyName() + " " +
										String.valueOf(((Business)tmpDelivery).getAfterDiscountPrice()) + " ";
							}
							
							else
							{
								line += "Code:" + tmpDelivery.getDeliveryCode() + " " +
										String.valueOf(tmpDelivery.getPrice()) + " ";
							}	
						}
					}
					
					writer.write(line);
					writer.newLine();
					line = "";
				}	
			}
		}
		
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of RegularDeliveriesByArea.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing RegularDeliveriesByArea.txt file");
			}
		}
	}
	/*This function reads the String of The String reader until the space character and returns the String that was read*/
	public static String readString(StringReader linesReader,int ch)
	{
		String tmpString = "";
		try
		{
			ch = linesReader.read();
			while(ch != 32 && ch!= -1)//space or end of line
			{
				tmpString += (char)ch;
				ch = linesReader.read();
			}
			return tmpString;
		}
		catch (IOException ex) 
		{
			System.out.println("Smothing went wrong with the reading of the file, readString function");
			return null;
		}	
	}
	
	/*This function reads the whole information from the whole fit files*/
	public static void readWholeFitFiles()
	{
		DataBase.restoreInfo();
		DataBase.restoreDeputyManagers();
		DataBase.restoreDeliveriesOneAndTwo();
	}
	
	/*This function writes the whole information to the whole files*/
	public static void writeToWholeFiles()
	{
		DataBase.writeToMainManagersFile();
		DataBase.writeToWholeMembersFile();
		DataBase.writeToDeliveries1AND2File();
		DataBase.writeToDeputyManagers();
		DataBase.writeToShortDeliveriesFile();
//		DataBase.writeToMembersShortDeliveries(); /*This file's changes are not saved after closing the program*/
		/*Unless, the user clicks the save button in AddManagerFile*/
		DataBase.writeToRegularDeliveriesByArea();
	}
	
	/*This function Builds the manager's initial manual members HashMaps and ourMembersAndDeliveries1*/
//	public static void CreateInitialManualMembers()
//	{
//		Members tmpMember;
//		
//		tmpMember = new Members("123456789", "Ohad", "Cohen", "north");
//		DataBase.managers.get(0).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("987654321", "Boaz", "Maoda", "north");
//		DataBase.managers.get(0).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("159357456", "Lior", "Sushard", "center");
//		DataBase.managers.get(1).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("852146927", "Samuel.L", "Jackson", "center");
//		DataBase.managers.get(1).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("004852147", "Neli", "Tagar", "south");
//		DataBase.managers.get(2).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("194682375", "Kobi", "Mahat", "south");
//		DataBase.managers.get(2).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//	}
//	
//	/*This function builds the member's initial manual deliveries ArrayLists and ourMembersAndDeliveries1,2 and ourLastDeliveries*/
//	public static void CreateInitialManualDeliveries()
//	{
//		Date dateInvited,deadlineArriveDate;
//		Delivery tmpDelivery;
//		/*manager of the north members deliveries*/
//		/*Id:123456789*/
//		dateInvited = new Date(15,5,2020);
//		tmpDelivery = new Delivery("G1",15.33,dateInvited);
//		DataBase.managers.get(0).getManagerMembers().get("123456789").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("123456789"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("123456789"), tmpDelivery);
//		
//		dateInvited = new Date(17,10,2021);
//		deadlineArriveDate = new Date(18,11,2021);
//		tmpDelivery = new Express("E1",100.45,dateInvited,deadlineArriveDate,120);
//		DataBase.managers.get(0).getManagerMembers().get("123456789").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("123456789"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("123456789"), tmpDelivery);
//		
//		/*Id:987654321*/
//		dateInvited = new Date(4,1,2021);
//		tmpDelivery = new Delivery("G2",38.12,dateInvited);
//		DataBase.managers.get(0).getManagerMembers().get("987654321").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("987654321"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("987654321"), tmpDelivery);
//		
//		dateInvited = new Date(17,10,2021);
//		tmpDelivery = new Delivery("G3",370,dateInvited);
//		DataBase.managers.get(0).getManagerMembers().get("987654321").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("987654321"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("987654321"), tmpDelivery);
//		
//		/*manager of the center members deliveries*/
//		/*Id: 159357456*/
//		dateInvited = new Date(31,3,2019);
//		tmpDelivery = new Delivery("G4",55.6,dateInvited);
//		DataBase.managers.get(1).getManagerMembers().get("159357456").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("159357456"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("159357456"), tmpDelivery);
//		
//		dateInvited = new Date(1,1,2021);
//		tmpDelivery = new Business("B1",1000.78,dateInvited,"APU software systems",890.6);
//		DataBase.managers.get(1).getManagerMembers().get("159357456").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("159357456"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("159357456"), tmpDelivery);
//		
//		dateInvited = new Date(15,9,2021);
//		
//		/*Id:852146927*/
//		tmpDelivery = new Delivery("G5",44.8,dateInvited);
//		DataBase.managers.get(1).getManagerMembers().get("852146927").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("852146927"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("852146927"), tmpDelivery);
//		
//		dateInvited = new Date(20,10,2021);
//		deadlineArriveDate = new Date(29,11,2021);
//		tmpDelivery = new Express("E2",350,dateInvited,deadlineArriveDate,400);
//		DataBase.managers.get(1).getManagerMembers().get("852146927").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("852146927"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("852146927"), tmpDelivery);
//		
//		/*manager of the south members deliveries*/
//		/*Id:004852147*/
//		dateInvited = new Date(31,3,2019);
//		tmpDelivery = new Delivery("G6",55.6,dateInvited);
//		DataBase.managers.get(2).getManagerMembers().get("004852147").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("004852147"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("004852147"), tmpDelivery);
//		
//		dateInvited = new Date(1,1,2021);
//		tmpDelivery = new Business("B2",50.4,dateInvited,"Nice lambs",45);
//		DataBase.managers.get(2).getManagerMembers().get("004852147").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("004852147"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("004852147"), tmpDelivery);
//		
//		/*Id:194682375*/
//		dateInvited = new Date(15,9,2021);
//		deadlineArriveDate = new Date(15,9,2021);
//		tmpDelivery = new Express("E3",44.8,dateInvited,deadlineArriveDate,60);
//		DataBase.managers.get(2).getManagerMembers().get("194682375").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("194682375"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("194682375"), tmpDelivery);
//		
//		dateInvited = new Date(20,10,2021);
//		tmpDelivery = new Delivery("G7",350,dateInvited);
//		DataBase.managers.get(2).getManagerMembers().get("194682375").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("194682375"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("194682375"), tmpDelivery);
//	}
	
	/*This function gets the userName of a manager and returns the manager with the same userName the function got*/
	public static Manager ManagerByUserName(String userName)
	{
		if(userName == null)
		{
			 return null;
		}
		
		/*Iterator for main manager*/
		Iterator<Manager> itr1 = DataBase.managers.iterator();
		Manager tmpManager;
		while(itr1.hasNext())
		{
			tmpManager = itr1.next();
			if(tmpManager.getUserName().equals(userName))
			{
				return tmpManager;
			}
		}
		
		Iterator<DeputyManager> itr2 = DataBase.deputyManagers.iterator();
		while(itr2.hasNext())
		{
			tmpManager = itr2.next();
			if(tmpManager.getUserName().equals(userName))
			{
				return tmpManager;
			}
		}
		return null;
	}
       
	/*This function returns true if the lastName of the member it gets already exists in the managers memeber's HashMaps*/
	/*else,it returns false*/
//	public static boolean sameLastName(Members tmpMember)
//	{
//		if(tmpMember == null || tmpMember.getLastName() == null)
//			return false;
//		Iterator<Manager> itr1 = DataBase.managers.iterator();
//		Manager tmpManager;
//		while(itr1.hasNext())
//		{
//			tmpManager = itr1.next();
//			for(Entry<String,Members> entry:tmpManager.getManagerMembers().entrySet())
//			{
//				if(!entry.getValue().equals(tmpMember))
//				{
//					if(entry.getValue().getLastName().toLowerCase().equals(tmpMember.getLastName().toLowerCase()))
//					{
//						return true;
//					}
//				}
//			}
//		}
//		return false;
//	}
	
}
