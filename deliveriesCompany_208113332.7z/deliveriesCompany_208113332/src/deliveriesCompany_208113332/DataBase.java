/*This is a class with static values and functions that meant for keeping the whole database of the deliveries company*/
package deliveriesCompany_208113332;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class DataBase {
	public static Integer countTree = 100;
	

	public static ArrayList<Members> wholeManagersMembersList = new ArrayList<Members>();
	
						 /*Area*/
	public static HashMap<String,ArrayList<Delivery>> RegularDeliveriesByAreasMap = new HashMap<String,ArrayList<Delivery>>();
	
	public static ArrayList<ShortDelivery> wholeShortDeliveries = new ArrayList<ShortDelivery>();
	public static HashMap<String,ArrayList<ShortDelivery>> shortDeliveriesByMemberId = new HashMap<String,ArrayList<ShortDelivery>>();
					    //memberId
							
	public static ArrayList<Manager> managers = new ArrayList<Manager>(); 
	public static ArrayList<DeputyManager> deputyManagers = new ArrayList<DeputyManager>();
	
	public static Map<Members,Delivery> ourLastDeliveries = new TreeMap<Members,Delivery>();
	public static Map<Integer,Members> ourMembersAndDeliveries1 = new TreeMap<Integer,Members>();
	public static Map<Integer,Delivery> ourMembersAndDeliveries2 = new TreeMap<Integer,Delivery>();
	
	
	/*Functions*/
	
	/*This function builds the ArrayList of the managers,This function was used in HW3 and not used in HW4*/
	public static void createManagersList()
	{
										 /*userNames*//*Passwords*/
		DataBase.managers.add(new Manager("adminNorth","adminNorth","north","Avi","Cohen"));
		DataBase.managers.add(new Manager("adminCenter","adminCenter","center","Moshe","Levi"));
		DataBase.managers.add(new Manager("adminSouth","adminSouth","south","George","Jackson"));
	}
	
	/*This function restores the whole information that was added, deleted or changed since the last running of the program to the data structures in DataBase class*/
	/*Beside of outLastMembersAndDeliveries1,2 and DataBase.DeputyManagers*/
	public static void restoreInfo()
	{
		
		String line;
		Manager tmpManager;
		
		try
		{
			String[] tmpManagerDetails;
			File mainManagersFile = new File("src/MainManagers.txt");
			Scanner scn = new Scanner(mainManagersFile);
			scn.nextLine();
			
			/*Because the way The file is made, the information starts from the second line*/
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				tmpManagerDetails = line.split(" ");
				tmpManager = managerByFileInfo(tmpManagerDetails);
				DataBase.managers.add(tmpManager);
			}
			scn.close();
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the opening of MainManagers.txt file");
		}
		catch(NumberFormatException ex)
		{
			System.out.println("Somthing went wrong with the formating of the one of the numbers types(one of the prices or distance) in MainMangers.txt file");
		}
	}
	
	/*This function gets the String array that stores the file information and returns the Manager that this information represents*/
	public static Manager managerByFileInfo(String[] data)
	{
		Manager tmpManager;
		int startIndex = 5,nextMemberIndex,nextDeliveryIndex;
		if(data.length == 5)//manager with not members
		{
			return new Manager(data[0],data[1],data[2],data[3],data[4]);
		}
		else if(data.length == 6)//deputy manager without short deliveries
		{
			return new DeputyManager(data[0],data[1],data[2],data[3],data[4],Integer.parseInt(data[5]));
		}
		else if(data.length > 5 && data[5].startsWith("ID:"))//the call to this function is from reading MainManagers.txt file function and manager has members
		{
			tmpManager = new Manager(data[0],data[1],data[2],data[3],data[4]);
			while(startIndex < data.length)
			{
				nextMemberIndex = whereNextMember(data,startIndex);
				tmpManager.addMember(memberByFileInfo(data,startIndex,data[2]));
				startIndex = nextMemberIndex;
			}
			return tmpManager;
		}
		
		else // deputy manager with short deliveries
		{
			tmpManager = new DeputyManager(data[0],data[1],data[2],data[3],data[4],Integer.parseInt(data[5]));
			startIndex = 6;
			while(startIndex < data.length)
			{
				nextDeliveryIndex = whereNextDelivery(data,startIndex);
				((DeputyManager)tmpManager).getShortDeliveriesList().add((ShortDelivery) deliveryByFileInfo(data,startIndex,data[2],null));
				startIndex = nextDeliveryIndex;
			}
			return tmpManager;
		}
	}
	
	/*This function gets the String array that stores the file information and index to start to get values from the array and returns the Member that this information represents*/
	public static Members memberByFileInfo(String[] data,int startIndex,String managerArea)
	{
		Members tmpMember = new Members(data[startIndex].substring(3),data[startIndex + 1],data[startIndex + 2],data[startIndex + 3]);
		String tmpMemberId = data[startIndex].substring(3);
		int tmpIndex = startIndex,nextDeliveryIndex = 0;
		tmpIndex = whereNextMember(data,tmpIndex);
		startIndex += 4;
		while(startIndex < tmpIndex)//while we do not get another member information
		{
			nextDeliveryIndex = whereNextDelivery(data,startIndex);
			tmpMember.addDelivery(deliveryByFileInfo(data,startIndex,managerArea,tmpMemberId));
			startIndex = nextDeliveryIndex;
		}
		DataBase.wholeManagersMembersList.add(tmpMember);
		if(tmpMember.getDeliveries().size() > 0)
				DataBase.ourLastDeliveries.put(tmpMember, tmpMember.getDeliveries().get(tmpMember.getDeliveries().size() - 1));
		return tmpMember;
	}
	
	/*This function gets the String array that stores the file information and index to start to get values from the array and returns the Delivery that this information represents*/
	public static Delivery deliveryByFileInfo(String[] data,int startIndex,String managerArea,String memberId)
	{
		try
		{
			int tmpIndex = startIndex;
			Date tmpDate;
			Delivery tmpDelivery;
			if(data[startIndex].startsWith("Code:"))//depends on the file we read from
			{
				data[startIndex] = data[startIndex].substring(5);//only the code itself 
			}
			
			tmpIndex = whereNextDelivery(data,tmpIndex);
			
			if(tmpIndex - startIndex == 2)//Delivery
			{
				tmpDelivery = new Delivery(data[startIndex],Double.parseDouble(data[startIndex + 1]));
				if(managerArea != null)
				{
					addToRegularDeliveriesByAreaMap(managerArea,tmpDelivery);
				}
				return tmpDelivery;
			}
			
			else if(tmpIndex - startIndex == 4)//Express or Business
			{
				if(data[startIndex].startsWith("E"))//Express
				{
					tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(data[startIndex + 2]);
					tmpDelivery = new Express(data[startIndex],Double.parseDouble(data[startIndex + 1]),tmpDate,Double.parseDouble(data[startIndex + 3]));
					if(managerArea != null)
					{
						addToRegularDeliveriesByAreaMap(managerArea,tmpDelivery);
					}
					return tmpDelivery;
				}
				else//Business
				{
					tmpDelivery = new Business(data[startIndex],Double.parseDouble(data[startIndex + 1]),data[startIndex + 2],Double.parseDouble(data[startIndex + 3]));
					if(managerArea != null)
					{
						addToRegularDeliveriesByAreaMap(managerArea,tmpDelivery);
					}
					return tmpDelivery;
				}
			}
			
			else//Short Delivery
			{
				tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(data[startIndex + 2]);
				tmpDelivery = new ShortDelivery(data[startIndex],Double.parseDouble(data[startIndex + 1]),tmpDate,
						data[startIndex + 3],data[startIndex + 4],Integer.parseInt(data[startIndex + 5]),
						Double.parseDouble(data[startIndex + 6]) , new Members(data[startIndex + 7]));
				
				if(memberId != null)//called from member function and not from manager function(deputy manager)
				{
					DataBase.wholeShortDeliveries.add((ShortDelivery)tmpDelivery);
					if(DataBase.shortDeliveriesByMemberId.get(memberId) != null)
					{
						DataBase.shortDeliveriesByMemberId.get(memberId).add((ShortDelivery)tmpDelivery);
					}
					else
					{
						ArrayList<ShortDelivery> al = new ArrayList<ShortDelivery>();
						al.add((ShortDelivery)tmpDelivery);
						DataBase.shortDeliveriesByMemberId.put(memberId, al);
					}
				}
				return tmpDelivery;
			}
		}
		catch(ParseException ex)
		{
			System.out.println("Something went wrong with the parsing of the date");
			return null;
		}	
	}
	
	/*This function get the data array and a tmpIndex and returns the index of the next delivery in the array, if there is no next delivery, it returns the last index of the array*/
	public static int whereNextDelivery(String[]data , int tmpIndex)
	{
		tmpIndex++;
		while(tmpIndex < data.length)
		{
			if(!data[tmpIndex].startsWith("Code:") && !data[tmpIndex].startsWith("ID:"))
			{
				tmpIndex++;
			}
			else
			{
				break;
			}
		}
		return tmpIndex;
	}
	
	/*This function get the data array and a tmpIndex and returns the index of the next member in the array, if there is no next member, it returns the last index of the array*/
	public static int whereNextMember(String[]data , int tmpIndex)
	{
		tmpIndex++;
		while(tmpIndex < data.length) 
		{
			if(!data[tmpIndex].startsWith("ID:"))
			{
				tmpIndex++;
			}
			else
			{
				break;
			}
			
		}
		return tmpIndex;
	}
	
	/*This function gets the area and a delivery(not short delivery) and adds it to DataBase.RegularDeliveriesByAreasMap*/
	public static void addToRegularDeliveriesByAreaMap(String area,Delivery tmpDelivery)
	{
		/*I assumed that a regular delivery is any delivery which is not a short delivery*/
		
		if(DataBase.RegularDeliveriesByAreasMap.get(area) != null)
		{
			DataBase.RegularDeliveriesByAreasMap.get(area).add(tmpDelivery);
		}
			else
			{
				ArrayList<Delivery> al = new ArrayList<Delivery>();
				al.add(tmpDelivery);
				DataBase.RegularDeliveriesByAreasMap.put(area, al);
			}
	}
	
	/*This function restores the whole most updated information about the ourMembersAndDeliveries1,2 TreeMaps*/
	public static void restoreDeliveriesOneAndTwo()
	{
		String line;
		Members tmpMember;

		try
		{
			File ourMembersAndDeliveries1And2File = new File("src/ourMembersAndDeliveries1And2.txt");
			Scanner scn = new Scanner(ourMembersAndDeliveries1And2File);
			String[] data;
			while(scn.hasNextLine())
			{
				line = scn.nextLine();	
				data = line.split(" ");
				DataBase.countTree = Integer.parseInt(data[0]);
				tmpMember = new Members(data[1]);
				tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember));
				line = scn.nextLine();
				data = line.split(" ");
				int index = 0;
				while(index < data.length - 1)
				{
					data[index] = data[index + 1];
					index++;
				}
				data = Arrays.copyOf(data, data.length - 1);
				DataBase.ourMembersAndDeliveries1.put(DataBase.countTree, tmpMember);
				DataBase.ourMembersAndDeliveries2.put(DataBase.countTree, deliveryByFileInfo(data,0,null,null));
			}
			scn.close();
			DataBase.countTree += 5;
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with openning the ourMembersAndDeliveries1,2 file");
		}
	}
	
	/*This function restores the whole most updated information about the DeputyManagers*/
	public static void restoreDeputyManagers()
	{
		String line;
		DeputyManager tmpDeputyManager;
		
		try
		{
			File deputyManagersFile = new File("src/DeputyManagers.txt");
			Scanner scn = new Scanner(deputyManagersFile);
			String[] data;
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				data = line.split(" ");
				
				tmpDeputyManager = (DeputyManager)(managerByFileInfo(data));
				DataBase.deputyManagers.add(tmpDeputyManager);
			}
			scn.close();
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of DeputyManagers.txt file");
		} 
	}
	
	/*This function returns the String represents the manager's details*/
	public static String writeManager(Manager tmpManager)
	{
		String tmpManagerDetails = "";
		if(tmpManager instanceof DeputyManager)
		{
			tmpManagerDetails += tmpManager.getUserName() + " " + tmpManager.getPassword() + " " + 
					tmpManager.getManagerArea() + " " + tmpManager.getFirstName() + " "
					+ tmpManager.getLastName() + " " + ((DeputyManager)tmpManager).getAmountDeliveriesTakeCare() + " ";
		}
		else
		{
			tmpManagerDetails += tmpManager.getUserName() + " " + tmpManager.getPassword() + " " +
					tmpManager.getManagerArea() + " " + tmpManager.getFirstName() + " " + tmpManager.getLastName() + " ";
		}

		return tmpManagerDetails;
	}
	
	/*This function returns the String represents the memeber's details*/
	public static String writeMember(Members tmpMember)
	{
		return tmpMember.getMemberId() + " " + tmpMember.getFirstName().replace(' ', '-') + " "
				 + tmpMember.getLastName().replace(' ', '-') + " " + tmpMember.getLivingArea() + " ";
	}
	
	/*This function returns the String represents the delivery's details*/
	public static String writeDelivery(String tmpMemberDeliveriesDetails, Delivery tmpDelivery,Members tmpMember)
	{
		String tmpStringDate;
		tmpMemberDeliveriesDetails += "Code:";//Code: is written and then the code of the tmpDelivery with no space(comment for me)
		tmpMemberDeliveriesDetails += tmpDelivery.getDeliveryCode() + " " + tmpDelivery.getPrice() + " ";
		
		if(tmpDelivery.getDeliveryCode().startsWith("E"))//Express
		{
			tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((Express)tmpDelivery).getDeadlineArriveDate());
			tmpMemberDeliveriesDetails += tmpStringDate + " " + String.valueOf(((Express)tmpDelivery).getAfterExpressAdditionPrice()) + " ";		
		}
		
		else if(tmpDelivery.getDeliveryCode().startsWith("B"))//Business
		{
			tmpMemberDeliveriesDetails += ((Business)tmpDelivery).getCompanyName().replace(" ", "-") + " " 
			+ String.valueOf(((Business)tmpDelivery).getAfterDiscountPrice()) + " ";
		}
		
		else if(tmpDelivery.getDeliveryCode().startsWith("S"))//Short
		{
			tmpStringDate =	new SimpleDateFormat("dd/MM/yyyy").format(((ShortDelivery)tmpDelivery).getDateArrived());
			tmpMemberDeliveriesDetails += tmpStringDate + " " + ((ShortDelivery)tmpDelivery).getOriginCity().replace(" ", "-")
			+ " " + ((ShortDelivery)tmpDelivery).getDestinationCity().replace(" ", "-") + " " +
			String.valueOf(((ShortDelivery)tmpDelivery).getDistance()) + " " + 
			String.valueOf(((ShortDelivery)tmpDelivery).getPricePerKm()) + " " + tmpMember.getMemberId() + " ";
		}
		
		return tmpMemberDeliveriesDetails;
	}
	
	/*This function writes The whole members details to WholeMembers.txt file*/
	public static void writeToWholeMembersFile()
	{
		BufferedWriter writer = null;
		String tmpMemberDetails="",tmpMemberDeliveriesDetails="";
		Members tmpMember;
		Delivery tmpDelivery;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/WholeMembers.txt"));
			Iterator<Members> itr = DataBase.wholeManagersMembersList.iterator();
			while(itr.hasNext())
			{
				tmpMember = itr.next();
				tmpMemberDetails = writeMember(tmpMember);	
				Iterator<Delivery> itr2 = tmpMember.getDeliveries().iterator();
				while(itr2.hasNext())
				{
					tmpDelivery = itr2.next();
					tmpMemberDeliveriesDetails = writeDelivery(tmpMemberDeliveriesDetails,tmpDelivery,tmpMember);
				}
				
				writer.write(tmpMemberDetails + tmpMemberDeliveriesDetails);
				writer.newLine();
				tmpMemberDeliveriesDetails = "";
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of WholeMembers.txt file");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing bufferedWriter of WholeMembers.txt file");
			}
		}
	}
	
	/*This function writes the whole details of main managers file*/
	public static void writeToMainManagersFile()
	{
		BufferedWriter writer = null;
		String tmpManagerDetails = "",tmpMemberDetails = "",tmpMemberDeliveriesDetails = "";
		Delivery tmpDelivery;
		Manager tmpManager;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/MainManagers.txt"));
			writer.write("UserName   Password   Area  FName LName Members (and each member deliveries)");
			writer.newLine();
			Iterator<Manager> itrManagers = DataBase.managers.iterator();
			while(itrManagers.hasNext())
			{
				tmpManager = itrManagers.next();
				tmpManagerDetails = writeManager(tmpManager);
	
				for(Members tmpMember:tmpManager.getManagerMembers().values())
				{
					tmpMemberDetails = "ID:" + writeMember(tmpMember);
					
					Iterator<Delivery> itrTmpMemberDeliveries = tmpMember.getDeliveries().iterator();
					while(itrTmpMemberDeliveries.hasNext())
					{
						tmpDelivery = itrTmpMemberDeliveries.next();
						tmpMemberDeliveriesDetails = writeDelivery(tmpMemberDeliveriesDetails,tmpDelivery,tmpMember);
					}
					
					tmpMemberDetails += tmpMemberDeliveriesDetails;
					tmpManagerDetails += tmpMemberDetails;
					tmpMemberDeliveriesDetails = "";
					tmpMemberDetails = "";
				}
				
				writer.write(tmpManagerDetails);
				writer.newLine();
				tmpManagerDetails = "";
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of main managers file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing the bufferedWriter of main managers file");
			}
		}
	}
	
	/*This function writes the whole details about ourMembersAndDeliveries1,2 TreeMapp in ourMembersAndDeliveries1And2.txt file*/
	public static void writeToDeliveries1AND2File()
	{
		BufferedWriter writer = null;
		Delivery tmpDelivery;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/ourMembersAndDeliveries1And2.txt"));
			if(writer != null)
			{
				for(Entry<Integer, Members> en:DataBase.ourMembersAndDeliveries1.entrySet())
				{
					writer.write(en.getKey() + " " + en.getValue().getMemberId());
					writer.newLine();
					tmpDelivery = DataBase.ourMembersAndDeliveries2.get(en.getKey());
					writer.write(en.getKey() + " " + writeDelivery("",tmpDelivery,en.getValue()));
					writer.newLine();
				}
			}
		}
		
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the opening of the file ourMembersAndDeliveries1And2.txt for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing the ourMembersAndDeliveries1And2.txt file");
			}
		}
	}
	
	/*This function writes the whole updated information to MembersShortDeliveries.txt file*/
	public static void writeToMembersShortDeliveries()
	{
		BufferedWriter writer = null;
		Members tmpMember;
		String line;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/MembersShortDeliveries.txt"));
			if(writer != null)
			{
				for(Entry<String,ArrayList<ShortDelivery>> en: DataBase.shortDeliveriesByMemberId.entrySet())
				{
					tmpMember = new Members(en.getKey());
					tmpMember = DataBase.wholeManagersMembersList.get(DataBase.wholeManagersMembersList.indexOf(tmpMember));
					line = writeMember(tmpMember);
					for(ShortDelivery tmpShortDelivery: en.getValue())
					{
						line = writeDelivery(line,tmpShortDelivery,tmpMember);
					}
					writer.write(line);
					writer.newLine();
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong on opening MembersShortDeliveries.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing the MembersShortDeliveries.txt file");
			}
		}
	}
	
	/*This function writes the information about the whole short deliveries to ShortDeliveries.txt file*/
	public static void writeToShortDeliveriesFile()
	{
		BufferedWriter writer = null;
		String line;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/ShortDeliveries.txt"));
			if(writer != null)
			{
				for(ShortDelivery tmpShortDelivery:DataBase.wholeShortDeliveries)
				{
					line = writeDelivery("",tmpShortDelivery,tmpShortDelivery.getMember());
					writer.write(line);
					writer.newLine();
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of ShortDeliveries.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing ShortDeliveries.txt file");
			}
		}	
	}
	
	/*This function write the information from the arrayList of the deputy managers to DeputyManagers.txt file*/
	public static void writeToDeputyManagers()
	{
		BufferedWriter writer = null;
		String line;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/DeputyManagers.txt"));
			for(DeputyManager tmpDeputyManager:DataBase.deputyManagers)
			{
				line = writeManager(tmpDeputyManager);
				for(ShortDelivery tmpShortDelivery: tmpDeputyManager.getShortDeliveriesList())
				{
					line = writeDelivery(line,tmpShortDelivery,tmpShortDelivery.getMember());
				}
				writer.write(line);
				writer.newLine();
			}
		}
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of DeputyManagers.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing DeputyManagers.txt file");
			}
		}	
	}
	
	/*This function writes the most updated information of RegularDeliveriesByAreaMap to RegularDeliveriesByArea.txt file*/
	public static void writeToRegularDeliveriesByArea()
	{
		BufferedWriter writer = null;
		String tmpArea = null;
		String line = "";
		try
		{
			writer = new BufferedWriter(new FileWriter("src/RegularDeliveriesByArea.txt"));
			if(writer != null)
			{
				for(int areaNumber = 1;areaNumber <= 3;areaNumber++)
				{
					switch(areaNumber)
					{
						case 1: tmpArea = "north";break;
						case 2: tmpArea = "center";break;
						case 3: tmpArea = "south";break;
						default:System.out.println("Something went wrong with the areas loop in writeToRegularDeliveriesByArea function");;
					}
					
					writer.write(tmpArea);
					writer.newLine();
					if(DataBase.RegularDeliveriesByAreasMap.get(tmpArea) != null)
					{
						for(Delivery tmpDelivery: DataBase.RegularDeliveriesByAreasMap.get(tmpArea))
						{
							line = writeDelivery(line,tmpDelivery,null);/*The member the writeDelivery function gets in not neccesary for this case*/
						}
					}
					
					writer.write(line);
					writer.newLine();
					line = "";
				}	
			}
		}
		
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with the opening of RegularDeliveriesByArea.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing RegularDeliveriesByArea.txt file");
			}
		}
	}
	/*This function reads the String of The String reader until the space character and returns the String that was read*/
	public static String readString(StringReader linesReader,int ch)
	{
		String tmpString = "";
		try
		{
			ch = linesReader.read();
			while(ch != 32 && ch!= -1)//space or end of line
			{
				tmpString += (char)ch;
				ch = linesReader.read();
			}
			return tmpString;
		}
		catch (IOException ex) 
		{
			System.out.println("Smothing went wrong with the reading of the file, readString function");
			return null;
		}	
	}
	
	/*This function reads the whole information from the whole fit files*/
	public static void readWholeFitFiles()
	{
		DataBase.restoreInfo();
		DataBase.restoreDeputyManagers();
		DataBase.restoreDeliveriesOneAndTwo();
	}
	
	/*This function writes the whole information to the whole files*/
	public static void writeToWholeFiles()
	{
		DataBase.writeToMainManagersFile();
		DataBase.writeToWholeMembersFile();
		DataBase.writeToDeliveries1AND2File();
		DataBase.writeToDeputyManagers();
		DataBase.writeToShortDeliveriesFile();
//		DataBase.writeToMembersShortDeliveries(); /*This file's changes are not saved after closing the program*/
		/*Unless, the user clicks the save button in AddManagerFile*/
		DataBase.writeToRegularDeliveriesByArea();
	}
	
	/*This function Builds the manager's initial manual members HashMaps and ourMembersAndDeliveries1*/
//	public static void CreateInitialManualMembers()
//	{
//		Members tmpMember;
//		
//		tmpMember = new Members("123456789", "Ohad", "Cohen", "north");
//		DataBase.managers.get(0).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("987654321", "Boaz", "Maoda", "north");
//		DataBase.managers.get(0).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("159357456", "Lior", "Sushard", "center");
//		DataBase.managers.get(1).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("852146927", "Samuel.L", "Jackson", "center");
//		DataBase.managers.get(1).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("004852147", "Neli", "Tagar", "south");
//		DataBase.managers.get(2).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//		tmpMember = new Members("194682375", "Kobi", "Mahat", "south");
//		DataBase.managers.get(2).getManagerMembers().put(tmpMember.getMemberId(), tmpMember);
//	}
//	
//	/*This function builds the member's initial manual deliveries ArrayLists and ourMembersAndDeliveries1,2 and ourLastDeliveries*/
//	public static void CreateInitialManualDeliveries()
//	{
//		Date dateInvited,deadlineArriveDate;
//		Delivery tmpDelivery;
//		/*manager of the north members deliveries*/
//		/*Id:123456789*/
//		dateInvited = new Date(15,5,2020);
//		tmpDelivery = new Delivery("G1",15.33,dateInvited);
//		DataBase.managers.get(0).getManagerMembers().get("123456789").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("123456789"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("123456789"), tmpDelivery);
//		
//		dateInvited = new Date(17,10,2021);
//		deadlineArriveDate = new Date(18,11,2021);
//		tmpDelivery = new Express("E1",100.45,dateInvited,deadlineArriveDate,120);
//		DataBase.managers.get(0).getManagerMembers().get("123456789").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("123456789"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("123456789"), tmpDelivery);
//		
//		/*Id:987654321*/
//		dateInvited = new Date(4,1,2021);
//		tmpDelivery = new Delivery("G2",38.12,dateInvited);
//		DataBase.managers.get(0).getManagerMembers().get("987654321").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("987654321"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("987654321"), tmpDelivery);
//		
//		dateInvited = new Date(17,10,2021);
//		tmpDelivery = new Delivery("G3",370,dateInvited);
//		DataBase.managers.get(0).getManagerMembers().get("987654321").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(0).getManagerMembers().get("987654321"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(0).getManagerMembers().get("987654321"), tmpDelivery);
//		
//		/*manager of the center members deliveries*/
//		/*Id: 159357456*/
//		dateInvited = new Date(31,3,2019);
//		tmpDelivery = new Delivery("G4",55.6,dateInvited);
//		DataBase.managers.get(1).getManagerMembers().get("159357456").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("159357456"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("159357456"), tmpDelivery);
//		
//		dateInvited = new Date(1,1,2021);
//		tmpDelivery = new Business("B1",1000.78,dateInvited,"APU software systems",890.6);
//		DataBase.managers.get(1).getManagerMembers().get("159357456").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("159357456"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("159357456"), tmpDelivery);
//		
//		dateInvited = new Date(15,9,2021);
//		
//		/*Id:852146927*/
//		tmpDelivery = new Delivery("G5",44.8,dateInvited);
//		DataBase.managers.get(1).getManagerMembers().get("852146927").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("852146927"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("852146927"), tmpDelivery);
//		
//		dateInvited = new Date(20,10,2021);
//		deadlineArriveDate = new Date(29,11,2021);
//		tmpDelivery = new Express("E2",350,dateInvited,deadlineArriveDate,400);
//		DataBase.managers.get(1).getManagerMembers().get("852146927").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(1).getManagerMembers().get("852146927"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(1).getManagerMembers().get("852146927"), tmpDelivery);
//		
//		/*manager of the south members deliveries*/
//		/*Id:004852147*/
//		dateInvited = new Date(31,3,2019);
//		tmpDelivery = new Delivery("G6",55.6,dateInvited);
//		DataBase.managers.get(2).getManagerMembers().get("004852147").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("004852147"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("004852147"), tmpDelivery);
//		
//		dateInvited = new Date(1,1,2021);
//		tmpDelivery = new Business("B2",50.4,dateInvited,"Nice lambs",45);
//		DataBase.managers.get(2).getManagerMembers().get("004852147").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("004852147"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("004852147"), tmpDelivery);
//		
//		/*Id:194682375*/
//		dateInvited = new Date(15,9,2021);
//		deadlineArriveDate = new Date(15,9,2021);
//		tmpDelivery = new Express("E3",44.8,dateInvited,deadlineArriveDate,60);
//		DataBase.managers.get(2).getManagerMembers().get("194682375").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("194682375"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("194682375"), tmpDelivery);
//		
//		dateInvited = new Date(20,10,2021);
//		tmpDelivery = new Delivery("G7",350,dateInvited);
//		DataBase.managers.get(2).getManagerMembers().get("194682375").addDelivery(tmpDelivery);
//		DataBase.ourMembersAndDeliveries1.put(countTree, DataBase.managers.get(2).getManagerMembers().get("194682375"));
//		DataBase.ourMembersAndDeliveries2.put(countTree,tmpDelivery);
//		DataBase.countTree += 5;
//		DataBase.ourLastDeliveries.put(DataBase.managers.get(2).getManagerMembers().get("194682375"), tmpDelivery);
//	}
	
	/*This function gets the userName of a manager and returns the manager with the same userName the function got*/
	public static Manager ManagerByUserName(String userName)
	{
		if(userName == null)
		{
			 return null;
		}
		
		/*Iterator for main manager*/
		Iterator<Manager> itr1 = DataBase.managers.iterator();
		Manager tmpManager;
		while(itr1.hasNext())
		{
			tmpManager = itr1.next();
			if(tmpManager.getUserName().equals(userName))
			{
				return tmpManager;
			}
		}
		
		Iterator<DeputyManager> itr2 = DataBase.deputyManagers.iterator();
		while(itr2.hasNext())
		{
			tmpManager = itr2.next();
			if(tmpManager.getUserName().equals(userName))
			{
				return tmpManager;
			}
		}
		return null;
	}
       
	/*This function returns true if the lastName of the member it gets already exists in the managers memeber's HashMaps*/
	/*else,it returns false*/
//	public static boolean sameLastName(Members tmpMember)
//	{
//		if(tmpMember == null || tmpMember.getLastName() == null)
//			return false;
//		Iterator<Manager> itr1 = DataBase.managers.iterator();
//		Manager tmpManager;
//		while(itr1.hasNext())
//		{
//			tmpManager = itr1.next();
//			for(Entry<String,Members> entry:tmpManager.getManagerMembers().entrySet())
//			{
//				if(!entry.getValue().equals(tmpMember))
//				{
//					if(entry.getValue().getLastName().toLowerCase().equals(tmpMember.getLastName().toLowerCase()))
//					{
//						return true;
//					}
//				}
//			}
//		}
//		return false;
//	}
	
}
