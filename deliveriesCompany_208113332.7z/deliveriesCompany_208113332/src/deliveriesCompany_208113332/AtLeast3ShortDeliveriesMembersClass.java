package deliveriesCompany_208113332;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class AtLeast3ShortDeliveriesMembersClass extends JFrame {
	
	public JPanel panel33;
	public JPanel panel44;
	public JLabel massage2; //These are the whole members that ordered at least 3 short deliveries
	public JTextArea textAreaMembersShortDeliveriesDetails;
	public JScrollPane jsp3;
	public JLabel backgroundFile;
	
	private String textOfTheTextArea;
	private BufferedReader reader;
	private StringReader linesReader;
	private String line;
	private String tmpDetail;
	
	public AtLeast3ShortDeliveriesMembersClass()
	{
		try
		{
			int ch = 0,countShortDeliveries = 0;
			this.setBackground(Color.WHITE);
			
			this.textOfTheTextArea = "";
			reader = new BufferedReader(new FileReader("src/MembersShortDeliveries.txt"));
			if(reader != null)
			{
				line = reader.readLine();
				while(line != null)
				{
					linesReader = new StringReader(line);
					ch = linesReader.read();
					tmpDetail = DataBase.readString(linesReader, ch);
					while(ch != -1)
					{
						if(tmpDetail.startsWith("ode:"))//ch already read the C of "Code:"
						{
							countShortDeliveries++;
						}
						ch = linesReader.read();
						tmpDetail = DataBase.readString(linesReader, ch);
					}
					
					if(countShortDeliveries >= 3)
					{
						this.textOfTheTextArea += line + "\n";
					}
					countShortDeliveries = 0;
					linesReader.close();
					line = reader.readLine();
				}
			}
			this.setBounds(0,30,400,500);
			panel33 = new JPanel(new FlowLayout());
			panel33.setBounds(30,200,400,50);
			panel33.setBackground(Color.WHITE);
			massage2 = new JLabel("The members above ordered at least 3 short deliveries:");
			massage2.setBounds(30,50,200,20);
			massage2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
			panel33.add(massage2);

			this.add(panel33);		

			panel44 = new JPanel(new FlowLayout());
			panel44.setBounds(50,70,400,50);
			panel44.setBackground(Color.WHITE);
			textAreaMembersShortDeliveriesDetails = new JTextArea(8,40);
			textAreaMembersShortDeliveriesDetails.setEditable(false);
			textAreaMembersShortDeliveriesDetails.setText(this.textOfTheTextArea);
			jsp3 = new JScrollPane(textAreaMembersShortDeliveriesDetails);
			jsp3.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			panel44.add(jsp3);
			this.add(panel44);
				
			this.setSize(500,500);
			this.setVisible(true);
		}
		
		catch(IOException ex)
		{
			System.out.println("Somthing went wrong with opening MembersShortDeliveries.txt for reading");
		}
		
		finally
		{
			try
			{
				if(reader != null) 
				{
					reader.close();
				}
				if(linesReader != null)
				{
					linesReader.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing one of the streams in MembersShortDeliveries.txt file");
			}
		}	

	}

}
