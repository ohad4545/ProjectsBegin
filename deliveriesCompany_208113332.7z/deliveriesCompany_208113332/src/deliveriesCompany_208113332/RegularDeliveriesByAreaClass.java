package deliveriesCompany_208113332;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class RegularDeliveriesByAreaClass extends JFrame {

	public JTable table;
	public JScrollPane scroll;
	
	private BufferedReader reader;
	private StringReader linesReader;
	private String line;
	private String tmpArea;
	
	public RegularDeliveriesByAreaClass(String tmpArea) {

		try
		{
			this.tmpArea = tmpArea;
			this.setBackground(Color.WHITE);
			DataBase.writeToRegularDeliveriesByArea();; //for updating also the current running changes of this file
			String[] cols= {"Deliery code","price","DeadLine date","After express price","Company name","After discount price"};
			
			if(DataBase.RegularDeliveriesByAreasMap.get(tmpArea) == null) //The Area does not have regular deliveries
			{
				throw new NullPointerException();
			}
			Object[][] data = new Object[DataBase.RegularDeliveriesByAreasMap.get(tmpArea).size()][6];
			reader = new BufferedReader(new FileReader("src/RegularDeliveriesByArea.txt"));
			int ch = 0,row = 0;
			if(reader != null)
			{
				line = reader.readLine();
				while(line != null)
				{
					if(line.equals(tmpArea))
					{
						line = reader.readLine();
						linesReader = new StringReader(line);
						while(linesReader.read() != -1)
						{
							data[row][0] = DataBase.readString(linesReader, ch).substring(4);//code
							data[row][1] = DataBase.readString(linesReader, ch);//price
							
							/*To initialize the rest of the details which are not common to whole types of deliveries*/
							for(int col=2;col<6;col++)
							{
								data[row][col] = "";
							}
							
							if(String.valueOf(data[row][0]).startsWith("E"))//Express
							{
								/*Express properties columns*/
								data[row][2] = DataBase.readString(linesReader, ch);//DeadLine date
								data[row][3] = DataBase.readString(linesReader, ch);//After express addition price
							}
							
							else if(String.valueOf(data[row][0]).startsWith("B"))//Business
							{
								/*Business properties columns*/
								data[row][4] = DataBase.readString(linesReader, ch);//company name
								data[row][5] = DataBase.readString(linesReader, ch);//After discount price
							}	
							row++;
						}	
					}
					
					line = reader.readLine();	
				}	
			}
			
			this.setBounds(0,10,1300,500);
			setLayout(new BorderLayout());
					
			table = new JTable(data,cols);
			table.setBounds(10, 254, 414, -198);

			scroll = new JScrollPane(table);
			add(scroll,BorderLayout.CENTER);
			
			this.setBackground(Color.WHITE);
			this.setVisible(true);
			
			
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with the reading of RegularDeliveriesByArea.txt file");
		}
		catch(NullPointerException ex)
		{
			JOptionPane.showMessageDialog(null, "There are no regular deliveries in your managing area");
		}
		
		finally
		{
			try
			{
				if(reader != null) 
				{
					reader.close();
				}
				if(linesReader != null)
				{
					linesReader.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Somthing went wrong with closing one of the streams in RegularDeliveriesByArea.txt file");
			}
		}	
	}
}
