package deliveriesCompany_208113332;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;

public class RemoveCustomerFile extends JPanel implements ActionListener{

	public JLabel title;
	public JLabel massage;
	public JComboBox<String> comboBoxRemoveMember;
	public JButton removeButton;
	
	private String currentUserName;
	private Manager tmpManager;
	private JLabel backgroundRemoveMember;
	
	public RemoveCustomerFile(String currentUserName) {
		
		this.setBackground(Color.WHITE);
		this.currentUserName = currentUserName;
		this.tmpManager = DataBase.managers.get(DataBase.managers.indexOf(DataBase.ManagerByUserName(this.currentUserName)));
		
		setLayout(null);
		this.setBounds(0,10,400,500);
		
		title = new JLabel("Removing customer file");
		title.setBounds(100, 29, 242, 30);
		title.setForeground(Color.darkGray);
		title.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
		add(title);
		
		massage = new JLabel("Please choose the customer you would like to remove:");
		massage.setBounds(10, 70, 313, 14);
		massage.setForeground(Color.darkGray);
		massage.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		add(massage);
		
		comboBoxRemoveMember = new JComboBox<String>();
		comboBoxRemoveMember.setBounds(20, 93, 249, 22);
		comboBoxRemoveMember.addItem("");
		
		/*Adding the whole this.tmpManager members to the comboBox*/
		for(Members m:this.tmpManager.getManagerMembers().values())
		{
			comboBoxRemoveMember.addItem(m.getMemberId() + " " + m.getFirstName() + " " + m.getLastName());
		}
		add(comboBoxRemoveMember);
		
		removeButton = new JButton("Remove");
		removeButton.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/remove.png")));
		removeButton.setBounds(275, 93, 117, 25);
		removeButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 15));
		removeButton.addActionListener(this);
		add(removeButton);
		
		this.setSize(500,500);
		
		backgroundRemoveMember = new JLabel("");
		backgroundRemoveMember.setIcon(new ImageIcon(RemoveCustomerFile.class.getResource("/ImagesPackage/collections_deliveries_large.jpeg")));
		backgroundRemoveMember.setBounds(42, 41, 696, 448);
		add(backgroundRemoveMember);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == removeButton)
		{
			try
			{
				if(comboBoxRemoveMember.getSelectedIndex() == 0)//No member was chosen
				{
					throw new NullPointerException();
				}
				String tmpMemberId = (String.valueOf(comboBoxRemoveMember.getSelectedItem())).substring(0, 9);
				Members tmpMember = new Members(tmpMemberId);
				
				/*The member have short deliveries*/
				if(DataBase.shortDeliveriesByMemberId.get(tmpMemberId) != null)
					if(DataBase.shortDeliveriesByMemberId.get(tmpMemberId).size() > 0)
					{
						throw new UnauthorizedException();
					}
				
				/*This loop is for removing the deliveries of the member and NOT for remove the member itself*/
//				for(Delivery d:DataBase.wholeManagersByUserName.get(this.currentUserName).getManagerMembers().get(tmpMemberId).getDeliveries())
//				{
//					DataBase.wholeDeliveriesByDeliveryCode.remove(d.getDeliveryCode());
//				}
				
				/*Removing from the fit data structures*/
				DataBase.wholeManagersMembersList.remove(tmpMember);
//				DataBase.wholeManagersMembersMap.remove(tmpMemberId);
				tmpMember = DataBase.ManagerByUserName(this.currentUserName).getManagerMembers().remove(tmpMember.getMemberId());
	
				if(DataBase.ourLastDeliveries.containsKey(tmpMember))
					DataBase.ourLastDeliveries.remove(tmpMember);
				
//				if(DataBase.shortDeliveriesByMemberId.containsKey(tmpMemberId))
//				{
//					ArrayList<ShortDelivery> shortDeliveriesToRemove = DataBase.shortDeliveriesByMemberId.get(tmpMemberId);
//					DataBase.shortDeliveriesByMemberId.remove(tmpMemberId);
//					DataBase.wholeShortDeliveries.removeAll(shortDeliveriesToRemove);
//					
//					/*This loop meant for getting the whole deputy Managers and NOT for removing the member itself*/
//					for(DeputyManager m:DataBase.deputyManagers)
//					{
//						m.removeShortDeliveries(tmpMember);
//					}
//				}
			
//				DataBase.managers.get(DataBase.managers.indexOf(DataBase.wholeManagersByUserName.get(this.currentUserName))).getManagerMembers().remove(tmpMemberId);
				
				JOptionPane.showMessageDialog(null, "The member was removed successfully");
				int index = comboBoxRemoveMember.getSelectedIndex();
				comboBoxRemoveMember.removeItemAt(index);
				comboBoxRemoveMember.setSelectedIndex(0);
			}
			catch(UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "You can not remove the member because it has short deliveries");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "Please choose a member");
			}
		}
		
	}
}
