package deliveriesCompany_208113332;

import java.util.ArrayList;
import java.util.Iterator;

public class DeputyManager extends Manager{

	private int amountDeliveriesTakeCare;
	private ArrayList<ShortDelivery> shortDeliveriesList;
	
	/*constructor*/
	public DeputyManager(String userName, String password, String managerArea, String firstName, String lastName,
			int amountDeliveriesTakeCare) {
		super(userName, password, managerArea, firstName, lastName);
		this.amountDeliveriesTakeCare = amountDeliveriesTakeCare;
		this.shortDeliveriesList = new ArrayList<ShortDelivery>();
	}

	/*Functions*/
	
	/*This function meant for looking and removing the short deliveries we would like to remove when we click(Remove short delivery main manager) on remove whole short deliveries button*/
	public void removeShortDeliveries(Members tmpMember)
	{
		Iterator<ShortDelivery> itr = this.getShortDeliveriesList().iterator();
		/*This loop is for removing the short deliveries of the member and NOT for remove the member itself*/
		while(itr.hasNext())
		{
			if(itr.next().getMember().equals(tmpMember))
			{
				itr.remove();
			}
		}
	}
	
	/*Getters and Setters*/
	public int getAmountDeliveriesTakeCare() {
		return amountDeliveriesTakeCare;
	}

	public void setAmountDeliveriesTakeCare(int amountDeliveriesTakeCare) {
		this.amountDeliveriesTakeCare = amountDeliveriesTakeCare;
	}

	public ArrayList<ShortDelivery> getShortDeliveriesList() {
		return shortDeliveriesList;
	}

	public void setShortDeliveriesList(ArrayList<ShortDelivery> shortDeliveriesList) {
		if(shortDeliveriesList != null)
			this.shortDeliveriesList = shortDeliveriesList;
	}

	
	/*toString function*/
	@Override
	public String toString() {
		return super.toString() + " DeputyManager [amountDeliveriesTakeCare=" + amountDeliveriesTakeCare + ", shortDeliveriesList="
				+ shortDeliveriesList + "]";
	}
	
}
