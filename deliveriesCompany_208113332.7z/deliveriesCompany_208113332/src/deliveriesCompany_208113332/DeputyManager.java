package deliveriesCompany_208113332;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

public class DeputyManager extends Manager{

	private int amountDeliveriesTakeCare;
	private ArrayList<ShortDelivery> shortDeliveriesList;
	
	/*constructor*/
	public DeputyManager(String userName, String password, String managerArea, String firstName, String lastName,
			int amountDeliveriesTakeCare) {
		super(userName, password, managerArea, firstName, lastName);
		this.amountDeliveriesTakeCare = amountDeliveriesTakeCare;
		this.shortDeliveriesList = new ArrayList<ShortDelivery>();
	}

	/*Functions*/
	
	/*This function meant for looking and removing the short deliveries we would like to remove when we click(Remove short delivery main manager) on remove whole short deliveries button*/
	public void removeShortDeliveries(Members tmpMember)
	{
		Iterator<ShortDelivery> itr = this.getShortDeliveriesList().iterator();
		/*This loop is for removing the short deliveries of the member and NOT for remove the member itself*/
		while(itr.hasNext())
		{
			if(itr.next().getMember().equals(tmpMember))
			{
				itr.remove();
			}
		}
	}
	
	/*This function removes the whole short deliveries from ourMembersAndDeliveries1,2*/
	public void removeWholeMemberShortDeliveriesFromMembersAndDeliveriesMaps(Members tmpMember)
	{
		 Integer currentCountTree;
		 ArrayList<Integer> countTreeList = new ArrayList<Integer>();
		 if(tmpMember == null)
			 return;
		 
		 /*finding the whole countTree values that their values are the tmpMember values*/
		 for(Entry<Integer,Members> entry: DataBase.ourMembersAndDeliveries1.entrySet())
		 {
			 /*if in the current key there is the member in TreeMap 1 and short delivery on TreeMap 2*/
			 if(entry.getValue().equals(tmpMember) && DataBase.ourMembersAndDeliveries2.get(entry.getKey()).getDeliveryCode().startsWith("S"))
			 {
				 countTreeList.add(entry.getKey());
			 }
		 }
		 
		 /*removing the whole countTree values that are the tmpMember value and all of its deliveries*/
		 Iterator<Integer> itr = countTreeList.iterator();
		 while(itr.hasNext())
		 {
			 currentCountTree = itr.next();
			 DataBase.ourMembersAndDeliveries1.remove(currentCountTree);
			 DataBase.ourMembersAndDeliveries2.remove(currentCountTree);
		 } 	
	}
	
	/*Getters and Setters*/
	public int getAmountDeliveriesTakeCare() {
		return amountDeliveriesTakeCare;
	}

	public void setAmountDeliveriesTakeCare(int amountDeliveriesTakeCare) {
		this.amountDeliveriesTakeCare = amountDeliveriesTakeCare;
	}

	public ArrayList<ShortDelivery> getShortDeliveriesList() {
		return shortDeliveriesList;
	}

	public void setShortDeliveriesList(ArrayList<ShortDelivery> shortDeliveriesList) {
		if(shortDeliveriesList != null)
			this.shortDeliveriesList = shortDeliveriesList;
	}

	
	/*toString function*/
	@Override
	public String toString() {
		return super.toString() + " DeputyManager [amountDeliveriesTakeCare=" + amountDeliveriesTakeCare + ", shortDeliveriesList="
				+ shortDeliveriesList + "]";
	}
	
}
