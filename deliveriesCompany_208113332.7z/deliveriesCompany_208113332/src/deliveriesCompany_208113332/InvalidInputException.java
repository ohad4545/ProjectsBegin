package deliveriesCompany_208113332;

/*This exception is thrown when the user typed an invalid input*/
public class InvalidInputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/*constructors*/
	public InvalidInputException()
	{
		super();
	}
	public InvalidInputException(String massage)
	{
		super(massage);
	}
}
