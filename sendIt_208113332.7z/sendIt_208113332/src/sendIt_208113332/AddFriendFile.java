package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class AddFriendFile extends JFrame implements ActionListener{
	
	public JLabel title;
	public JLabel usersLabel;
	public JComboBox<String> usersComboBox;
	public JButton sendFriendRequestButton;
	public JButton backToMenuButton;
	public JLabel background;

	private User tmpUser;
	
	public AddFriendFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		title = new JLabel("Add Friend");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		title.setBounds(168, 11, 94, 26);
		getContentPane().add(title);
		
		usersLabel = new JLabel("Please choose the user you want to send a friend request:");
		usersLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		usersLabel.setBounds(10, 48, 414, 26);
		getContentPane().add(usersLabel);
		
		usersComboBox = new JComboBox<String>();
		usersComboBox.setBounds(10, 85, 218, 34);
		usersComboBox.addItem("");
		addUsersToUsersSet();
		for(User u:DataBase.usersSet)
		{
			usersComboBox.addItem(u.getLastName() + " " + u.getFirstName() + " " + u.getUserName());
		}
		getContentPane().add(usersComboBox);
		
		sendFriendRequestButton = new JButton("Send A Friend Request");
		sendFriendRequestButton.setIcon(new ImageIcon(AddFriendFile.class.getResource("/img/send.png")));
		sendFriendRequestButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendFriendRequestButton.setBounds(101, 147, 218, 42);
		sendFriendRequestButton.addActionListener(this);
		getContentPane().add(sendFriendRequestButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(AddFriendFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(101, 200, 218, 42);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(AddFriendFile.class.getResource("/img/friends.png")));
		background.setBounds(74, 11, 434, 261);
		getContentPane().add(background);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == sendFriendRequestButton)
		{
			try
			{
				/*no user was chosen*/
				if(usersComboBox.getSelectedIndex() == 0)
				{
					throw new NullPointerException();
				}
			
				String[] infoArr = String.valueOf(usersComboBox.getSelectedItem()).split(" ");
				
				/*The chosen user already has a friend request from the current user*/
				if(DataBase.UsersByUserNameMap.get(infoArr[2]).equals(this.tmpUser))
				{
					throw new SameUserException();
				}
				if(DataBase.UsersByUserNameMap.get(infoArr[2]).getFriendRequestsMap().get(this.tmpUser.getUserName()) != null)
				{
					throw new UnauthorizedException();
				}
				
				if(DataBase.UsersByUserNameMap.get(tmpUser.getUserName()).getFriendsMassagesMap().get(infoArr[2]) != null)
				{
					throw new AlreadyFriendsException();
				}
				
				/*Add to the fit data structures and writing to the right files*/
				
				FriendRequest fr = new FriendRequest(this.tmpUser.getUserName(),infoArr[2]);
				DataBase.UsersByUserNameMap.get(infoArr[2]).getFriendRequestsMap().put(this.tmpUser.getUserName(), fr);
				
				DataBase.writeToFriendRequestsFile();
				
				JOptionPane.showMessageDialog(null, "Friend request was sent successfully");
				DataBase.UsersByIdMap.put(DataBase.UsersByUserNameMap.get(infoArr[2]).getId(), DataBase.UsersByUserNameMap.get(infoArr[2]));
				
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "Please choose a user from the list");
			} 
			catch (UnauthorizedException ex) 
			{
				JOptionPane.showMessageDialog(null, "You have already sent a friend request to this user");
			} 
			catch (SameUserException ex)
			{
				JOptionPane.showMessageDialog(null, "Sorry, but you can not send a friend request to yourself");
			} 
			catch (AlreadyFriendsException ex)
			{
				JOptionPane.showMessageDialog(null, "You are already friend of the user you chose");
			}
		}
		
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			this.setVisible(false);
		}
			
	}
	
	/*This function adds the users from the Users file to the usersSet TreeSet in DataBase that compares by last names*/
	public static void addUsersToUsersSet()
	{
		if(!DataBase.usersSet.isEmpty())
		{
			DataBase.usersSet.clear();
		}
		
		File file = null;
		Scanner scn = null;
		String line = "";
		String []infoArr;
		try
		{
			file = new File("src/Users.txt");
			scn = new Scanner(file);
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				infoArr = line.split(" ");
				DataBase.usersSet.add(DataBase.createUserFromUserFileInfo(infoArr));
			}
		}
		
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening Users.txt file for reading");
		}
		
		finally
		{
			if(scn!= null)
				scn.close();
		}
	}
}