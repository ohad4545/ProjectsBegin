package sendIt_208113332;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;

public class ForumsDetailsFile extends JFrame implements ActionListener{

	public JTable forumsDetailsTable;
	public JScrollPane scrollPane;
	public JButton backButton;
		
	private User tmpUser;
	
	public ForumsDetailsFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		this.tmpUser = tmpUser;
		
		getContentPane().setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,650, 400);
		getContentPane().setLayout(new BorderLayout());
		
		String[] cols = {"Forum Name" , "Forum Code","Who Opened"};
		Object[][] data = new Object[DataBase.forumsList.size()][3];
		int tmpId = 0;
		
		/*Adding the forums list details to the JTable*/
		for(int i = 0;i < DataBase.forumsList.size(); i++)
		{
			data[i][0] = DataBase.forumsList.get(i).getForumName();
			data[i][1] = String.valueOf(DataBase.forumsList.get(i).getForumCode());
			tmpId = DataBase.getForumUserId(DataBase.forumsList.get(i).getFilePathForum());
			if(DataBase.UsersByIdMap.get(tmpId) != null)
				data[i][2] = DataBase.UsersByIdMap.get(tmpId).getUserName();
			else if(DataBase.UsersByIdMap.get(tmpId) == null)
				data[i][2] = DataBase.removedUsersByIdMap.get(tmpId).getUserName();
		}
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		getContentPane().add(scrollPane,BorderLayout.CENTER);
		
		forumsDetailsTable = new JTable(data,cols);
		forumsDetailsTable.setBounds(10, 254, 414, -198);
		scrollPane.setViewportView(forumsDetailsTable);
		
		backButton = new JButton("Back");
		backButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backButton.setIcon(new ImageIcon(UsersDetailsFile.class.getResource("/img/return.png")));
		backButton.setBounds(210, 298, 89, 23);
		backButton.addActionListener(this);
		getContentPane().add(backButton,BorderLayout.SOUTH);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == backButton)
		{
			new StatisticsFile(this.tmpUser);
			this.setVisible(false);
		}
	}
}
