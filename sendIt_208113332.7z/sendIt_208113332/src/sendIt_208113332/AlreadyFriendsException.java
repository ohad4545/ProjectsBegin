package sendIt_208113332;

/*This exception is thrown when the user tries to send a friend request to a user that is already a friend of the current user*/
public class AlreadyFriendsException extends Exception {
	
	/*constructors*/
	public AlreadyFriendsException()
	{
		super();
	}
	
	public AlreadyFriendsException(String Massage)
	{
		super(Massage);
	}
}
