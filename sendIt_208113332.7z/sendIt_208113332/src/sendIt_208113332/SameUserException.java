package sendIt_208113332;

/*This exception meant to be thrown when the user tries to make an action in the system with itself the is not logic*/
public class SameUserException extends Exception {
	
	/*constructors*/
	public SameUserException()
	{
		super();
	}
	public SameUserException(String massage)
	{
		super(massage);
	}
}
