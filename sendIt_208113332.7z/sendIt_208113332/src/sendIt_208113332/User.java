package sendIt_208113332;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class User {
	
	protected String userName;//Unique property
	protected String password;
	protected String firstName;
	protected String lastName;
	protected static int count = 0;
	protected int id;//unique property
	protected int massagesAmountTheUserSent;
	protected boolean isBlocked;
	
	  				/*UserName WhoSent*/
	protected HashMap<String,FriendRequest> friendRequestsMap;
					/*UserName of the friend*/
	protected HashMap<String,ArrayList<Massage>> friendsMassagesMap;
	protected ArrayList<Forum> forumsList;
	
	/*constructors*/
	public User(String userName)
	{
		super();
		this.userName = userName;
	}
	public User(String userName, String password, String firstName, String lastName) {
		
		this(userName);
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		User.count++;
		this.id = User.count;
		this.massagesAmountTheUserSent = 0;
		this.isBlocked = false;
		
		this.friendRequestsMap = new HashMap<String,FriendRequest>();
		this.friendsMassagesMap = new HashMap<String,ArrayList<Massage>>();
		this.forumsList = new ArrayList<Forum>();
	}

	/*Getters and Setters*/
	public String getUserName() {
		return userName;
	}
	
	public abstract void setUserName(String userName);

	public String getPassword() {
		return password;
	}

	public abstract void setPassword(String password);

	public String getFirstName() {
		return firstName;
	}

	public abstract void setFirstName(String firstName);

	public String getLastName() {
		return lastName;
	}

	public abstract void setLastName(String lastName);

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		User.count = count;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMassagesAmount() {
		return massagesAmountTheUserSent;
	}

	public abstract void setMassagesAmount(int massagesAmount);
	
	public HashMap<String, FriendRequest> getFriendRequestsMap() {
		return friendRequestsMap;
	}
	public abstract void setFriendRequestsMap(HashMap<String, FriendRequest> friendRequestsMap);
	
	public HashMap<String, ArrayList<Massage>> getFriendsMassagesMap() {
		return friendsMassagesMap;
	}
	
	public abstract void setFriendsMassagesMap(HashMap<String, ArrayList<Massage>> friendsMassagesMap);
	
	public ArrayList<Forum> getForumsList() {
		return forumsList;
	}
	
	public abstract void setForumsList(ArrayList<Forum> forumsList);
	
	public boolean getIsBlocked() {
		return isBlocked;
	}
	public abstract void setBlocked(boolean isBlocked);
	
	/*equals Method(by userName)*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
	
	/*toString Method*/
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", id=" + id + ", massagesAmountTheUserSent=" + massagesAmountTheUserSent +
				", friendRequestsMap=" + friendRequestsMap + ", friendsMassagesMap=" + friendsMassagesMap + 
				", ForumsList=" + forumsList + ", isBlocked=" + isBlocked + "]";
	}
	
}

