package sendIt_208113332;

/*This program meant for be a social system of sending massages between friends and also in forums that the users of the system create*/
public class Main {

	public static void main(String[] args) {
		DataBase.readFromFiles();
		new WelcomeScreen();
	}

}
