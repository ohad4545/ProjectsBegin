package sendIt_208113332;

/*This exception meant to be thrown when the user tries to do something in the system that he is unauthorized to do*/
public class UnauthorizedException extends Exception {
	
	public UnauthorizedException()
	{
		super();
	}
	
	public UnauthorizedException(String massage)
	{
		super(massage);
	}
}
