package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import java.awt.Color;
import javax.swing.ImageIcon;

public class SendExpressMassageFile extends JFrame implements ActionListener{

	public JPanel panel;
	public JLabel title;
	public JPanel panel_1;
	public JLabel massageLabel;
	public JScrollPane scrollPane;
	public JTextArea expressMassage_ta;
	public JButton sendButton;
	public JButton backToMenuButton;
	public JLabel dateLabel;
	public JDateChooser dateChooser;
	public JTextFieldDateEditor editor;
	
	private User tmpUser;
	
	public SendExpressMassageFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 11, 402, 29);
		getContentPane().add(panel);
		
		title = new JLabel("Express Massage");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		panel.add(title);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(10, 62, 402, 188);
		getContentPane().add(panel_1);
		
		massageLabel = new JLabel("Please type your express massage to the whole forums:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		panel_1.add(massageLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panel_1.add(scrollPane);
		
		expressMassage_ta = new JTextArea();
		expressMassage_ta.setColumns(30);
		expressMassage_ta.setRows(8);
		scrollPane.setViewportView(expressMassage_ta);
		
		sendButton = new JButton("Send");
		sendButton.setIcon(new ImageIcon(SendExpressMassageFile.class.getResource("/img/send.png")));
		sendButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendButton.setBounds(131, 320, 159, 29);
		sendButton.addActionListener(this);
		getContentPane().add(sendButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(SendExpressMassageFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(131, 360, 159, 29);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		dateLabel = new JLabel("Date the Massage is sent:");
		dateLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		dateLabel.setBounds(10, 275, 215, 27);
		getContentPane().add(dateLabel);
		
		dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("dd/MM/yyyy");
		dateChooser.setBounds(245, 283, 166, 19);
		editor = (JTextFieldDateEditor) dateChooser.getDateEditor();
		editor.setEditable(false);
		getContentPane().add(dateChooser);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == sendButton)
		{
			try
			{
				if(expressMassage_ta.getText().equals("") || editor.getText().equals(""))
				{
					throw new NullPointerException();
				}
				Date tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(editor.getText());
				@SuppressWarnings("deprecation")
				Date dateTheSystemWasOpened = new Date(122,1,1); // 1/2/2022
				if(tmpDate.getTime() - dateTheSystemWasOpened.getTime() < 0)//tmpDate is earlier than 1/2/2022
				{
					throw new OutOfDateException();
				}
				
				String strMassage = editor.getText() + " " + this.tmpUser.getFirstName() + ": " + expressMassage_ta.getText();
				Massage m = new ExpressMassage(strMassage + '\n',tmpDate);
				
				/*Adding the massage to the fit data structures and writing it to the fit text files*/
				DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()).setMassagesAmount(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()).getMassagesAmount() + 1);
				DataBase.writeToUsersFile("src/Users.txt",DataBase.UsersByUserNameMap);
				
				sendExpressMassage(m,DataBase.UsersByUserNameMap);
				sendExpressMassage(m,DataBase.removedUsersByUserNameMap);
				DataBase.addToDaliyMassagesMap(m);
				
				JOptionPane.showMessageDialog(null, "Massage was sent successfully");
				expressMassage_ta.setText("");
				editor.setText("");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields are empty, please fill the whole fields");
			} 
			catch (ParseException ex)
			{
				JOptionPane.showMessageDialog(null, "Something went wrong with the parsing of the date");
			}
			catch (OutOfDateException ex)
			{
				JOptionPane.showMessageDialog(null, "The date of the massage can not be earlier than the 1st Fabuary 2022 (01/02/2022)");
			}
		}
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			this.setVisible(false);
		}
		
	}
	
	/*This function sends the express massage*/
	public static void sendExpressMassage(Massage m,HashMap<String,User> hm)
	{
		for(User u:hm.values())
		{
			for(Forum f:u.getForumsList())
			{
				u.getForumsList().get(u.getForumsList().indexOf(f)).getForumMassagesList().add(m);
				if(hm == DataBase.UsersByUserNameMap)
					DataBase.UsersByIdMap.put(u.getId(), u);
				else
					DataBase.removedUsersByIdMap.put(u.getId(), u);
				
				DataBase.writeMassageToFitForumMassagesFile(f.getForumCode(), u.getId(), f);
			}
		}
	}
}
