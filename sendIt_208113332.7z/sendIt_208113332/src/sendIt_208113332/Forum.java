package sendIt_208113332;

import java.util.ArrayList;

public class Forum {
	
	private String forumName;
	private static int num = 0;
	private int forumCode;
	private ArrayList<Massage> forumMassagesList;
	private String description;//what does the forum meant for?
	private String filePathForum;
	
	/*constructors*/
	public Forum(int forumCode)
	{
		this.forumCode = forumCode;
	}
	public Forum(String forumName, String description) {
		super();
		this.forumName = forumName;
		this.description = description;
		Forum.num++;
		this.forumCode = Forum.num;
		this.forumMassagesList = new ArrayList<Massage>();
		this.filePathForum = "";
	}

	/*Getters and Setters*/
	public String getForumName() {
		return forumName;
	}

	public void setForumName(String forumName) {
		this.forumName = forumName;
	}

	public static int getNum() {
		return num;
	}

	public static void setNum(int num) {
		Forum.num = num;
	}

	public int getForumCode() {
		return forumCode;
	}

	public void setForumCode(int forumCode) {
		this.forumCode = forumCode;
	}

	public ArrayList<Massage> getForumMassagesList() {
		return forumMassagesList;
	}

	public void setForumMassagesList(ArrayList<Massage> forumMassagesList) {
		this.forumMassagesList = forumMassagesList;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFilePathForum() {
		return filePathForum;
	}

	public void setFilePathForum(String filePathForum) {
		this.filePathForum = filePathForum;
	}

	/*equals by forumCode method*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Forum other = (Forum) obj;
		if (forumCode != other.forumCode)
			return false;
		return true;
	}
	
	/*toString Function*/
	@Override
	public String toString() {
		return "Forum [forumName=" + forumName + ", forumCode=" + forumCode + ", forumMassagesList=" + forumMassagesList
				+ ", description=" + description + ", filePathForum=" + filePathForum + "]";
	}
}
