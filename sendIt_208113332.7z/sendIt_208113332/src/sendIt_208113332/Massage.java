package sendIt_208113332;

import java.util.Date;

public class Massage {
	
	private String text;
	private Date whenSent;
	
	/*constructors*/
	public Massage() {}
	
	public Massage(String text, Date whenSent) {
		super();
		this.text = text;
		this.whenSent = whenSent;
	}

	/*Getters and Setters*/
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getWhenSent() {
		return whenSent;
	}

	public void setWhenSent(Date whenSent) {
		this.whenSent = whenSent;
	}
	
	/*equals function by the whole properties*/

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Massage other = (Massage) obj;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		if (whenSent == null) {
			if (other.whenSent != null)
				return false;
		} else if (!whenSent.equals(other.whenSent))
			return false;
		return true;
	}

	/*toString Function*/
	@Override
	public String toString() {
		return "Massage [text=" + text + ", whenSent=" + whenSent + "]";
	}
}
