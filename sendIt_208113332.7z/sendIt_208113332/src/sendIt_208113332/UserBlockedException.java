package sendIt_208113332;

/*This exception meant to be thrown when a blocked user tries to enter the system*/
public class UserBlockedException extends Exception {
	
	/*constructors*/
	public UserBlockedException()
	{
		super();
	}
	public UserBlockedException(String massage)
	{
		super(massage);
	}
}
