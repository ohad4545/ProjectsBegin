package sendIt_208113332;

import java.util.ArrayList;
import java.util.HashMap;

public class ForumsManager extends User{
	
	private boolean isConnected;
	
	/*constructors*/
	public ForumsManager(String userName)
	{
		super(userName);
		this.isConnected = false;
	}

	public ForumsManager(String userName, String password, String firstName, String lastName)
	{
		super(userName,password,firstName,lastName);
		this.isConnected = false;
	}
	
	/*Getters and Setters*/
	public boolean GetIsConnected() 
	{
		return isConnected;
	}

	public void setIsConnected(boolean isConnected) 
	{
		this.isConnected = isConnected;
	}
	
	@Override
	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	@Override
	public void setPassword(String password)
	{
		this.password = password;
	}

	@Override
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	@Override
	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}

	@Override
	public void setMassagesAmount(int massagesAmount) 
	{
		this.massagesAmountTheUserSent = massagesAmount;
	}
	
	@Override
	public void setFriendRequestsMap(HashMap<String, FriendRequest> friendRequestsMap)
	{
		this.friendRequestsMap = friendRequestsMap;
	}
	@Override
	public void setFriendsMassagesMap(HashMap<String, ArrayList<Massage>> friendsMassagesMap) 
	{
		this.friendsMassagesMap = friendsMassagesMap;
	}
	@Override
	public void setForumsList(ArrayList<Forum> forumsList)
	{
		this.forumsList = forumsList;
	}

	@Override
	public void setBlocked(boolean isBlocked) {
		this.isBlocked = isBlocked;
	}
	
	/*toString Function*/
	@Override
	public String toString() {
		return super.toString() + ", isConnected= " + isConnected + " " + "ForumsManager";
	}	
}
