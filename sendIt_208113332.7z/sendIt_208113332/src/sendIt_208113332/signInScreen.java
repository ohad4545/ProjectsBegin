package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class signInScreen extends JFrame implements ActionListener{
	
	public JTextField userName_tf;
	public JPasswordField passwordField;
	public JLabel massageLabel;
	public JLabel signInLabel;
	public JLabel userNameLabel;
	public JLabel passwordLabel;
	public JButton logInButton;
	public JButton signUpButton;
	public JLabel background;
	
	public signInScreen() {
		getContentPane().setBackground(Color.WHITE);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		massageLabel = new JLabel("Please type your details:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massageLabel.setBounds(10, 37, 186, 28);
		getContentPane().add(massageLabel);
		
		signInLabel = new JLabel("Sign In");
		signInLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		signInLabel.setBounds(180, 11, 61, 28);
		getContentPane().add(signInLabel);
		
		userNameLabel = new JLabel("userName:");
		userNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		userNameLabel.setBounds(95, 65, 81, 28);
		getContentPane().add(userNameLabel);
		
		userName_tf = new JTextField();
		userName_tf.setBounds(189, 69, 110, 27);
		getContentPane().add(userName_tf);
		userName_tf.setColumns(10);
		
		passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		passwordLabel.setBounds(95, 103, 81, 28);
		getContentPane().add(passwordLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(189, 107, 110, 27);
		getContentPane().add(passwordField);
		
		logInButton = new JButton("Log In");
		logInButton.setIcon(new ImageIcon(signInScreen.class.getResource("/img/lock.png")));
		logInButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		logInButton.setBounds(142, 157, 123, 35);
		logInButton.addActionListener(this);
		getContentPane().add(logInButton);
		
		signUpButton = new JButton("Sign up");
		signUpButton.setIcon(new ImageIcon(signInScreen.class.getResource("/img/writing (1).png")));
		signUpButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		signUpButton.setBounds(142, 203, 123, 35);
		signUpButton.addActionListener(this);
		getContentPane().add(signUpButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(signInScreen.class.getResource("/img/13.jpg")));
		background.setBounds(32, 0, 402, 261);
		getContentPane().add(background);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == logInButton)
		{
			String tmpUserName = userName_tf.getText();
			String tmpPassword = String.valueOf(passwordField.getPassword());
			try
			{
				/*Missing field*/
				if(tmpUserName.equals("") ||  tmpPassword.equals(""))
				{
					throw new NullPointerException();
				}
				
				/*User does not exist or the password the user typed is wrong*/
				if(DataBase.UsersByUserNameMap.get(tmpUserName) == null || !DataBase.UsersByUserNameMap.get(tmpUserName).getPassword().equals(tmpPassword))
				{
					throw new UnauthorizedException();
				}
				
				/*User is blocked*/
				if(DataBase.UsersByUserNameMap.get(tmpUserName).getIsBlocked())
				{
					throw new UserBlockedException();
				}
				
				/*Setting the user isConnecnted setting*/
				if(DataBase.UsersByUserNameMap.get(tmpUserName) instanceof MainManager)
				{
					((MainManager)DataBase.UsersByUserNameMap.get(tmpUserName)).setIsConnected(true);
				}
				else if(DataBase.UsersByUserNameMap.get(tmpUserName) instanceof UsersManager)
				{
					((UsersManager)DataBase.UsersByUserNameMap.get(tmpUserName)).setIsConnected(true);
				}
				else if(DataBase.UsersByUserNameMap.get(tmpUserName) instanceof ForumsManager)
				{
					((ForumsManager)DataBase.UsersByUserNameMap.get(tmpUserName)).setIsConnected(true);
				}
				else if(DataBase.UsersByUserNameMap.get(tmpUserName) instanceof Member)
				{
					((Member)DataBase.UsersByUserNameMap.get(tmpUserName)).setIsConnected(true);
				}
				
				new MainScreen(DataBase.UsersByUserNameMap.get(tmpUserName));
				this.setVisible(false);
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields is empty, please fill the whole fields");
			} 
			catch (UnauthorizedException ex) 
			{
				JOptionPane.showMessageDialog(null, "The user name or the password you typed are wrong because the user is not found in the system, please type your details again");
			} 
			catch (UserBlockedException ex)
			{
				JOptionPane.showMessageDialog(null, "This user is blocked and therefore can not enter the system");
			}
		}
		if(e.getSource() == signUpButton)
		{
			new SignUpScreen();
			this.setVisible(false);
		}
		
	}

}
