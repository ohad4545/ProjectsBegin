package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class MainScreen extends JFrame implements ActionListener{
	
	public JButton addFriendButton;
	public JLabel massageLabel;
	public JButton watchFriendRequestsButton;
	public JButton sendMassageToFriendButton;
	public JButton sendMassageInForumButton;
	public JButton buildForumButton;
	public JButton managingUsersButton;
	public JButton sendExpressMassageButton;
	public JButton addManagerButton;
	public JButton statisticsButton;
	public JButton logOutButton;
	public JLabel background;
	
	private User tmpUser;
	
	public MainScreen(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 650);
		getContentPane().setLayout(null);
		
		addFriendButton = new JButton("Add friend");
		addFriendButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-add-friend-32.png")));
		addFriendButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		addFriendButton.setBounds(10, 56, 238, 67);
		addFriendButton.addActionListener(this);
		getContentPane().add(addFriendButton);
		
		massageLabel = new JLabel("Please pick an option from the menu below:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massageLabel.setBounds(87, 11, 308, 21);
		getContentPane().add(massageLabel);
		
		watchFriendRequestsButton = new JButton("Watch friends requests");
		watchFriendRequestsButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-request-32.png")));
		watchFriendRequestsButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		watchFriendRequestsButton.setBounds(271, 56, 228, 67);
		watchFriendRequestsButton.addActionListener(this);
		getContentPane().add(watchFriendRequestsButton);
		
		sendMassageToFriendButton = new JButton("Send Massage to friend");
		sendMassageToFriendButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-send-32.png")));
		sendMassageToFriendButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendMassageToFriendButton.setBounds(10, 148, 238, 67);
		sendMassageToFriendButton.addActionListener(this);
		getContentPane().add(sendMassageToFriendButton);
		
		sendMassageInForumButton = new JButton("Send massage in Forum");
		sendMassageInForumButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-send-32 (1).png")));
		sendMassageInForumButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendMassageInForumButton.setBounds(130, 226, 252, 67);
		sendMassageInForumButton.addActionListener(this);
		getContentPane().add(sendMassageInForumButton);
		
		buildForumButton = new JButton("Build Forum");
		buildForumButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-forum-32.png")));
		buildForumButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		buildForumButton.setBounds(271, 148, 228, 67);
		buildForumButton.addActionListener(this);
		getContentPane().add(buildForumButton);
		
		managingUsersButton = new JButton("Manage Users");
		managingUsersButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-admin-settings-male-32.png")));
		managingUsersButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		managingUsersButton.setBounds(130, 304, 252, 67);
		managingUsersButton.addActionListener(this);
		getContentPane().add(managingUsersButton);
		managingUsersButton.setVisible(false);
		if(this.tmpUser instanceof MainManager || this.tmpUser instanceof UsersManager)
		{
			managingUsersButton.setVisible(true);
		}
		
		sendExpressMassageButton = new JButton("Send Express Massage");
		sendExpressMassageButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-mail-32.png")));
		sendExpressMassageButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendExpressMassageButton.setBounds(130, 382, 252, 67);
		sendExpressMassageButton.addActionListener(this);
		getContentPane().add(sendExpressMassageButton);
		sendExpressMassageButton.setVisible(false);
		if(this.tmpUser instanceof MainManager || this.tmpUser instanceof ForumsManager)
		{
			sendExpressMassageButton.setVisible(true);
		}
		
		addManagerButton = new JButton("Add manager");
		addManagerButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-add-user-male-32.png")));
		addManagerButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		addManagerButton.setBounds(10, 460, 238, 67);
		addManagerButton.addActionListener(this);
		getContentPane().add(addManagerButton);
		addManagerButton.setVisible(false);
		if(this.tmpUser instanceof MainManager)
		{
			addManagerButton.setVisible(true);
		}
		
		statisticsButton = new JButton("Statistics");
		statisticsButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-economy-32.png")));
		statisticsButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		statisticsButton.setBounds(271, 460, 228, 67);
		statisticsButton.addActionListener(this);
		getContentPane().add(statisticsButton);
		statisticsButton.setVisible(false);
		if(this.tmpUser instanceof MainManager)
		{
			statisticsButton.setVisible(true);
		}
		
		logOutButton = new JButton("Log out");
		logOutButton.setIcon(new ImageIcon(MainScreen.class.getResource("/img/icons8-exit-32.png")));
		logOutButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		logOutButton.setBounds(197, 538, 131, 51);
		logOutButton.addActionListener(this);
		getContentPane().add(logOutButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(MainScreen.class.getResource("/img/istockphoto-1014365320-612x612.jpg")));
		background.setBounds(-62, 11, 561, 611);
		getContentPane().add(background);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == addFriendButton)
		{
			new AddFriendFile(this.tmpUser);
		}
		if(e.getSource() == watchFriendRequestsButton)
		{
			new watchFriendRequestsFile(this.tmpUser);
		}
		if(e.getSource() == sendMassageToFriendButton)
		{
			new sendMassageToFriendFile(this.tmpUser);
		}
		if(e.getSource() == buildForumButton)
		{
			new BuildForumFile(this.tmpUser);
		}
		if(e.getSource() == sendMassageInForumButton)
		{
			new SendMassageInForumFile(this.tmpUser);
		}
		if(e.getSource() == managingUsersButton)
		{
			new ManagingUsersFile(this.tmpUser);
		}
		if(e.getSource() == sendExpressMassageButton)
		{
			new SendExpressMassageFile(this.tmpUser);
		}
		if(e.getSource() == addManagerButton)
		{
			new AddManagerFile(this.tmpUser);
		}
		if(e.getSource() == statisticsButton)
		{
			new StatisticsFile(this.tmpUser);
		}
		if(e.getSource() == logOutButton)
		{
			/*Setting the isConnected setting*/
			
			if(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()) instanceof MainManager)
			{
				((MainManager)DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName())).setIsConnected(false);
			}
			else if(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()) instanceof UsersManager)
			{
				((UsersManager)DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName())).setIsConnected(false);
			}
			else if(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()) instanceof ForumsManager)
			{
				((ForumsManager)DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName())).setIsConnected(false);
			}
			else if(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()) instanceof Member)
			{
				((Member)DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName())).setIsConnected(false);
			}
			
			new signInScreen();
		}
		this.setVisible(false);	
	}
}
