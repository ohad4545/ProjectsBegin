package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;  
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class WelcomeScreen extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	public JButton signInButton;
	public JButton signUpButton;
	public JLabel massageLabel;
	public JLabel background;

	public WelcomeScreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 300);
		getContentPane().setLayout(null);
		
		massageLabel = new JLabel("Welcome to \"SendIt\" system, please choose from the options below:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massageLabel.setBounds(40, 11, 484, 21);
		getContentPane().add(massageLabel);
		
		signUpButton = new JButton("Sign up");
		signUpButton.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/writing.png")));
		signUpButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		signUpButton.setBounds(189, 56, 143, 73);
		signUpButton.addActionListener(this);
		getContentPane().add(signUpButton);
		
		signInButton = new JButton("sign in");
		signInButton.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/sign-in.png")));
		signInButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		signInButton.setBounds(189, 153, 143, 73);
		signInButton.addActionListener(this);
		getContentPane().add(signInButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/mail.png")));
		background.setBounds(135, 11, 438, 239);
		getContentPane().add(background);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == signUpButton)
		{
			new SignUpScreen();
		}
		
		if(e.getSource() == signInButton)
		{
			new signInScreen();
		}
		this.setVisible(false);
		
	}
}
