package sendIt_208113332;

public class FriendRequest {
	private String userNameSent;
	private String userNameGot;
	private int status;//1=Confirm , 2 = Refuse , 3 = waiting
	
	/*constructor*/
	public FriendRequest(String userNameSent, String userNameGot) {
		super();
		this.userNameSent = userNameSent;
		this.userNameGot = userNameGot;
		this.status = 3; // waiting
	}

	/*Getters and Setters*/
	public String getUserNameSent() {
		return userNameSent;
	}

	public void setUserNameSent(String userNameSent) {
		this.userNameSent = userNameSent;
	}

	public String getUserNameGot() {
		return userNameGot;
	}

	public void setUserNameGot(String userNameGot) {
		this.userNameGot = userNameGot;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		if(status == 1 || status == 2 || status == 3)
			this.status = status;
	}

	/*toString Function*/
	@Override
	public String toString() {
		return "FriendRequest [userNameSent=" + userNameSent + ", userNameGot=" + userNameGot + ", status=" + status
				+ "]";
	}
}
