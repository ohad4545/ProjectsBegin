package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Map.Entry;
import javax.swing.ImageIcon;

public class StatisticsFile extends JFrame implements ActionListener{

	public JButton usersDetailsButton;
	public JButton forumsDetailsButton;
	public JLabel title;
	public JButton dailyMassagesButton;
	public JButton backToMenuButton;
	
	private User tmpUser;
	private JLabel background;
	
	public StatisticsFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 320);
		getContentPane().setLayout(null);
		
		usersDetailsButton = new JButton("Users details");
		usersDetailsButton.setIcon(new ImageIcon(StatisticsFile.class.getResource("/img/icons8-user-folder-48.png")));
		usersDetailsButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		usersDetailsButton.setBounds(75, 47, 266, 55);
		usersDetailsButton.addActionListener(this);
		getContentPane().add(usersDetailsButton);
		
		forumsDetailsButton = new JButton("Forums details");
		forumsDetailsButton.setIcon(new ImageIcon(StatisticsFile.class.getResource("/img/icons8-forum-48.png")));
		forumsDetailsButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		forumsDetailsButton.setBounds(75, 113, 266, 55);
		forumsDetailsButton.addActionListener(this);
		getContentPane().add(forumsDetailsButton);
		
		title = new JLabel("Statistics");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		title.setBounds(174, 11, 73, 25);
		getContentPane().add(title);
		
		dailyMassagesButton = new JButton("Daily Amount Of Massages");
		dailyMassagesButton.setIcon(new ImageIcon(StatisticsFile.class.getResource("/img/icons8-discussion-forum-30.png")));
		dailyMassagesButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		dailyMassagesButton.setBounds(75, 179, 266, 55);
		dailyMassagesButton.addActionListener(this);
		getContentPane().add(dailyMassagesButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(StatisticsFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(132, 244, 150, 23);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(StatisticsFile.class.getResource("/img/chart-g038fc9e70_640.png")));
		background.setBounds(0, 0, 434, 281);
		getContentPane().add(background);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == usersDetailsButton)
		{
			new UsersDetailsFile(this.tmpUser);
		}
		if(e.getSource() == forumsDetailsButton)
		{
			new ForumsDetailsFile(this.tmpUser);
		}
		if(e.getSource() == dailyMassagesButton)
		{
			/*This Comparator and TreeMap sort the massages by amount(main sort) (by date - deputy sort)*/
			Comparator<ArrayList<Massage>> comp = (al1,al2)->{
			int res = al1.size() - al2.size();
			int intDiff = 0;
			long diff = al1.get(0).getWhenSent().getTime() - al2.get(0).getWhenSent().getTime();
			if(diff > 0)
			{
				intDiff = 1;
			}
			else
			{
				intDiff = -1;
			}
			return res == 0? intDiff :res;
			};
			
			TreeMap<ArrayList<Massage>,Date> tmpMassagesByDateMap = new TreeMap<ArrayList<Massage>,Date>(comp);
			/**/
			
			/*Adding from the hashMap in DataBase that meant for this part to the TreeMap*/
			for(Entry<Date, ArrayList<Massage>> en: DataBase.massagesByDateMap.entrySet())
			{
				tmpMassagesByDateMap.put(en.getValue(), en.getKey());
			}
			System.out.println("These are the whole massages by Amount:");
			System.out.println();
			for(Entry<ArrayList<Massage>,Date> en: tmpMassagesByDateMap.entrySet())
			{
				System.out.println(en);
				System.out.println("*****************************************************************");
			}
		}
		
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
		}
		
		if(e.getSource() != dailyMassagesButton)
		{
			this.setVisible(false);
		}
	}
}
