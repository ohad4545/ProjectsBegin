package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class watchFriendRequestsFile extends JFrame implements ActionListener{

	public JLabel title;
	public JList<String> friendRequestList;
	public JRadioButton confirmButton;
	public JRadioButton refuseButton;
	public JButton backToMenuButton;
	public ButtonGroup bg;
	public JLabel massageLabel;
	public RadioButtonsListener rbl;
	public JLabel massageLabel2;
	public JLabel background;
	
	private User tmpUser;
	private String[] usersThatSentRequestArr;
	private User tmpFriend;
	
	public watchFriendRequestsFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		this.tmpUser = tmpUser;
		usersThatSentRequestArr = new String[0];
		this.tmpFriend = null;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
	
		title = new JLabel("Friend Requests");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		title.setBounds(152, 11, 131, 15);
		getContentPane().add(title);
		
		massageLabel = new JLabel("Please choose a user from the list:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massageLabel.setBounds(19, 49, 350, 15);
		getContentPane().add(massageLabel);
		
		/*Adding the friend requests users to the array that will be the array of the JList*/
		for(FriendRequest fr:DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()).getFriendRequestsMap().values())
		{
			usersThatSentRequestArr = Arrays.copyOf(usersThatSentRequestArr, usersThatSentRequestArr.length + 1);
			usersThatSentRequestArr[usersThatSentRequestArr.length - 1] = fr.getUserNameSent();
		}
		friendRequestList = new JList<String>(usersThatSentRequestArr);
		friendRequestList.setVisibleRowCount(4);
		friendRequestList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		friendRequestList.setBounds(23, 70, 260, 74);
		friendRequestList.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				
				tmpFriend = DataBase.UsersByUserNameMap.get(friendRequestList.getSelectedValue());
				if(tmpFriend == null)
				{
					tmpFriend = DataBase.removedUsersByUserNameMap.get(friendRequestList.getSelectedValue());
				}
				
				/*The current user already confirmed the selected list user friend request */
				if(DataBase.UsersByUserNameMap.get(tmpUser.getUserName()).getFriendRequestsMap().get(friendRequestList.getSelectedValue()).getStatus() == 1)
				{
					massageLabel2.setText("You confirmed the friend request of this user");
					massageLabel2.setVisible(true);
					confirmButton.setVisible(false);
					refuseButton.setVisible(false);	
				}
				
				/*The current user already refused the selected list user friend request */
				else if(DataBase.UsersByUserNameMap.get(tmpUser.getUserName()).getFriendRequestsMap().get(friendRequestList.getSelectedValue()).getStatus() == 2)
				{
					massageLabel2.setText("You refused to the friend request of this user");
					massageLabel2.setVisible(true);
					confirmButton.setVisible(false);
					refuseButton.setVisible(false);	
				}
				
				else // status = 3
				{
					confirmButton.setVisible(true);
					refuseButton.setVisible(true);
					massageLabel2.setVisible(false);
				}
				
				bg.clearSelection();
			}
		});
		add(friendRequestList);
		
		massageLabel2 = new JLabel("");
		massageLabel2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massageLabel2.setBounds(19, 150, 400, 23);
		massageLabel2.setVisible(false);
		getContentPane().add(massageLabel2);
		
		confirmButton = new JRadioButton("Confirm");
		confirmButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		confirmButton.setBounds(19, 150, 109, 23);
		confirmButton.setVisible(false);
		getContentPane().add(confirmButton);
		
		refuseButton = new JRadioButton("Refuse");
		refuseButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		refuseButton.setBounds(145, 153, 109, 23);
		refuseButton.setVisible(false);
		getContentPane().add(refuseButton);
		
		bg = new ButtonGroup();
		bg.add(confirmButton);
		bg.add(refuseButton);

		rbl = new RadioButtonsListener();
		confirmButton.addActionListener(rbl);
		refuseButton.addActionListener(rbl);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(AddFriendFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(115, 209, 180, 41);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(watchFriendRequestsFile.class.getResource("/img/add-friend (1).png")));
		background.setBounds(99, 0, 350, 272);
		getContentPane().add(background);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
		}
		this.setVisible(false);
		
	}
	
	/*This class meant to use as a listener to the confirm and refuse JRadioButtons */
	private class RadioButtonsListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			
			FriendRequest fr= tmpUser.getFriendRequestsMap().get(friendRequestList.getSelectedValue());
			if(e.getSource() == confirmButton)
			{
				fr.setStatus(1);
				String str = "src/";
				File f = null;
				User u = DataBase.UsersByUserNameMap.get(fr.getUserNameSent());
				
				if(u == null)
				{
					u = DataBase.removedUsersByUserNameMap.get(fr.getUserNameSent());
				}
				
				/*Building the massages between friends file according to their id , when the lower value id is at the left side of the file*/
				if(u.getId() > DataBase.UsersByUserNameMap.get(fr.getUserNameGot()).getId())
				{
					str += String.valueOf(DataBase.UsersByUserNameMap.get(fr.getUserNameGot()).getId()) + "" + String.valueOf(u.getId());
				}
				
				else
				{
					str += String.valueOf(u.getId()) + "" + String.valueOf(DataBase.UsersByUserNameMap.get(fr.getUserNameGot()).getId());
				}
				
				str += ".txt";
				
				try
				{
					/*creating the massages file and add the friend to the fit User data structure*/
					
					f = new File(str);
					f.createNewFile();
					
					DataBase.UsersByUserNameMap.get(tmpUser.getUserName()).getFriendsMassagesMap().put(tmpFriend.getUserName(),new ArrayList<Massage>());
					DataBase.UsersByIdMap.put(tmpUser.getId(),tmpUser);
					
					if(DataBase.UsersByUserNameMap.get(tmpFriend.getUserName()) != null)
					{
						DataBase.UsersByUserNameMap.get(tmpFriend.getUserName()).getFriendsMassagesMap().put(tmpUser.getUserName(), new ArrayList<Massage>());
						DataBase.UsersByIdMap.put(tmpFriend.getId(),tmpFriend);
					}
					else
					{
						DataBase.removedUsersByUserNameMap.get(tmpFriend.getUserName()).getFriendsMassagesMap().put(tmpUser.getUserName(), new ArrayList<Massage>());
						DataBase.removedUsersByIdMap.put(tmpFriend.getId(),tmpFriend);
					}
					
					massageLabel2.setText("You confirmed the friend request of this user");
					
				}
				catch(IOException ex)
				{
					System.out.println("Something went wrong with creating one of the massages files");
				}
				
				JOptionPane.showMessageDialog(null, "Friend Request confirmed");
			}
			
			if(e.getSource() == refuseButton)
			{
				fr.setStatus(2);
				massageLabel2.setText("You refused the friend request of this user");
				JOptionPane.showMessageDialog(null, "Friend Request refused");
			}
			
			massageLabel2.setVisible(true);
			confirmButton.setVisible(false);
			refuseButton.setVisible(false);
			
			DataBase.writeToFriendRequestsFile();
		}	
	}
}
