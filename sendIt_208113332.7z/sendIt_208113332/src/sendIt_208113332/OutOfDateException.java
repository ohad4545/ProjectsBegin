package sendIt_208113332;

public class OutOfDateException extends Exception {
	
	/*constructors*/
	public OutOfDateException()
	{
		super();
	}
	public OutOfDateException(String massage)
	{
		super(massage);
	}
}
