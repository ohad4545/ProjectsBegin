package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JButton;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class UsersDetailsFile extends JFrame implements ItemListener,ActionListener{

	public JPanel panelUp;
	public JLabel massageLabel;
	public JPanel panelDown;
	public JScrollPane scrollPane;
	public JTextArea usersDetails_ta;
	public JComboBox<String> usersComboBox;
	public JButton backButton;
	
	private User tmpUser;
	
	public UsersDetailsFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 400);
		getContentPane().setLayout(null);

		panelUp = new JPanel();
		panelUp.setBackground(Color.WHITE);
		panelUp.setBounds(10, 11, 414, 40);
		getContentPane().add(panelUp);
		
		massageLabel = new JLabel("Please choose a user from the users at the list:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		panelUp.add(massageLabel);
		
		panelDown = new JPanel();
		panelDown.setBackground(Color.WHITE);
		panelDown.setBounds(20, 95, 404, 185);
		getContentPane().add(panelDown);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panelDown.add(scrollPane);
		
		usersDetails_ta = new JTextArea();
		usersDetails_ta.setEditable(false);
		usersDetails_ta.setColumns(30);
		usersDetails_ta.setRows(8);
		scrollPane.setViewportView(usersDetails_ta);
		
		usersComboBox = new JComboBox<String>();
		usersComboBox.setBounds(115, 62, 215, 22);
		usersComboBox.addItem("");
		
		/*Adding the users to the combo box*/
		for(User u:DataBase.UsersByIdMap.values())
		{
			usersComboBox.addItem(String.valueOf(u.getId()) + " " + u.getFirstName() + " " + u.getLastName());
		}
		usersComboBox.addItemListener(this);
		getContentPane().add(usersComboBox);
		
		backButton = new JButton("Back");
		backButton.setIcon(new ImageIcon(UsersDetailsFile.class.getResource("/img/return.png")));
		backButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backButton.setBounds(170, 307, 89, 23);
		backButton.addActionListener(this);
		getContentPane().add(backButton);
		
		setVisible(true);
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(usersComboBox.getSelectedIndex() == 0)
		{
			usersDetails_ta.setText("");
		}
		else
		{
			String line = String.valueOf(usersComboBox.getSelectedItem());
			String[] strArr = line.split(" ");
			
			usersDetails_ta.setText(DataBase.UsersByIdMap.get(Integer.parseInt(strArr[0])).toString());
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == backButton)
		{
			new StatisticsFile(this.tmpUser);
			setVisible(false);
		}
	}

}
