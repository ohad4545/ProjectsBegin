package sendIt_208113332;

import java.util.Date;

public class ExpressMassage extends Massage{

	private static int counter = 0;
	private int massageCode;
	
	/*constructors*/
	public ExpressMassage(String text, Date whenSent)
	{
		super(text, whenSent);
		ExpressMassage.counter++;
		this.massageCode = ExpressMassage.counter;
	}
	
	public ExpressMassage(int massageCode)
	{
		super();
		this.massageCode = massageCode;
	}

	/*Getters and Setters*/
	public static int getCounter() {
		return counter;
	}

	public static void setCounter(int counter) {
		ExpressMassage.counter = counter;
	}

	public int getMassageCode() {
		return massageCode;
	}

	public void setMassageCode(int massageCode) {
		this.massageCode = massageCode;
	}

	/*equals function by massageCode*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExpressMassage other = (ExpressMassage) obj;
		if (massageCode != other.massageCode)
			return false;
		return true;
	}
	
	/*toString function*/
	@Override
	public String toString() {
		return super.toString() + " ExpressMassage [massageCode=" + massageCode + "]";
	}
}
