package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class SignUpScreen extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	public JTextField userName_tf;
	public JTextField firstName_tf;
	public JTextField lastName_tf;
	public JLabel userNameLabel;
	public JLabel massageLabel;
	public JLabel passwordLabel;
	public JPasswordField passwordField;
	public JLabel firstNameLabel;
	public JLabel lastNameLabel;
	public JButton signUpButton;
	public JButton clearButton;
	public JButton signInButton;
	public JLabel massage2Label;
	public JLabel background;
	
	public SignUpScreen() {
		getContentPane().setBackground(Color.WHITE);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 400);
		getContentPane().setLayout(null);
		
		userNameLabel = new JLabel("userName:");
		userNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		userNameLabel.setBounds(76, 92, 82, 21);
		getContentPane().add(userNameLabel);
		
		massageLabel = new JLabel("Please type the details that you will use to enter the system:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massageLabel.setBounds(10, 42, 414, 39);
		getContentPane().add(massageLabel);
		
		userName_tf = new JTextField();
		userName_tf.setBounds(168, 92, 124, 21);
		getContentPane().add(userName_tf);
		userName_tf.setColumns(10);
		
		passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		passwordLabel.setBounds(76, 119, 82, 28);
		getContentPane().add(passwordLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(168, 126, 124, 21);
		getContentPane().add(passwordField);
		
		firstNameLabel = new JLabel("first name:");
		firstNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		firstNameLabel.setBounds(76, 158, 82, 26);
		getContentPane().add(firstNameLabel);
		
		firstName_tf = new JTextField();
		firstName_tf.setBounds(168, 164, 124, 20);
		getContentPane().add(firstName_tf);
		firstName_tf.setColumns(10);
		
		lastNameLabel = new JLabel("last name:");
		lastNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lastNameLabel.setBounds(76, 193, 82, 21);
		getContentPane().add(lastNameLabel);
		
		lastName_tf = new JTextField();
		lastName_tf.setBounds(168, 196, 124, 20);
		getContentPane().add(lastName_tf);
		lastName_tf.setColumns(10);
		
		signUpButton = new JButton("sign up");
		signUpButton.setIcon(new ImageIcon(SignUpScreen.class.getResource("/img/writing (1).png")));
		signUpButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		signUpButton.setBounds(152, 230, 114, 28);
		signUpButton.addActionListener(this);
		getContentPane().add(signUpButton);
		
		clearButton = new JButton("clear");
		clearButton.setIcon(new ImageIcon(SignUpScreen.class.getResource("/img/archeology.png")));
		clearButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		clearButton.setBounds(152, 310, 114, 28);
		clearButton.addActionListener(this);
		getContentPane().add(clearButton);
		
		signInButton = new JButton("sign in");
		signInButton.setIcon(new ImageIcon(SignUpScreen.class.getResource("/img/sign-in (1).png")));
		signInButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		signInButton.setBounds(152, 269, 114, 28);
		signInButton.addActionListener(this);
		getContentPane().add(signInButton);
		
		massage2Label = new JLabel("Sign Up");
		massage2Label.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		massage2Label.setBounds(179, 11, 73, 28);
		getContentPane().add(massage2Label);
		
		background = new JLabel("");
		background.setBackground(Color.WHITE);
		background.setIcon(new ImageIcon(SignUpScreen.class.getResource("/img/12.jpg")));
		background.setBounds(-28, -48, 518, 422);
		getContentPane().add(background);
		
		setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == signUpButton)
		{
			Member tmpMember = null;
			try
			{
				/*Missing field*/
				if(userName_tf.getText().equals("") || String.valueOf(passwordField.getPassword()).equals("") 
				   || firstName_tf.getText().equals("") || lastName_tf.getText().equals(""))
				{
					throw new NullPointerException();
				}
				
				/*User already exists (or removed)*/
				if(DataBase.UsersByUserNameMap.get(userName_tf.getText()) != null || DataBase.removedUsersByUserNameMap.get(userName_tf.getText()) != null)
				{
					throw new UnauthorizedException();
				}
				
				/*Because only a main manager can add managers, I assumed that the signUp screen is meant only for registering of members*/
				/*Adding the userName to the fit data structure and write it to the fit file*/
				tmpMember = new Member(userName_tf.getText(),String.valueOf(passwordField.getPassword()),
							firstName_tf.getText(),lastName_tf.getText());
				
				DataBase.UsersByUserNameMap.put(userName_tf.getText(),tmpMember);
				DataBase.UsersByIdMap.put(tmpMember.getId(),tmpMember);
				
				DataBase.writeToUsersFile("src/Users.txt",DataBase.UsersByUserNameMap);	
				
				JOptionPane.showMessageDialog(null, "You have singed up successfully");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one the the fields is empty, please fill the whole fields");
			}
			catch (UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "The user is already exists in the system, please type another user name");
			}
				
		}
		
		if(e.getSource() == signInButton)
		{
			new signInScreen();
			this.setVisible(false);
		}
		
		if(e.getSource() == clearButton)
		{
			userName_tf.setText("");
			passwordField.setText("");
			firstName_tf.setText("");
			lastName_tf.setText("");
		}
		
	}
}
