package sendIt_208113332;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.Date;

/*Service class*/
public class DataBase {

	public static HashMap<String,User> UsersByUserNameMap = new HashMap<String,User>();
	public static HashMap<Integer,User> UsersByIdMap = new HashMap<Integer,User>();
	public static HashMap<String,User> removedUsersByUserNameMap = new HashMap<String,User>();
	public static HashMap<Integer,User> removedUsersByIdMap = new HashMap<Integer,User>();
	public static ArrayList<Forum> forumsList = new ArrayList<Forum>();
	
	/*This Comparator and TreeSet are using for the list of users in add friend file(compared by last name)*/
	public static Comparator<User> comp2 = (u1,u2)->
	{
		int res1 = u1.getLastName().toLowerCase().compareTo(u2.getLastName().toLowerCase());
		int res2 = u1.getUserName().compareTo(u2.getUserName());
		return res1 == 0?res2:res1;
	};
	public static TreeSet<User> usersSet = new TreeSet<User>(comp2);
	/**/
	
	/*This map is meant for the daily massages part(in statistics file)*/
	public static HashMap<Date,ArrayList<Massage>> massagesByDateMap = new HashMap<Date,ArrayList<Massage>>();
	
	/*Functions*/
	/*This function reads the whole information from the fit files to the fit data structures*/
	public static void readFromFiles()
	{
		readUsersFiles();
		readFriendRequestsFile();
		addToFriendsMap(DataBase.UsersByUserNameMap);
		addToFriendsMap(DataBase.removedUsersByUserNameMap);
		readMassageFromMassageText();
		readForumsDetailsFile();
		readMassageFromFitForumFile();
	}
		
	/*This function meant for writing the information to Users.txt or to RemovedUsers.txt file, depends on the file path and the data structure the function gets */
	public static void writeToUsersFile(String filePath,HashMap<String,User> hm)
	{
		BufferedWriter writer = null;
		String line = "";
		try
		{
			writer = new BufferedWriter(new FileWriter(filePath));
			for(User u:hm.values())
			{
				if(u instanceof UsersManager)
				{
					line += "UsersManager ";
				}
				else if(u instanceof ForumsManager)
				{
					line += "ForumsManager ";
				}
				else if(u instanceof Member)
				{
					line += "Member ";
				}
				else if(u instanceof MainManager)
				{
					line += "MainManager ";
				}
				
				line += u.getUserName() + " " + u.getPassword() + " " + u.getFirstName() + " " + u.getLastName() +
						" " + String.valueOf(u.getId()) + " " + String.valueOf(u.getMassagesAmount() + " " + String.valueOf(u.getIsBlocked()));
				writer.append(line);
				writer.newLine();
				line = "";
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening Users.txt or RemovedUsers.txt for writing");
		}
		finally
		{
			try
			{
				if(writer!= null)
				{
					writer.close();
				} 
			}
			catch (IOException ex)
			{
				System.out.println("Something went wrong with closing Users.txt or RemovedUsers.txt for writing");
			}
		}	
	}
	
	/*This function writes the friend requests of the users to Requests.txt file*/
	public static void writeToFriendRequestsFile()
	{
		try
		{
			BufferedWriter writer = new BufferedWriter(new FileWriter("src/Requests.txt"));
			writer.close();
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening or closing the Requests.txt file for writing");
		}
		writeToFriendRequestsFile(DataBase.UsersByUserNameMap);
		writeToFriendRequestsFile(DataBase.removedUsersByUserNameMap);
	}
	
	/*This function is a help function to writeToFriendRequestsFile (another function same name; overload)*/
	public static void writeToFriendRequestsFile(HashMap<String,User> hm)
	{
		BufferedWriter writer = null;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/Requests.txt",true));
			String line = "";
			for(User u:hm.values())
			{
				for(FriendRequest fr:u.getFriendRequestsMap().values())
				{
					line += u.getUserName() + " " + fr.getUserNameSent() + " " + fr.getUserNameGot() + " " + fr.getStatus();
					writer.append(line);
					writer.newLine();
					line = "";
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening Requests.txt file for writing");
		}
		finally
		{
			try
			{
				writer.close();
			}
			catch(IOException ex)
			{
				System.out.println("Something went wrong with closing FriendRequests.txt file");
			}
		}
	}
	
	/*This function reads the information from Users.txt file and RemovedUsers.txt file and adds it to the fit data structures*/
	public static void readUsersFiles()
	{
		readUsersOrRemovedUsers("src/Users.txt");
		readUsersOrRemovedUsers("src/RemovedUsers.txt");
	}
	
	/*This function meant for reading the users or the removed users from Users.txt file or RemovedUsers.txt file to the fit data structure in DataBase,depends on the file path the function gets*/
	public static void readUsersOrRemovedUsers(String filePath)
	{
		File f = null;
		Scanner scn = null;
		String line = "";
		String []infoArr;
		User u = null;
		try
		{
			f = new File(filePath);
			scn = new Scanner(f);
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				infoArr = line.split(" ");
				u = createUserFromUserFileInfo(infoArr);
				
				if(filePath.equals("src/Users.txt"))
				{
					DataBase.UsersByUserNameMap.put(infoArr[1], u);
					DataBase.UsersByIdMap.put(Integer.parseInt(infoArr[5]), u);
					
				}
				else if(filePath.equals("src/RemovedUsers.txt"))
				{
					DataBase.removedUsersByUserNameMap.put(u.getUserName(), u);
					DataBase.removedUsersByIdMap.put(u.getId(), u);
				}
			}	
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening RemovedUsers.txt file for reading");
		}
		
		finally
		{
			if(scn!= null)
				scn.close();
		}
	}
	
	/*This function read the friend requests from Requests.txt file and adds the info to the fit data structure*/
	public static void readFriendRequestsFile()
	{
		File f = null;
		Scanner scn = null;
		String line = "";
		String[] infoArr;
		
		try
		{
			f = new File("src/Requests.txt");
			scn = new Scanner(f);
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				infoArr = line.split(" ");
				FriendRequest fr = new FriendRequest(infoArr[1],infoArr[2]);
				fr.setStatus(Integer.parseInt(infoArr[3]));
				
				if(DataBase.UsersByUserNameMap.get(infoArr[0]) != null) //User exists at the system(was not removed)
				{
					DataBase.UsersByUserNameMap.get(infoArr[0]).getFriendRequestsMap().put(fr.getUserNameSent(),fr);
					DataBase.UsersByIdMap.put(DataBase.UsersByUserNameMap.get(infoArr[0]).getId(),DataBase.UsersByUserNameMap.get(infoArr[0]));
				}
				
				else//User removed from the system
				{
					DataBase.removedUsersByUserNameMap.get(infoArr[0]).getFriendRequestsMap().put(fr.getUserNameSent(), fr);
					DataBase.removedUsersByIdMap.put(DataBase.removedUsersByUserNameMap.get(infoArr[0]).getId(), DataBase.removedUsersByUserNameMap.get(infoArr[0]));
				}
			}
		}
		
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening Requests.txt file for reading");
		}
		
		finally
		{
			if(scn != null)
			{
				scn.close();
			}
		}
	}
	
	/*This function creates a user from the information of the Users.txt file*/
	public static User createUserFromUserFileInfo(String[] infoArr)
	{
		User u = null;
		if(infoArr[0].equals("MainManager"))
		{
			u = new MainManager(infoArr[1],infoArr[2],infoArr[3],infoArr[4]);
			
		}
		else if(infoArr[0].equals("Member"))
		{
			u = new Member(infoArr[1],infoArr[2],infoArr[3],infoArr[4]);
		}
		else if(infoArr[0].equals("ForumsManager"))
		{
			u = new ForumsManager(infoArr[1],infoArr[2],infoArr[3],infoArr[4]);
		}
		else if(infoArr[0].equals("UsersManager"))
		{
			u = new UsersManager(infoArr[1],infoArr[2],infoArr[3],infoArr[4]);
		}

		u.setId(Integer.parseInt(infoArr[5]));
		u.setMassagesAmount(Integer.parseInt(infoArr[6]));
		u.setBlocked(Boolean.parseBoolean(infoArr[7]));
		return u;
	}
	
	/*This function writes the massage the user1 sent to the other user2 (or the opposite) at the right massage text file*/
	public static void writeMassageToMassageText(User user1,User user2)
	{
		int min = Math.min(user1.getId(), user2.getId());
		int max = Math.max(user1.getId(), user2.getId());
		String str = "src/" + String.valueOf(min) + "" + String.valueOf(max) + ".txt";
		BufferedWriter writer = null;
		try
		{
			writer = new BufferedWriter(new FileWriter(str));
			Iterator<Massage> itr = user1.getFriendsMassagesMap().get(user2.getUserName()).iterator();
			while(itr.hasNext())
			{
				Massage m = itr.next();
				writer.append(m.getText().substring(0, 10) + " ");//The part of the date in the massage
				writer.write(m.getText().substring(10).replace(" ", ")("));//The rest of the massage
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening id's massages file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Something went wrong with closing the writer of the id's massages text files");
			}
		}
	}
	
	/*This function adds the whole status 1(confirmed) friends to the friendsMap of the fit users */
	public static void addToFriendsMap(HashMap<String,User> hm)
	{
		for(User u:hm.values())
		{
			for(FriendRequest fr:u.getFriendRequestsMap().values())
			{
				if(fr.getStatus() == 1)//confirmed
				{
					u.getFriendsMassagesMap().put(fr.getUserNameSent(), new ArrayList<Massage>());
					if(DataBase.UsersByUserNameMap.get(fr.getUserNameSent()) != null)
					{
						DataBase.UsersByUserNameMap.get(fr.getUserNameSent()).getFriendsMassagesMap().put(u.getUserName(), new ArrayList<Massage>());
						DataBase.UsersByIdMap.put(DataBase.UsersByUserNameMap.get(fr.getUserNameSent()).getId(), DataBase.UsersByUserNameMap.get(fr.getUserNameSent()));
					}
					
					else if(DataBase.UsersByUserNameMap.get(fr.getUserNameSent()) == null)
					{
						DataBase.removedUsersByUserNameMap.get(fr.getUserNameSent()).getFriendsMassagesMap().put(u.getUserName(), new ArrayList<Massage>());
						DataBase.removedUsersByIdMap.put(DataBase.removedUsersByUserNameMap.get(fr.getUserNameSent()).getId(), DataBase.removedUsersByUserNameMap.get(fr.getUserNameSent()));
					}
				}
			}
		}
	}
	
	/*This function reads the whole information from the users massages text files to the fit users data structures*/
	public static void readMassageFromMassageText()
	{	
		ArrayList<String> userIdWeVisited = new ArrayList<String>();
		readMassageFromMassageText(DataBase.UsersByUserNameMap,userIdWeVisited);
		readMassageFromMassageText(DataBase.removedUsersByUserNameMap,userIdWeVisited);
	}
	
	/*This function is a help function for readMassageFromMassageText another function(overload)*/
	public static void readMassageFromMassageText(HashMap<String,User> hm , ArrayList<String> userIdWeVisited)
	{
		File f = null;
		Scanner scn = null;
		String line = "";
		String[] infoArr;
		Massage m = null;
		int min = 0;
		int max = 0;

		for(User u:hm.values())
		{
			for(String s:u.getFriendsMassagesMap().keySet())
			{
				if(hm.get(s) == null)
				{
					if(hm == DataBase.UsersByUserNameMap)
					{
						min = Math.min(u.getId(), DataBase.removedUsersByUserNameMap.get(s).getId());
						max = Math.max(u.getId(), DataBase.removedUsersByUserNameMap.get(s).getId());
					}
					else//DataBase.removedUsersByUserNameMap
					{
						min = Math.min(u.getId(), DataBase.UsersByUserNameMap.get(s).getId());
						max = Math.max(u.getId(), DataBase.UsersByUserNameMap.get(s).getId());
					}
				}
				else
				{
					min = Math.min(u.getId(), hm.get(s).getId());
					max = Math.max(u.getId(), hm.get(s).getId());
				}
				
				String str = "src/" + String.valueOf(min) + "" + String.valueOf(max) + ".txt";
				try
				{
					f = new File(str);
					scn = new Scanner(f);
					while(scn.hasNextLine())
					{
						line = scn.nextLine();
						infoArr = line.split(" ");
						Date tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(infoArr[0]);
						String massageText = infoArr[0] + infoArr[1].replace(")(", " ");
						m = new Massage(massageText + '\n',tmpDate);
						
						if(!userIdWeVisited.contains(String.valueOf(min) + "" + String.valueOf(max)))
						{
							addToDaliyMassagesMap(m);
						}
						
						u.getFriendsMassagesMap().get(s).add(m);
						
						if(hm == DataBase.UsersByUserNameMap)
						{
							DataBase.UsersByIdMap.put(u.getId(), u);
						}
								
						else if(hm == DataBase.removedUsersByUserNameMap)
						{
							DataBase.removedUsersByIdMap.put(u.getId(), u);
						}
					}
					
					if(!userIdWeVisited.contains(String.valueOf(min) + "" + String.valueOf(max)))
					{
						userIdWeVisited.add(String.valueOf(min) + String.valueOf(max));
					}
				}
				catch(IOException ex)
				{
					System.out.println("Something went wrong with open id's massages file for reading");
				}
				catch(ParseException ex)
				{
					System.out.println("Something went wrong with parsing one of the dates");
				}
				finally
				{
					if(scn != null)
						scn.close();
				}
			}
		}
	}
	
	/*This function writes the whole forums details to ForumsDetails.txt file*/
	public static void writeToForumsDetailsFile()
	{
		try
		{
			BufferedWriter writer = new BufferedWriter(new FileWriter("src/ForumsDetails.txt"));
			writer.close();
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening or closing ForumsDetails.txt file for writing");
		}
		writeToForumsDetailsFile(DataBase.UsersByUserNameMap);
		writeToForumsDetailsFile(DataBase.removedUsersByUserNameMap);
	}
	
	/*This function is a help function to writeToForumsDetailsFile function(overload)*/
	public static void writeToForumsDetailsFile(HashMap<String,User> hm)
	{
		BufferedWriter writer = null;
		try
		{
			writer = new BufferedWriter(new FileWriter("src/ForumsDetails.txt",true));
			for(User u:hm.values())
			{
				for(Forum f:u.getForumsList())
				{
					writer.append(f.getForumName().replace(" ", ")(") + " " + String.valueOf(f.getForumCode()) + " "
							 + f.getFilePathForum() + " " + f.getDescription().replace(" ", ")("));
					writer.newLine();
				}
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening ForumsDetails.txt file for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Something went wrong with the closing ForumsDetails.txt file writing");
			}
		}
	}
	
	/*This function reads the info of the forums and adds it to the fit data structures*/
	public static void readForumsDetailsFile()
	{
		File f = null;
		Scanner scn = null;
		String line = null;
		String[] strArr;
		String tmpForumName = "";
		String tmpForumDescription = "";
		Forum tmpForum = null;
		int tmpUserId;
		try
		{
			f = new File("src/ForumsDetails.txt");
			scn = new Scanner(f);
			while(scn.hasNextLine())
			{
				line = scn.nextLine();
				strArr = line.split(" ");
			
				tmpForumName = strArr[0].replace(")(", " ");
				tmpForumDescription = strArr[3].replace(")(", " ");
				tmpForum = new Forum(tmpForumName,tmpForumDescription);
				tmpForum.setFilePathForum(strArr[2]);
				tmpForum.setForumCode(Integer.parseInt(strArr[1]));
				tmpUserId = getForumUserId(strArr[2]);
				if(DataBase.UsersByIdMap.get(tmpUserId) != null)//User exists at the system
				{
					DataBase.UsersByIdMap.get(tmpUserId).getForumsList().add(tmpForum);
					DataBase.UsersByUserNameMap.put(DataBase.UsersByIdMap.get(tmpUserId).getUserName(), DataBase.UsersByIdMap.get(tmpUserId));
				}
				else//User was removed from the system
				{
					DataBase.removedUsersByIdMap.get(tmpUserId).getForumsList().add(tmpForum);
					DataBase.removedUsersByUserNameMap.put(DataBase.removedUsersByIdMap.get(tmpUserId).getUserName(), DataBase.removedUsersByIdMap.get(tmpUserId));
				}
				DataBase.forumsList.add(tmpForum);
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening ForumsDetails.txt file for reading");
		}
		
		finally
		{
			if(scn != null)
			{
				scn.close();
			}
		}
	}
	
	/*This function creates the id of the user who built the forum*/
	public static int getForumUserId(String filePathForum)
	{
		int startIndex = filePathForum.length() - 1;
		int endIndex = filePathForum.length() - 1;
		
		while(filePathForum.charAt(startIndex - 1) != 'D')
		{
			if(filePathForum.charAt(endIndex) != '.')
			{
				endIndex--;
			}
			startIndex--;
		}
		
		int tmpUserId = Integer.parseInt(filePathForum.substring(startIndex, endIndex));
		return tmpUserId;
	}
	
	/*This function adds a massage to the HashMap massages in database*/
	public static void addToDaliyMassagesMap(Massage m)
	{
		ArrayList<Massage> al = DataBase.massagesByDateMap.get(m.getWhenSent());
		if(al == null)
		{
			al = new ArrayList<Massage>();
		}
		
		al.add(m);
		DataBase.massagesByDateMap.put(m.getWhenSent(), al);
	}

	/*This function write the massage of the forum in the fit forum file*/
	public static void writeMassageToFitForumMassagesFile(int forumCode, int userId,Forum f) 
	{
		String fileName = "src/Forum" + String.valueOf(forumCode) + "ID" + String.valueOf(userId) + ".txt";
		BufferedWriter writer = null;
		try
		{
			writer = new BufferedWriter(new FileWriter(fileName));
			for(Massage m:f.getForumMassagesList())
			{
				if(!(m instanceof ExpressMassage))
				{
					writer.write(m.getText());
				}
				else //Express Massage
				{
					writer.write(m.getText().substring(0, m.getText().length() - 1) + " )(ExpressMassage " + String.valueOf(((ExpressMassage)m).getMassageCode()));
					writer.newLine();
				}
				
			}
		}
		catch(IOException ex)
		{
			System.out.println("Something went wrong with opening forums massages text files for writing");
		}
		finally
		{
			try
			{
				if(writer != null)
				{
					writer.close();
				}
			}
			catch(IOException ex)
			{
				System.out.println("Something went wrong with closing forums massages text file writing");
			}
		}
	}
	
	/*This function meant for reading to the fit data structures the fit massages from the fit forum file*/
	public static void readMassageFromFitForumFile()
	{
		readMassageFromFitForumFile(DataBase.UsersByUserNameMap);
		readMassageFromFitForumFile(DataBase.removedUsersByUserNameMap);
	}
	
	/*This function is a help function to readMassageFromFitForumFile function(overload)*/
	public static void readMassageFromFitForumFile(HashMap<String,User> hm)
	{
		File file = null;
		Scanner scn = null; 
		String line = "";
		Massage m = null;
		String[] strArr;
		
		for(User u:hm.values())
		{
			for(Forum f:u.getForumsList())
			{
				try
				{
					file = new File(f.getFilePathForum());
					scn = new Scanner(file);
					while(scn.hasNextLine())
					{
						line = scn.nextLine();
						strArr = line.split(" ");
						Date tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(strArr[0]);
						if(strArr[strArr.length - 2].equals(")(ExpressMassage"))//Express Massage
						{
							String tmpStr = "";
							for(int i=0;i < strArr.length - 2;i++)
							{
								tmpStr += strArr[i] + " ";
							}
							m = new ExpressMassage(tmpStr + '\n',tmpDate);
							((ExpressMassage)m).setMassageCode(Integer.parseInt(strArr[strArr.length - 1]));
							ExpressMassage.setCounter(Integer.parseInt(strArr[strArr.length - 1]));
						}
						else
						{
							m = new Massage(line + '\n',tmpDate);
						}
						
						f.getForumMassagesList().add(m);
						if(hm == DataBase.UsersByUserNameMap)
						{
							DataBase.UsersByIdMap.put(u.getId(), u);
						}
						else if(hm == DataBase.removedUsersByUserNameMap)
						{
							DataBase.removedUsersByIdMap.put(u.getId(), u);
						}
							
						m = f.getForumMassagesList().get(f.getForumMassagesList().indexOf(m));
						if(m instanceof ExpressMassage) 
						{
							if(DataBase.massagesByDateMap.get(m.getWhenSent()) != null)
							{
								if(!DataBase.massagesByDateMap.get(m.getWhenSent()).contains(m))
								{
									DataBase.addToDaliyMassagesMap(m);
								}
							}
							
							else if(DataBase.massagesByDateMap.get(m.getWhenSent()) == null)
							{
								DataBase.addToDaliyMassagesMap(m);
							}
						}
					}
				}
				catch(ParseException ex)
				{
					System.out.println("Something went wrong with parsing the date");
				}
				catch(IOException ex)
				{
					System.out.println("Something went wrong with opening one of the forums massages file for reading");
				}
			}
		}
	}
}


