package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.awt.event.ItemEvent;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import javax.swing.ImageIcon;
import java.awt.Color;

public class sendMassageToFriendFile extends JFrame implements ActionListener,ItemListener{

	public JPanel p1;
	public JLabel massageLabel;
	public JComboBox<String> friendsComboBox;
	public JScrollPane scrollPane1;
	public JTextArea pastMassages;
	public JScrollPane scrollPane2;
	public JPanel p2;
	public JPanel panel;
	public JScrollPane scrollPane;
	public JTextArea currentMassage;
	public JLabel previousMassages;
	public JLabel currentMassageLabel;
	public JButton sendButton;
	public JButton backToMenuButton;
	public JLabel dateLabel;
	public JDateChooser dateChooser;
	public JTextFieldDateEditor editor;
	
	private User tmpUser;
	
	public sendMassageToFriendFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 650);
		getContentPane().setLayout(null);
		
		p1 = new JPanel();
		p1.setBackground(Color.WHITE);
		p1.setBounds(10, 11, 424, 62);
		getContentPane().add(p1);
		
		p2 = new JPanel();
		p2.setBackground(Color.WHITE);
		p2.setBounds(42, 84, 372, 190);
		getContentPane().add(p2);
		
		massageLabel = new JLabel("Please choose the friend you would like to send a massage:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		p1.add(massageLabel);
		
		friendsComboBox = new JComboBox<String>();
		friendsComboBox.addItem("");
		
		/*Adding only the not removed friends of the users to the combo box(assume:only the not removed friends need to be added)*/
		for(String s:this.tmpUser.getFriendsMassagesMap().keySet())
		{
			if(DataBase.removedUsersByUserNameMap.get(s) == null)//The friend is not a user which has been removed
				friendsComboBox.addItem(s);
		}
		friendsComboBox.addItemListener(this);
		p1.add(friendsComboBox);
		
		previousMassages = new JLabel("Previous Massages:");
		p2.add(previousMassages);
		previousMassages.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		
		scrollPane1 = new JScrollPane();
		scrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane1.setBounds(10, 94, 414, 83);
		p2.add(scrollPane1);
		
		pastMassages = new JTextArea();
		pastMassages.setColumns(30);
		pastMassages.setRows(8);
		pastMassages.setEditable(false);
		scrollPane1.setViewportView(pastMassages);
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(42, 285, 372, 196);
		getContentPane().add(panel);
		
		currentMassageLabel = new JLabel("You type your current Masssage here:");
		panel.add(currentMassageLabel);
		currentMassageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panel.add(scrollPane);
		
		currentMassage = new JTextArea();
		currentMassage.setColumns(30);
		currentMassage.setRows(8);
		scrollPane.setViewportView(currentMassage);
		
		sendButton = new JButton("Send");
		sendButton.setIcon(new ImageIcon(sendMassageToFriendFile.class.getResource("/img/send.png")));
		sendButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendButton.setBounds(42, 551, 149, 36);
		sendButton.addActionListener(this);
		getContentPane().add(sendButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(sendMassageToFriendFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(265, 551, 149, 36);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		dateLabel = new JLabel("Date the current Massage is sent:");
		dateLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		dateLabel.setBounds(42, 503, 254, 28);
		getContentPane().add(dateLabel);
		
		dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("dd/MM/yyyy");
		dateChooser.setBounds(304, 512, 130, 19);
		editor = (JTextFieldDateEditor) dateChooser.getDateEditor();
		editor.setEditable(false);
		getContentPane().add(dateChooser);
		
		this.setVisible(true);			
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == sendButton)
		{
			try
			{
				if(currentMassage.getText().equals("") || editor.getText().equals("") || friendsComboBox.getSelectedIndex() == 0)
				{
					throw new NullPointerException();
				}
				
				/*Adding the massage to the fit data structures and writes to the fit file*/
				
				Date tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(editor.getText());
				@SuppressWarnings("deprecation")
				Date dateTheSystemWasOpened = new Date(122,1,1); // 1/2/2022
				if(tmpDate.getTime() - dateTheSystemWasOpened.getTime() < 0)//tmpDate is earlier than 1/2/2022
				{
					throw new OutOfDateException();
				}
				
				String currentMassageText = currentMassage.getText();
				Massage m = new Massage(editor.getText() + " " + this.tmpUser.getFirstName().replace(" ", "-")
				 + ": " + currentMassageText + '\n',tmpDate);
				
				this.tmpUser.setMassagesAmount(this.tmpUser.getMassagesAmount() + 1);
				this.tmpUser.getFriendsMassagesMap().get(String.valueOf(friendsComboBox.getSelectedItem())).add(m);
				
				DataBase.UsersByUserNameMap.put(this.tmpUser.getUserName(),this.tmpUser);
				DataBase.UsersByUserNameMap.get(String.valueOf(friendsComboBox.getSelectedItem())).
				getFriendsMassagesMap().get(this.tmpUser.getUserName()).add(m);
				
				DataBase.UsersByIdMap.put(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()).getId(), DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()));
				DataBase.UsersByIdMap.put(DataBase.UsersByUserNameMap.get(String.valueOf(friendsComboBox.getSelectedItem())).getId(), DataBase.UsersByUserNameMap.get(String.valueOf(friendsComboBox.getSelectedItem())));
				
				DataBase.addToDaliyMassagesMap(m);
								
				pastMassages.setText(pastMassages.getText() + editor.getText() + " " + this.tmpUser.getFirstName()
				 + ": " + currentMassageText + '\n');
				currentMassage.setText("");
				editor.setText("");
				
				DataBase.writeMassageToMassageText(this.tmpUser, DataBase.UsersByUserNameMap.get(String.valueOf(friendsComboBox.getSelectedItem())));
				DataBase.writeToUsersFile("src/Users.txt",DataBase.UsersByUserNameMap);
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "Please choose a friend to send the massage to , type a text and choose the date");
			} 
			catch (ParseException ex) 
			{
				JOptionPane.showMessageDialog(null, "Something went wrong with the Date parsing");
			}
			catch (OutOfDateException ex)
			{
				JOptionPane.showMessageDialog(null, "The date of the massage can not be earlier than the 1st Fabuary 2022 (01/02/2022)");
			}
		}
		
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			this.setVisible(false);
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(friendsComboBox.getSelectedIndex() == 0)
		{
			pastMassages.setText("");
		}
		else
		{
			/*Setting the text to the text of the friend chosen*/
			
			String pastMassagesStr = "";
			Iterator<Massage> itr = this.tmpUser.getFriendsMassagesMap().get(String.valueOf(friendsComboBox.getSelectedItem())).iterator();	
			while(itr.hasNext())
			{
				Massage m = itr.next();
				pastMassagesStr += m.getText();
			}
			
			pastMassages.setText(pastMassagesStr);
		}
	}
}
