package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class AddManagerFile extends JFrame implements ActionListener{

	public JTextField userName_tf;
	public JPasswordField passwordField;
	public JTextField firstName_tf;
	public JTextField lastName_tf;
	public JLabel typeOfManagerLabel;
	public JComboBox<String> managerTypeComboBox;
	public JButton addManagerButton;
	public JButton backToMenuButton;
	public JButton clearButton;
	public JLabel title;
	public JLabel userNameLabel;
	public JLabel passwordLabel;
	public JLabel firstNameLabel;
	public JLabel lastNameLabel;
	public JLabel background1;
	public JLabel background2;
	
	private User tmpUser;

	public AddManagerFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 400);
		getContentPane().setLayout(null);

		title = new JLabel("Add Manager");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		title.setBounds(155, 11, 112, 30);
		getContentPane().add(title);
		
		userNameLabel = new JLabel("User name:");
		userNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		userNameLabel.setBounds(57, 55, 84, 21);
		getContentPane().add(userNameLabel);
		
		userName_tf = new JTextField();
		userName_tf.setBounds(167, 52, 137, 23);
		getContentPane().add(userName_tf);
		userName_tf.setColumns(10);
		
		passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		passwordLabel.setBounds(57, 87, 84, 21);
		getContentPane().add(passwordLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(167, 86, 137, 23);
		getContentPane().add(passwordField);
		
		firstNameLabel = new JLabel("First name:");
		firstNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		firstNameLabel.setBounds(57, 119, 84, 21);
		getContentPane().add(firstNameLabel);
		
		firstName_tf = new JTextField();
		firstName_tf.setBounds(167, 120, 137, 23);
		getContentPane().add(firstName_tf);
		firstName_tf.setColumns(10);
		
		lastNameLabel = new JLabel("Last name:");
		lastNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lastNameLabel.setBounds(57, 151, 84, 21);
		getContentPane().add(lastNameLabel);
		
		lastName_tf = new JTextField();
		lastName_tf.setBounds(167, 154, 137, 23);
		getContentPane().add(lastName_tf);
		lastName_tf.setColumns(10);
		
		typeOfManagerLabel = new JLabel("Type of manager:");
		typeOfManagerLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		typeOfManagerLabel.setBounds(57, 188, 126, 21);
		getContentPane().add(typeOfManagerLabel);
		
		managerTypeComboBox = new JComboBox<String>();
		managerTypeComboBox.setBounds(193, 188, 126, 22);
		managerTypeComboBox.addItem("");
		managerTypeComboBox.addItem("Main Manager");
		managerTypeComboBox.addItem("Users Manager");
		managerTypeComboBox.addItem("Forums Manager");
		getContentPane().add(managerTypeComboBox);
		
		addManagerButton = new JButton("Add Manager");
		addManagerButton.setIcon(new ImageIcon(AddManagerFile.class.getResource("/img/icons8-add-administrator-16.png")));
		addManagerButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		addManagerButton.setBounds(137, 229, 149, 30);
		addManagerButton.addActionListener(this);
		getContentPane().add(addManagerButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(AddManagerFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(137, 305, 149, 30);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		clearButton = new JButton("Clear");
		clearButton.setIcon(new ImageIcon(AddManagerFile.class.getResource("/img/archeology.png")));
		clearButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		clearButton.setBounds(137, 264, 149, 30);
		clearButton.addActionListener(this);
		getContentPane().add(clearButton);
		
		background1 = new JLabel("");
		background1.setIcon(new ImageIcon(AddManagerFile.class.getResource("/img/icons8-manager-100.png")));
		background1.setBounds(23, 220, 100, 115);
		getContentPane().add(background1);
		
		background2 = new JLabel("");
		background2.setIcon(new ImageIcon(AddManagerFile.class.getResource("/img/icons8-manager-100 (1).png")));
		background2.setBounds(307, 229, 117, 106);
		getContentPane().add(background2);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == addManagerButton)
		{
			try
			{
				User u = null;
				
				/*Missing field*/
				if(userName_tf.getText().equals("") || String.valueOf(passwordField.getPassword()).equals("") || 
				   firstName_tf.getText().equals("") || lastName_tf.getText().equals("") || 
				   managerTypeComboBox.getSelectedIndex() == 0)
				{
					throw new NullPointerException();
				}
				
				/*User already exists or removed*/
				if(DataBase.UsersByUserNameMap.get(userName_tf.getText()) != null || DataBase.removedUsersByUserNameMap.get(userName_tf.getText()) != null)
				{
					throw new UnauthorizedException();
				}
				
				if(managerTypeComboBox.getSelectedIndex() == 1)//Main Manager
				{
					u = new MainManager(userName_tf.getText(),String.valueOf(passwordField.getPassword()),firstName_tf.getText(),lastName_tf.getText());
				}
				else if(managerTypeComboBox.getSelectedIndex() == 2)//Users Manager
				{
					u = new UsersManager(userName_tf.getText(),String.valueOf(passwordField.getPassword()),firstName_tf.getText(),lastName_tf.getText());
				}
				else if(managerTypeComboBox.getSelectedIndex() == 3)//Forums Manager
				{
					u = new ForumsManager(userName_tf.getText(),String.valueOf(passwordField.getPassword()),firstName_tf.getText(),lastName_tf.getText());
				}
				
				/*Adding to the fit data structures and writing to the fit files*/
				
				DataBase.UsersByUserNameMap.put(u.getUserName(), u);
				DataBase.UsersByIdMap.put(u.getId(), u);
				
				DataBase.writeToUsersFile("src/Users.txt", DataBase.UsersByUserNameMap);
				
				JOptionPane.showMessageDialog(null, "Manager was added successfully");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields is empty, please fill the whole fields");
			} 
			catch (UnauthorizedException ex)
			{
				JOptionPane.showMessageDialog(null, "User is already exists at the system, please type another user name");
			}
			
		}
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			this.setVisible(false);
		}
		if(e.getSource() == clearButton)
		{
			userName_tf.setText("");
			passwordField.setText("");
			firstName_tf.setText("");
			lastName_tf.setText("");
			managerTypeComboBox.setSelectedIndex(0);
		}
		
	}
}
