package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class BuildForumFile extends JFrame implements ActionListener{

	public JTextField textField;
	public JPanel panel;
	public JLabel title;
	public JPanel panel_1;
	public JLabel forumNameLabel;
	public JPanel panel_2;
	public JLabel descriptionLabel;
	public JScrollPane scrollPane;
	public JTextArea textArea;
	public JButton buildForumButton;
	public JButton backToMenuButton;
	
	private User tmpUser;

	public BuildForumFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 500);
		getContentPane().setLayout(null);
	
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(-9, 11, 414, 40);
		getContentPane().add(panel);
		
		title = new JLabel("Build A Forum");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		panel.add(title);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(20, 62, 385, 48);
		getContentPane().add(panel_1);
		
		forumNameLabel = new JLabel("Forum name:");
		forumNameLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		panel_1.add(forumNameLabel);
		
		textField = new JTextField();
		panel_1.add(textField);
		textField.setColumns(20);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(10, 121, 404, 227);
		getContentPane().add(panel_2);
		
		descriptionLabel = new JLabel("What is the Forum meant for?");
		descriptionLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		panel_2.add(descriptionLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panel_2.add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setColumns(30);
		textArea.setRows(8);
		scrollPane.setViewportView(textArea);
		
		buildForumButton = new JButton("Build Forum");
		buildForumButton.setIcon(new ImageIcon(BuildForumFile.class.getResource("/img/discussion.png")));
		buildForumButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		buildForumButton.setBounds(123, 359, 158, 40);
		buildForumButton.addActionListener(this);
		getContentPane().add(buildForumButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(BuildForumFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(123, 410, 160, 40);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == buildForumButton)
		{
			try
			{
				/*Missing field*/
				if(textField.getText().equals("") || textArea.getText().equals(""))
				{
					throw new NullPointerException();
				}
				
				/*Adding the forums to the fit data structures and generating and writing it info to the fit text files*/
				
				Forum f = new Forum(textField.getText(),textArea.getText());
				String str = "src/Forum" + String.valueOf(f.getForumCode()) + "ID" + String.valueOf(this.tmpUser.getId()) + ".txt";
				f.setFilePathForum(str);
				DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()).getForumsList().add(f);
				DataBase.UsersByIdMap.put(DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()).getId(), DataBase.UsersByUserNameMap.get(this.tmpUser.getUserName()));
				DataBase.forumsList.add(f);
				
				File file = null;
				try
				{
					file = new File(str);
					file.createNewFile();
					
					DataBase.writeToForumsDetailsFile();
					
					JOptionPane.showMessageDialog(null, "Forum code is: " + f.getForumCode());
					JOptionPane.showMessageDialog(null, "Forum created successfuly");
				}
				catch(IOException ex)
				{
					System.out.println("Something went wrong with creating the forum file");
				}
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields is empty, please fill the whole fields");
			}
		}
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			setVisible(false);
		}
		
	}
}
