package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class SendMassageInForumFile extends JFrame implements ActionListener,ItemListener{

	public JPanel panel1;
	public JLabel massageLabel;
	public JComboBox<String> forumsComboBox;
	public JScrollPane scrollPane11;
	public JTextArea previousMassages_ta;
	public JScrollPane scrollPane2;
	public JPanel panel2;
	public JPanel panel3;
	public JScrollPane scrollPane22;
	public JTextArea currentMassage_ta;
	public JLabel previousMassages;
	public JLabel currentMassageLabel;
	public JButton sendButton;
	public JButton backToMenuButton;
	public JLabel dateLabel;
	public JDateChooser dateChooser;
	public JTextFieldDateEditor editor;
	
	private User tmpUser;
	
	public SendMassageInForumFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 650);
		getContentPane().setLayout(null);
		
		panel1 = new JPanel();
		panel1.setBackground(Color.WHITE);
		panel1.setBounds(10, 11, 424, 62);
		getContentPane().add(panel1);
		
		panel2 = new JPanel();
		panel2.setBackground(Color.WHITE);
		panel2.setBounds(42, 84, 372, 190);
		getContentPane().add(panel2);
		
		massageLabel = new JLabel("Please choose the forum by its name and code you want to send a massage:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		panel1.add(massageLabel);
		
		forumsComboBox = new JComboBox<String>();
		forumsComboBox.addItem("");
		
		/*Adding the forums to the combo box*/
		for(Forum f:DataBase.forumsList)
		{
			forumsComboBox.addItem(f.getForumName() + " " + String.valueOf(f.getForumCode()));
		}
		forumsComboBox.addItemListener(this);
		panel1.add(forumsComboBox);
		
		previousMassages = new JLabel("Previous Massages:");
		panel2.add(previousMassages);
		previousMassages.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
	
		scrollPane11 = new JScrollPane();
		scrollPane11.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane11.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane11.setBounds(10, 94, 414, 83);
		panel2.add(scrollPane11);
		
		previousMassages_ta = new JTextArea();
		previousMassages_ta.setColumns(30);
		previousMassages_ta.setRows(8);
		previousMassages_ta.setEditable(false);
		scrollPane11.setViewportView(previousMassages_ta);
		
		panel3 = new JPanel();
		panel3.setBackground(Color.WHITE);
		panel3.setBounds(42, 285, 372, 196);
		getContentPane().add(panel3);
		
		currentMassageLabel = new JLabel("You type your current Masssage here:");
		panel3.add(currentMassageLabel);
		currentMassageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		
		scrollPane22 = new JScrollPane();
		scrollPane22.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane22.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panel3.add(scrollPane22);
		
		currentMassage_ta = new JTextArea();
		currentMassage_ta.setColumns(30);
		currentMassage_ta.setRows(8);
		scrollPane22.setViewportView(currentMassage_ta);
		
		sendButton = new JButton("Send");
		sendButton.setIcon(new ImageIcon(SendMassageInForumFile.class.getResource("/img/send.png")));
		sendButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		sendButton.setBounds(42, 551, 149, 36);
		sendButton.addActionListener(this);
		getContentPane().add(sendButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(SendMassageInForumFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(265, 551, 149, 36);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		dateLabel = new JLabel("Date the current massage is sent:");
		dateLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		dateLabel.setBounds(42, 492, 251, 33);
		getContentPane().add(dateLabel);
		
		dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("dd/MM/yyyy");
		dateChooser.setBounds(303, 502, 131, 19);
		editor = (JTextFieldDateEditor) dateChooser.getDateEditor();
		editor.setEditable(false);
		getContentPane().add(dateChooser);
		
		this.setVisible(true);			
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == sendButton)
		{
			try
			{
				if(editor.getText().equals("") || currentMassage_ta.getText().equals("")|| forumsComboBox.getSelectedIndex() == 0)
				{
					throw new NullPointerException();
				}
				Date tmpDate = new SimpleDateFormat("dd/MM/yyyy").parse(editor.getText());
				@SuppressWarnings("deprecation")
				Date dateTheSystemWasOpened = new Date(122,1,1); // 1/2/2022
				if(tmpDate.getTime() - dateTheSystemWasOpened.getTime() < 0)//tmpDate is earlier than 1/2/2022
				{
					throw new OutOfDateException();
				}
				
				String strMassage = editor.getText() + " " + this.tmpUser.getFirstName().replace(" ", "-") + ": " + currentMassage_ta.getText() + '\n';
				Massage m = new Massage(strMassage,tmpDate);
				String[]strArr = String.valueOf(forumsComboBox.getSelectedItem()).split(" ");
				Forum tmpForum = new Forum(Integer.parseInt(strArr[strArr.length - 1]));//The forum code
								
				tmpForum = DataBase.forumsList.get(DataBase.forumsList.indexOf(tmpForum));
				
				/*Adding the massage to the fit data structures*/
				/*Talking about the user who created the forum which the massage has sent*/
				int userId = DataBase.getForumUserId(tmpForum.getFilePathForum());
				int forumIndex = 0;
				
				if(DataBase.UsersByIdMap.get(userId) != null)
				{
					forumIndex = DataBase.UsersByIdMap.get(userId).getForumsList().indexOf(tmpForum);
					DataBase.UsersByIdMap.get(userId).getForumsList().get(forumIndex).getForumMassagesList().add(m);
					DataBase.UsersByUserNameMap.put(DataBase.UsersByIdMap.get(userId).getUserName(), DataBase.UsersByIdMap.get(userId));
				}
					
				else if(DataBase.UsersByIdMap.get(userId) == null)
				{
					forumIndex = DataBase.removedUsersByIdMap.get(userId).getForumsList().indexOf(tmpForum);
					DataBase.removedUsersByIdMap.get(userId).getForumsList().get(forumIndex).getForumMassagesList().add(m);
					DataBase.removedUsersByUserNameMap.put(DataBase.removedUsersByIdMap.get(userId).getUserName(), DataBase.removedUsersByIdMap.get(userId));
				}
				
				DataBase.UsersByIdMap.get(this.tmpUser.getId()).setMassagesAmount(this.tmpUser.getMassagesAmount() + 1);
				DataBase.UsersByUserNameMap.put(DataBase.UsersByIdMap.get(this.tmpUser.getId()).getUserName(),DataBase.UsersByIdMap.get(this.tmpUser.getId()));
				
				DataBase.addToDaliyMassagesMap(m);
				
				/*write the massage to the fit text files*/
				DataBase.writeMassageToFitForumMassagesFile(tmpForum.getForumCode(),userId,tmpForum);
				DataBase.writeToUsersFile("src/Users.txt",DataBase.UsersByUserNameMap);
				
				previousMassages_ta.setText(previousMassages_ta.getText() + strMassage);
				currentMassage_ta.setText("");
				editor.setText("");
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "At least one of the fields is empty, please fill the whole fields");
			}
			catch (ParseException ex) 
			{
				JOptionPane.showMessageDialog(null, "Something went wrong with converting the date");
			}
			catch (OutOfDateException ex)
			{
				JOptionPane.showMessageDialog(null, "The date of the massage can not be earlier than the 1st Fabuary 2022 (01/02/2022)");
			}
		}
		
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			this.setVisible(false);
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(forumsComboBox.getSelectedIndex() == 0)
		{
			previousMassages_ta.setText("");
		}
		else
		{
			/*Setting the text to the text of the forum chosen*/
			
			String previousMassagesText = "";
			String[] strArr = String.valueOf(forumsComboBox.getSelectedItem()).split(" ");
			Forum tmpForum = new Forum(Integer.parseInt(strArr[strArr.length - 1]));
			Iterator<Massage> itr = DataBase.forumsList.get(DataBase.forumsList.indexOf(tmpForum)).getForumMassagesList().iterator();
			while(itr.hasNext())
			{
				Massage m = itr.next();
				previousMassagesText += m.getText();
			}
			
			previousMassages_ta.setText(previousMassagesText);
		}
		
	}
}

