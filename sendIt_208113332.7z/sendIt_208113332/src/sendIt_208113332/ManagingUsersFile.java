package sendIt_208113332;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class ManagingUsersFile extends JFrame implements ActionListener{
	
	public JLabel massageLabel;
	public JLabel title;
	public JComboBox<String> usersComboBox;
	public JButton blockButton;
	public JButton removeButton;
	public JButton backToMenuButton;
	public JLabel background;
	public JLabel background2;
	
	private User tmpUser;

	public ManagingUsersFile(User tmpUser) {
		
		super("User: " + tmpUser.getUserName());
		getContentPane().setBackground(Color.WHITE);
		this.tmpUser = tmpUser;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		massageLabel = new JLabel("Please choose the user you would like to block or remove:");
		massageLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		massageLabel.setBounds(21, 39, 384, 28);
		getContentPane().add(massageLabel);
		
		title = new JLabel("Manage Users");
		title.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		title.setBounds(166, 11, 116, 28);
		getContentPane().add(title);
		
		usersComboBox = new JComboBox<String>();
		usersComboBox.setBounds(21, 78, 216, 22);
		usersComboBox.addItem("");
		
		/*Adding the users to the combo box*/
		for(User u:DataBase.UsersByUserNameMap.values())
		{
			if(this.tmpUser instanceof UsersManager)
			{
				if(u instanceof Member)
				{
					usersComboBox.addItem(u.getFirstName().replace(" ", "-") + " " + u.getLastName().replace(" ", "-") + " " + u.getUserName());
				}
			}
			else //Main manager, I assumed that a Main manager can not be removed
			{
				if(!(u instanceof MainManager))
					usersComboBox.addItem(u.getFirstName().replace(" ", "-") + " " + u.getLastName().replace(" ", "-") + " " + u.getUserName());
			}
		}
		getContentPane().add(usersComboBox);
		
		blockButton = new JButton("Block user");
		blockButton.setIcon(new ImageIcon(ManagingUsersFile.class.getResource("/img/icons8-block-16.png")));
		blockButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		blockButton.setBounds(138, 111, 156, 35);
		blockButton.addActionListener(this);
		getContentPane().add(blockButton);
		
		removeButton = new JButton("Remove user");
		removeButton.setIcon(new ImageIcon(ManagingUsersFile.class.getResource("/img/icons8-remove-16.png")));
		removeButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		removeButton.setBounds(138, 157, 156, 35);
		removeButton.addActionListener(this);
		getContentPane().add(removeButton);
		
		backToMenuButton = new JButton("Back to menu");
		backToMenuButton.setIcon(new ImageIcon(ManagingUsersFile.class.getResource("/img/return.png")));
		backToMenuButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		backToMenuButton.setBounds(138, 203, 156, 35);
		backToMenuButton.addActionListener(this);
		getContentPane().add(backToMenuButton);
		
		background = new JLabel("");
		background.setIcon(new ImageIcon(ManagingUsersFile.class.getResource("/img/team-management.png")));
		background.setBackground(Color.WHITE);
		background.setBounds(3, 91, 234, 159);
		getContentPane().add(background);
		
		background2 = new JLabel("");
		background2.setIcon(new ImageIcon(ManagingUsersFile.class.getResource("/img/team.png")));
		background2.setBounds(302, 111, 132, 127);
		getContentPane().add(background2);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() != backToMenuButton)
		{
			try
			{
				if(usersComboBox.getSelectedIndex() == 0)
				{
					throw new NullPointerException();
				}
			}
			catch(NullPointerException ex)
			{
				JOptionPane.showMessageDialog(null, "Please choose a user from the list");
				return;
			}
		}
		
		if(e.getSource() == blockButton)
		{
			String[] strArr = String.valueOf(usersComboBox.getSelectedItem()).split(" ");
			DataBase.UsersByUserNameMap.get(strArr[2]).setBlocked(true);
			DataBase.UsersByIdMap.get(DataBase.UsersByUserNameMap.get(strArr[2]).getId()).setBlocked(true);
			JOptionPane.showMessageDialog(null, "User has been blocked and can not enter the system");
			
			DataBase.writeToUsersFile("src/Users.txt", DataBase.UsersByUserNameMap);
		}
		
		if(e.getSource() == removeButton)
		{
			String[] strArr = String.valueOf(usersComboBox.getSelectedItem()).split(" ");
			User tmpUser2 = DataBase.UsersByUserNameMap.remove(strArr[2]);
			
			/*Adding and removing the users to the fit data structures and writing and deleting their details from the fit text files*/
			DataBase.UsersByIdMap.remove(tmpUser2.getId());
			DataBase.removedUsersByUserNameMap.put(tmpUser2.getUserName(), tmpUser2);
			DataBase.removedUsersByIdMap.put(tmpUser2.getId(),tmpUser2);
			
			JOptionPane.showMessageDialog(null, "User has been removed");
			usersComboBox.removeItemAt(usersComboBox.getSelectedIndex());
			usersComboBox.setSelectedIndex(0);
			
			DataBase.writeToUsersFile("src/Users.txt", DataBase.UsersByUserNameMap);
			DataBase.writeToUsersFile("src/RemovedUsers.txt", DataBase.removedUsersByUserNameMap);
		}
		
		if(e.getSource() == backToMenuButton)
		{
			new MainScreen(this.tmpUser);
			this.setVisible(false);
		}
		
	}

}
